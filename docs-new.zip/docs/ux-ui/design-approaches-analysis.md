# Constellation UX Design - Approaches Analysis

**Created:** 2025-11-22
**Designer:** Sally (UX Designer)
**Project:** Jaimee Constellation Gamification

---

## Design Challenge

**The Tension:**
- **Constellations** = Dark night sky, mystery, celestial wonder (cool palette)
- **Jaimee** = Warm, safe, supportive, therapeutic (warm palette)

**Goal:** Merge these seemingly opposing aesthetics into a cohesive, beautiful experience that feels both magical AND safe.

---

## 4 Proof-of-Concept Approaches

### POC 1: Warm Twilight Celestial
**File:** `docs/ux-ui/poc-warm-twilight-constellation.html`

**Concept:**
Instead of deep space black, use warm "golden hour" twilight sky - the magical moment between day and night.

**Visual Approach:**
- **Background:** Warm gradient (peachy-orange → lavender → warm purple)
- **Stars:** Warm gold (not cold white)
- **Constellations:** Golden lines with warm glow
- **Cards:** Light cream cards on twilight background

**Emotional Tone:**
- Transition and reflection (perfect for therapeutic context)
- Gentle and calming (not harsh or dark)
- Magical but approachable
- Maintains constellation wonder without losing warmth

**Pros:**
- ✅ Completely cohesive with Jaimee's warm brand
- ✅ Stars visible against warm colors
- ✅ Unique aesthetic (not seen in other apps)
- ✅ Emotionally reads as "reflection time" (therapeutic)
- ✅ No jarring visual shift from main app

**Cons:**
- ⚠️ Less "traditionally celestial" (not space-black)
- ⚠️ May feel less mystical/magical to some users
- ⚠️ Twilight metaphor may not resonate with everyone

**Best For:**
- Users who want gentle, calming experience
- Maintaining brand consistency throughout
- Therapeutic context (reflection, warmth, safety)

**Implementation Complexity:** Medium
- Custom gradient backgrounds
- Warm color-adjusted star animations
- Requires careful color calibration for readability

---

### POC 2: Hybrid Card Window
**File:** `docs/ux-ui/poc-hybrid-card-window.html`

**Concept:**
Keep Jaimee's warm cards, but INSIDE each card is a "window" into dark space - like looking through a telescope or portal.

**Visual Approach:**
- **Card Background:** Cream/white (standard Jaimee)
- **Celestial Window:** Traditional dark space (contained)
- **Border:** Warm gold frame around space window
- **Content:** Classic Jaimee warm typography below

**Emotional Tone:**
- "Special moment" framing - peeking into something magical
- Familiar structure (Jaimee cards) with magical content
- Containment feels intentional and safe
- Like opening a treasured box

**Pros:**
- ✅ Best of both worlds (warm frame + mystical content)
- ✅ Familiar Jaimee card structure (low learning curve)
- ✅ Traditional constellation aesthetic preserved
- ✅ Dark space works because it's contained
- ✅ Strong visual hierarchy (card → window → constellation)

**Cons:**
- ⚠️ May feel compartmentalized (two separate aesthetics)
- ⚠️ Less immersive than full-sky view
- ⚠️ Repetitive if many cards in feed

**Best For:**
- Users who love current Jaimee card UI
- Browsing multiple constellations in feed
- Preserving traditional constellation aesthetic
- Gradual visual transition (warm → mystical)

**Implementation Complexity:** Low
- Reuses existing Jaimee card components
- Standard dark space rendering inside container
- Easy to build in Flutter

---

### POC 3: Vintage Astronomy Map
**File:** `docs/ux-ui/poc-vintage-astronomy.html`

**Concept:**
Old astronomical charts aesthetic - parchment, sepia tones, illustrated constellations like antique star maps from the 1700s.

**Visual Approach:**
- **Background:** Aged parchment (warm cream/tan)
- **Illustrations:** Sepia ink, gold accents
- **Stars:** Warm gold dots with Greek letters (α, β, γ)
- **Details:** Vintage cartography ornaments

**Emotional Tone:**
- Treasured journal or precious artifact
- Historical, timeless, sophisticated
- Collector's item feeling
- Warm, scholarly, gentle

**Pros:**
- ✅ Completely unique differentiation
- ✅ Perfect warm palette match with Jaimee
- ✅ Feels like treasured personal journal (therapeutic connection)
- ✅ No dark/light aesthetic conflict
- ✅ Sophisticated and beautiful
- ✅ Greek letters (α, β, γ) add educational/elegant touch

**Cons:**
- ⚠️ Less "modern gamification" feel
- ⚠️ May feel too vintage/old for younger users
- ⚠️ Requires custom illustration style
- ⚠️ Animation opportunities limited (vintage maps don't animate)

**Best For:**
- Sophisticated, journaling-focused users
- Emphasizing "emotional archive" over "game"
- Unique brand differentiation
- Users who love vintage aesthetics

**Implementation Complexity:** High
- Custom vintage illustration style for each constellation
- Parchment texture and ornamental details
- May need custom fonts and decorative elements

---

### POC 4: Full Constellation Sky
**File:** `docs/ux-ui/poc-full-constellation-sky.html`

**Concept:**
Immersive full-screen constellation sky view with warm twilight gradient, showing all constellations organized by category.

**Visual Approach:**
- **Background:** Full-screen warm twilight (cream → purple gradient)
- **Constellations:** Mini cards floating in sky
- **Organization:** Three regions (Emotion/Courage/Presence)
- **Navigation:** Bottom nav for app integration

**Emotional Tone:**
- Immersive and expansive
- "Your entire journey visible at once"
- Atmospheric and contemplative
- Celebration of progress

**Pros:**
- ✅ Shows full collection at glance (great for progress visualization)
- ✅ Organized by category (clear structure)
- ✅ Immersive full-screen experience
- ✅ Easy to scan and find constellations
- ✅ Works well for celebration ritual

**Cons:**
- ⚠️ Less detail per constellation (overview, not deep dive)
- ⚠️ Requires separate detail view (tap to expand)
- ⚠️ May feel overwhelming with 88+ constellations

**Best For:**
- Main "My Sky" overview screen
- Progress visualization and celebration
- Quick navigation to specific constellations
- Weekly ritual experience

**Implementation Complexity:** Medium
- Grid/flex layout with responsive design
- Scroll optimization for 88+ cards
- Category organization logic
- Locked/unlocked state management

---

## Deep Analysis: Which Approach(es) to Use

### Recommendation: **Hybrid Strategy (Mix Multiple Approaches)**

Different screens serve different purposes. Here's how they could work together:

#### **Screen 1: Full Constellation Sky (POC 4)**
**Use Case:** Main overview/home for constellation feature
- Shows all constellations organized by category
- Users see their complete progress
- Warm twilight aesthetic (immersive but safe)
- Tap any constellation to see details

#### **Screen 2: Constellation Detail Cards (Choose POC 2 or POC 3)**
**Use Case:** When user taps a constellation from sky view
- Full details: mythology, breakthrough moment, stats
- **Option A:** Hybrid Card Window (POC 2) - if you want traditional space aesthetic
- **Option B:** Vintage Astronomy (POC 3) - if you want unique journaling feel

#### **Screen 3: Unlock Celebration (Unique Animation)**
**Use Case:** Real-time when constellation unlocks
- Brief full-screen animation
- Could use warm twilight (POC 1 style)
- "You've unlocked Leo!" with brief sparkle
- Fades back to chat

---

## Color Psychology Analysis

### Warm Twilight Palette (POC 1 & 4)
**Colors:** Peach (#FFE8D6) → Lavender (#C8A8BE) → Warm Purple (#8B7AA0)

**Psychological Impact:**
- **Warmth:** Peach/orange = comforting, nurturing
- **Transition:** Gradient = journey, progress, transformation
- **Depth:** Purple = introspection, wisdom
- **Safety:** Warm tones = approachable, not intimidating

**Therapeutic Alignment:** ✅✅✅
- Gentle on eyes (no harsh black)
- Evokes sunset/golden hour (natural reflection time)
- Reduces anxiety (warm > cool colors)
- Maintains mystery without darkness

### Vintage Parchment (POC 3)
**Colors:** Cream (#FFFCF8) → Tan (#F0E8D8) → Gold (#D4A868)

**Psychological Impact:**
- **Timelessness:** Vintage = permanent, lasting, significant
- **Warmth:** Cream/gold = comforting, valuable
- **Scholarship:** Parchment = learning, wisdom, growth
- **Nostalgia:** Vintage = treasured memories

**Therapeutic Alignment:** ✅✅✅
- Feels like personal journal (safe, private)
- No gamification pressure (scholarly, not competitive)
- Sophisticated and mature
- Warm throughout

### Hybrid Window (POC 2)
**Colors:** Cream cards (#FFF) + Dark space (#0a0a1f) + Gold accents

**Psychological Impact:**
- **Familiar → Novel:** Jaimee card structure eases into mystical
- **Containment:** Dark space "boxed in" feels controlled
- **Treasure Chest:** Opening a special window to see something precious

**Therapeutic Alignment:** ✅✅
- Safe structure (familiar cards)
- Allows traditional constellation aesthetic
- May create visual disconnect (warm/cool split)

---

## Technical Implementation Considerations

### Flutter Implementation Feasibility

**POC 1 (Warm Twilight):**
- **Gradient:** `LinearGradient` with warm color stops
- **Stars:** `CustomPaint` with warm gold colors
- **Animations:** Standard Flutter animation controllers
- **Complexity:** Medium

**POC 2 (Hybrid Window):**
- **Cards:** Standard `Card` widget (existing Jaimee style)
- **Space Window:** `Container` with dark gradient + `CustomPaint` for stars
- **Border:** `BoxDecoration` with gold border
- **Complexity:** Low (reuses existing components)

**POC 3 (Vintage Map):**
- **Parchment:** Texture image overlay or noise filter
- **Illustrations:** Custom SVG or hand-drawn PNG assets
- **Typography:** Serif fonts (Georgia, Garamond)
- **Complexity:** High (custom illustration assets needed)

**POC 4 (Full Sky):**
- **Layout:** `GridView` or `ListView` with category sections
- **Scroll:** Standard scroll behavior
- **Mini Cards:** Simplified version of constellation cards
- **Complexity:** Medium (responsive grid, scroll optimization)

---

## User Experience Considerations

### Cognitive Load
- **POC 1 (Warm Twilight):** Low - single cohesive aesthetic
- **POC 2 (Hybrid Window):** Medium - dual aesthetics require mental adjustment
- **POC 3 (Vintage Map):** Low - consistent vintage throughout
- **POC 4 (Full Sky):** Medium-High - many items visible (needs good organization)

### Emotional Impact
- **POC 1:** Calming, reflective, gentle ✅✅✅
- **POC 2:** Familiar + surprising (treasure chest feeling) ✅✅
- **POC 3:** Treasured journal, sophisticated ✅✅✅
- **POC 4:** Expansive, celebratory, progress-focused ✅✅✅

### Brand Cohesion with Jaimee
- **POC 1:** ✅✅✅ Perfect match (all warm tones)
- **POC 2:** ✅✅ Good (uses Jaimee card structure, contains mystical)
- **POC 3:** ✅✅✅ Perfect match (vintage warmth)
- **POC 4:** ✅✅✅ Perfect match (warm twilight throughout)

### Uniqueness / Differentiation
- **POC 1:** ✅✅✅ Very unique (warm celestial rarely seen)
- **POC 2:** ✅✅ Somewhat unique (hybrid approach)
- **POC 3:** ✅✅✅ Extremely unique (vintage astronomy)
- **POC 4:** ✅✅ Moderately unique (layout approach)

---

## Recommended Hybrid Approach

### **Primary Recommendation: Warm Twilight + Vintage Elements**

**Why This Combination:**
1. **Use Warm Twilight (POC 1) for immersive screens:**
   - Full constellation sky overview (POC 4 layout + POC 1 colors)
   - Unlock celebration animations
   - Weekly celebration ritual

2. **Use Vintage Astronomy (POC 3) for detail cards:**
   - Individual constellation details
   - Mythology and breakthrough moment display
   - Feels like opening a treasured page in your journal

3. **Transition Story:**
   - Main Jaimee app = bright cream/gold (daytime)
   - Tap "Constellations" tab = transition to warm twilight sky (reflection time)
   - Tap specific constellation = vintage card detail (treasured memory)
   - Creates emotional journey: Activity → Reflection → Remembrance

**Benefits:**
- ✅ Each aesthetic serves a specific purpose
- ✅ Warm palette throughout (brand cohesion)
- ✅ Multiple "wow" moments (twilight sky + vintage details)
- ✅ Therapeutic progression (activity → reflection)
- ✅ Unique differentiation (warm celestial + vintage maps)

---

## Alternative Recommendation: Hybrid Card Window (Simplest)

**If prioritizing speed/simplicity:**
- Use **POC 2** exclusively
- Reuses existing Jaimee card components
- Easiest Flutter implementation
- Still maintains mystical feeling (dark space windows)
- Safe fallback option

---

## Key Design Decisions Needed

### Decision 1: Color Direction
**A) Warm throughout** (Twilight + Vintage) - Recommended
**B) Hybrid warm/cool** (Cards + Dark windows)

### Decision 2: Detail Card Style
**A) Vintage Astronomy Map** - Unique, journal-like
**B) Hybrid Window** - Simpler, traditional constellation

### Decision 3: Full Sky View
**A) Warm twilight gradient background**
**B) Cream background with constellation cards**

### Decision 4: Animation Style
**A) Gentle, flowing** (warm twilight particles)
**B) Traditional space** (twinkling white stars)
**C) Vintage** (minimal animation, elegant fades)

---

## Next Steps

1. **Review all 4 POCs** in browser
2. **Choose primary direction** or hybrid combination
3. **Create detailed UX specification** based on chosen approach
4. **Define all screens, flows, and micro-interactions**
5. **Document design system** (colors, typography, components)

---

## Files Created

- ✅ `poc-warm-twilight-constellation.html` - Golden hour sky approach
- ✅ `poc-hybrid-card-window.html` - Jaimee cards with space windows
- ✅ `poc-vintage-astronomy.html` - Antique star map style
- ✅ `poc-full-constellation-sky.html` - Full sky overview with warm gradient

**To view:** Open any HTML file in your browser to see the visual approach.

---

_Each POC demonstrates a different way to solve the warm/mystical tension. The "right" answer depends on which emotional experience resonates most with your vision for Jaimee's users._
