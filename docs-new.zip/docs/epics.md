# jaimee-constellations - Epic Breakdown

**Author:** BMad
**Date:** 2025-11-22
**Project Level:** Level 3-4 (Complex Brownfield)
**Target Scale:** MVP (20-30 constellations, 1,000-10,000 users)

---

## Overview

This document provides the complete epic and story breakdown for the Constellation Gamification System, decomposing the requirements from the [PRD](./PRD.md) and [Architecture](./architecture/constellation-system-architecture.md) into implementable stories for AI development agents.

### Epic Summary

**Total Epics:** 6 (MVP Phase 1)
**Estimated Stories:** 45-55

**Epic Sequencing:**

1. **Foundation & Data Layer** (8-10 stories) - Database schema, models, seed data
2. **AI Breakthrough Detection** (7-9 stories) - LangChain integration, detection logic
3. **Constellation Service** (8-10 stories) - Unlock logic, progress tracking
4. **API Endpoints** (6-8 stories) - REST API implementation
5. **Integration & Notifications** (6-8 stories) - Chat hooks, Firebase notifications
6. **Testing, Monitoring & Deployment** (10-12 stories) - Quality assurance, launch

**Value Delivery Strategy:**
- Epic 1 establishes foundation (enables all other work)
- Epics 2-3 build core business logic (can be developed in parallel after Epic 1)
- Epic 4 exposes functionality via APIs
- Epic 5 integrates with existing chat flow
- Epic 6 ensures quality and successful launch

---

## Epic 1: Foundation & Data Layer

**Goal:** Establish database schema, SQLAlchemy models, and seed constellation library data to enable all constellation gamification functionality.

**Business Value:** Creates the data foundation for the entire constellation system. Without this, no other features can be implemented.

**Technical Scope:** Database migration, models, seed data, caching setup

---

### Story 1.1: Create Database Migration for Constellation Tables

As a **backend developer**,
I want **an Alembic migration that creates the 5 constellation tables**,
So that **the database schema supports constellation gamification**.

**Acceptance Criteria:**

**Given** the existing Ultra API AWS database with 12 tables
**When** I run `alembic upgrade head`
**Then** the following tables are created:
- `constellation_library` (with indexes on category and is_active)
- `user_constellations` (with indexes on user_id, unlocked_at, breakthrough_chat_id)
- `breakthrough_events` (with indexes on user_id, session_id, chat_id, category)
- `user_constellation_stats` (primary key on user_id)
- `weekly_reflections` (with unique constraint on user_id + week_start_date)

**And** the `update_constellation_stats()` database trigger is created
**And** the trigger is attached to `user_constellations` table (AFTER INSERT)
**And** all foreign key constraints reference existing tables correctly
**And** the migration can be rolled back cleanly with `alembic downgrade -1`

**Prerequisites:** None (first story)

**Technical Notes:**
- Migration file: `alembic/versions/xxx_add_constellation_tables.py`
- Use UUIDs or Integers for IDs (match existing tables - likely Integer based on existing patterns)
- Foreign keys: `user_profile(id)`, `chats(id)`, `sessions(id)`
- ON DELETE CASCADE for user_profile references
- Test migration on local database before committing

---

### Story 1.2: Implement SQLAlchemy Models for Constellation Library

As a **backend developer**,
I want **SQLAlchemy model classes for constellation data**,
So that **I can query and manage constellations using the ORM**.

**Acceptance Criteria:**

**Given** the database migration from Story 1.1 is applied
**When** I create the model classes
**Then** the following models exist in `app/db/`:
- `ConstellationLibrary` class in `app/db/constellation.py`
- Model includes all fields (id, constellation_key, name, category, mythology_short, etc.)
- Relationships defined (if any)

**And** async CRUD functions are implemented:
- `get_constellation_by_key(constellation_key: str)`
- `get_active_constellations(category: str = None)`
- `create_constellation(data: dict)`
- `update_constellation(id: int, data: dict)`

**And** models follow existing patterns from `app/db/user_metrics.py`:
- Inherit from `Base` (base_class.py)
- Use async functions (not class methods)
- Return results compatible with Pydantic schemas
- Use `get_db().session` for database access

**Prerequisites:** Story 1.1 (migration must exist)

**Technical Notes:**
- File: `app/db/constellation.py`
- Follow existing patterns from `user_metrics.py`
- Import: `from app.db.base_class import Base`
- Use `Column(JSON)` for flexible data (constellation_data, required_categories)

---

### Story 1.3: Implement SQLAlchemy Models for User Progress

As a **backend developer**,
I want **SQLAlchemy models for user constellation progress and breakthrough events**,
So that **I can track which constellations users have unlocked and why**.

**Acceptance Criteria:**

**Given** the database migration from Story 1.1 is applied
**When** I create the progress tracking models
**Then** the following models exist in `app/db/constellation_progress.py`:
- `UserConstellation` class (user unlock records)
- `BreakthroughEvent` class (detection history)
- `UserConstellationStats` class (aggregated stats)

**And** async CRUD functions are implemented for UserConstellation:
- `unlock_constellation_for_user(user_id, constellation_id, unlock_type, context)` - Idempotent
- `get_user_constellation(user_id, constellation_id)`
- `get_user_constellations(user_id, category=None)`
- `get_constellation_by_chat(chat_id)` - Find constellation linked to breakthrough message

**And** async CRUD functions for BreakthroughEvent:
- `save_breakthrough_event(user_id, chat_id, category, confidence, insight)`
- `get_user_breakthroughs(user_id, limit=10)`

**And** async CRUD functions for UserConstellationStats:
- `get_user_stats(user_id)` - Returns stats or creates if not exists
- `increment_category_count(user_id, category)` - Helper for testing

**And** all models have proper relationships:
- `UserConstellation.user_profile` → `UserProfile`
- `UserConstellation.constellation` → `ConstellationLibrary`
- `UserConstellation.breakthrough_chat` → `Chat`

**And** the UNIQUE constraint prevents duplicate unlocks

**Prerequisites:** Story 1.1 (migration), Story 1.2 (ConstellationLibrary model)

**Technical Notes:**
- File: `app/db/constellation_progress.py`
- Idempotent unlock: Check existing before creating
- Use `get_db().session.add()` and `commit()`
- Foreign keys match existing table ID types

---

### Story 1.4: Create Pydantic Schemas for Constellation Data

As a **backend developer**,
I want **Pydantic schemas for request/response validation**,
So that **API endpoints have type-safe data models**.

**Acceptance Criteria:**

**Given** the SQLAlchemy models from Stories 1.2 and 1.3
**When** I create Pydantic schemas
**Then** the following schemas exist in `app/schemas/schemas.py` or `app/api/api_v1/endpoints/models/constellation_data.py`:

**Request Schemas:**
- `MarkBreakthroughRequest` (chat_id, category?, note?)
- `AdminUnlockRequest` (user_id, constellation_key, unlock_type, reason)

**Response Schemas:**
- `ConstellationSchema` (id, key, name, category, mythology, is_unlocked, unlocked_at)
- `UserConstellationSchema` (constellation data + unlock details + breakthrough_link)
- `ConstellationSkyResponse` (constellations list + progress stats)
- `ProgressStatsSchema` (category counts, completion %, rarity distribution)
- `BreakthroughResponseSchema` (breakthrough_id, constellation_unlocked?, status)

**And** all schemas have:
- `class Config: from_attributes = True` (for ORM compatibility)
- Proper field validators
- Optional fields marked correctly
- Clear docstrings

**Prerequisites:** Stories 1.2, 1.3 (models must exist)

**Technical Notes:**
- File: `app/api/api_v1/endpoints/models/constellation_data.py` (new) OR add to `app/schemas/schemas.py` (existing)
- Follow existing schema patterns
- Use `Field(...)` for validation rules
- Test schema validation with sample data

---

### Story 1.5: Create Constellation Library Seed Data Script

As a **backend developer**,
I want **a seed data script that populates the constellation library**,
So that **the MVP has 20-30 constellations available for unlock**.

**Acceptance Criteria:**

**Given** the database migration and models are complete
**When** I run `python scripts/seed_constellations.py`
**Then** 30 constellations are created in the database with:
- **12 Emotion constellations** (40% - Pisces, Cancer, Aquarius, Scorpio, etc.)
- **9 Courage constellations** (30% - Leo, Aries, Sagittarius, Orion, etc.)
- **9 Presence constellations** (30% - Libra, Taurus, Virgo, etc.)

**And** each constellation has:
- Unique `constellation_key` (lowercase, e.g., "leo")
- Display `name` (title case, e.g., "Leo")
- `category` (emotion|courage|presence)
- `mythology_short` (1-2 sentences of meaningful text)
- `sort_order` (display ordering)
- `is_active = True` (MVP flag)

**And** the script is idempotent (can run multiple times safely)
**And** running the script twice doesn't create duplicates

**Prerequisites:** Stories 1.1, 1.2 (migration + ConstellationLibrary model)

**Technical Notes:**
- File: `scripts/seed_constellations.py`
- Use async functions with `async with init_db():`
- Check if constellation_key exists before creating (idempotency)
- Mythology content can be placeholder text initially (refine later)
- Consider using JSON file for constellation data (`data/constellations.json`)

---

### Story 1.6: Implement Redis Caching for Constellation Library

As a **backend developer**,
I want **Redis caching for the static constellation library**,
So that **constellation queries are fast and don't overload the database**.

**Acceptance Criteria:**

**Given** Redis is running (existing infrastructure)
**When** constellation library is queried
**Then** the following cache keys are used:
- `constellation:library:all` (all active constellations)
- `constellation:library:emotion` (emotion category)
- `constellation:library:courage` (courage category)
- `constellation:library:presence` (presence category)

**And** cache TTL is 1 hour (3600 seconds)
**And** cache is invalidated when constellation data updates
**And** cache miss triggers database query and cache population

**And** caching logic exists in service layer:
```python
async def get_cached_constellation_library(category: str = None):
    # Try cache first
    # On miss: query DB + populate cache
    # Return results
```

**Prerequisites:** Story 1.2 (ConstellationLibrary model)

**Technical Notes:**
- Use existing Redis connection from `app/core/redis_client` or similar
- JSON serialize constellation data for cache storage
- Handle cache failures gracefully (fallback to DB)
- Add cache warming on app startup (optional)

---

## Epic 2: AI Breakthrough Detection

**Goal:** Implement AI-powered breakthrough moment detection using LangChain to automatically recognize meaningful insights in user conversations.

**Business Value:** Enables the core innovation - automatically celebrating breakthrough moments without user effort. This is what makes the system magical vs manual badge collection.

**Technical Scope:** LangChain integration, detection prompts, category classification, confidence scoring

---

### Story 2.1: Create LangChain Prompt Template for Breakthrough Detection

As a **backend developer**,
I want **a LangChain prompt template that detects breakthrough moments**,
So that **the AI can identify meaningful insights in conversations**.

**Acceptance Criteria:**

**Given** the existing LangChain integration in `app/chat/`
**When** I create the breakthrough detection prompt
**Then** a prompt template file exists at `app/chat/templates/breakthrough_detection.txt`

**And** the prompt instructs the LLM to:
- Analyze conversation messages for breakthrough indicators
- Detect emotional language ("I realize...", "I understand now...")
- Identify vulnerability markers (first-time disclosures, difficult emotions)
- Recognize pattern connections (past/present, reframing)
- Classify into categories (emotion, courage, presence)

**And** the prompt returns structured JSON output:
```json
{
  "is_breakthrough": true/false,
  "category": "emotion" | "courage" | "presence",
  "confidence": 0.0-1.0,
  "insight_summary": "Brief description of what user realized",
  "emotional_indicators": ["marker1", "marker2"]
}
```

**And** the prompt is tested with 5 sample conversations (known breakthroughs)
**And** detection accuracy is validated (manual review of results)

**Prerequisites:** None (can be developed independently)

**Technical Notes:**
- File: `app/chat/templates/breakthrough_detection.txt`
- Use existing prompt template format
- Include conversation context (last 5 messages)
- Request JSON output for easy parsing
- Iterate and refine based on test results

---

### Story 2.2: Add Breakthrough Detection Topic to LangChain Model Configuration

As a **backend developer**,
I want **breakthrough detection added to the LangChain topic routing**,
So that **breakthrough analysis uses the appropriate LLM model**.

**Acceptance Criteria:**

**Given** the existing `TOPIC_MODELS` in `app/chat/models.py`
**When** I add breakthrough detection topic
**Then** `TOPIC_MODELS` includes:
```python
"breakthrough_detection": {
    "default": GEMINI_25_MODEL,  # Fast, cost-effective
    "openai_only": SPECIAL_MODEL_NAME  # Fallback
}
```

**And** `initialize_language_model("breakthrough_detection")` returns appropriate LLM
**And** the model supports JSON output format
**And** model selection prioritizes speed (Gemini 2.5 Flash recommended)

**Prerequisites:** Story 2.1 (prompt template)

**Technical Notes:**
- File: `app/chat/models.py`
- Use Gemini 2.5 Flash for speed (<2s target)
- Fallback to OpenAI if Gemini unavailable
- Test model initialization

---

### Story 2.3: Implement Breakthrough Detection Service (Real-Time Mode)

As a **backend developer**,
I want **a service function that analyzes messages for breakthroughs in real-time**,
So that **breakthrough detection happens during conversations**.

**Acceptance Criteria:**

**Given** the prompt template and model configuration from Stories 2.1-2.2
**When** I implement the detection service
**Then** a function exists:
```python
async def analyze_message_for_breakthrough(
    message: str,
    conversation_context: List[str],
    user_id: str
) -> BreakthroughDetectionResult
```

**And** the function:
- Constructs prompt with message + last 5 messages context
- Calls LangChain using `initialize_language_model("breakthrough_detection")`
- Parses JSON response
- Returns structured result with confidence score

**And** detection completes in < 2 seconds (P95)
**And** errors are handled gracefully (log + return no_detection)
**And** timeout after 5 seconds (prevents blocking)

**Prerequisites:** Stories 2.1, 2.2 (prompt + model config)

**Technical Notes:**
- File: `app/service/breakthrough_detection_service.py` (new) OR add to `constellation_service.py`
- Use async LangChain invocation: `chain.ainvoke()`
- Handle JSON parsing errors
- Add Logfire instrumentation
- Return Pydantic model: `BreakthroughDetectionResult`

---

### Story 2.4: Implement Category Classification Logic

As a **backend developer**,
I want **logic to classify breakthroughs into Emotion, Courage, or Presence categories**,
So that **constellations are awarded from the appropriate category**.

**Acceptance Criteria:**

**Given** a detected breakthrough moment
**When** the category classification runs
**Then** the category is determined by analyzing:
- **Emotion indicators:** Emotional awareness, processing feelings, naming emotions
- **Courage indicators:** Vulnerability, facing fears, taking action despite discomfort
- **Presence indicators:** Mindfulness, staying present, non-reactive awareness

**And** classification is included in LangChain prompt (Story 2.1)
**And** confidence threshold is enforced (only accept if confidence >= 0.70)
**And** category accuracy target is >= 75% (validated with test dataset)

**And** if category is ambiguous, default to most likely category
**And** manual user override is supported (Story 3.x will implement)

**Prerequisites:** Story 2.3 (detection service)

**Technical Notes:**
- Logic embedded in LangChain prompt
- Post-processing validation in Python (ensure category is valid)
- Add category-specific keyword detection as backup
- Log category confidence scores for analysis

---

### Story 2.5: Implement Post-Conversation Deep Analysis

As a **backend developer**,
I want **deep analysis of full conversations after sessions end**,
So that **missed breakthroughs are caught and categorization is refined**.

**Acceptance Criteria:**

**Given** a chat session has ended
**When** post-conversation analysis runs
**Then** a function exists:
```python
async def analyze_completed_session(session_id: int) -> List[BreakthroughDetectionResult]
```

**And** the function:
- Loads all messages from the session
- Analyzes the full conversation (not just individual messages)
- Detects breakthroughs missed in real-time
- Refines/reclassifies existing breakthrough events
- Updates `breakthrough_events` table with refined data

**And** analysis completes within 5 minutes
**And** existing breakthrough events can be updated (change category or confidence)
**And** errors don't block session closure

**Prerequisites:** Story 2.3 (detection service)

**Technical Notes:**
- File: Add to `app/service/breakthrough_detection_service.py`
- More thorough analysis (can use more expensive model)
- Compare with real-time detections, update if confidence higher
- Mark detection_type as "post_analysis"

---

### Story 2.6: Create Unit Tests for Breakthrough Detection

As a **backend developer**,
I want **comprehensive unit tests for breakthrough detection logic**,
So that **detection accuracy is verified and regressions are prevented**.

**Acceptance Criteria:**

**Given** the detection service from Stories 2.3-2.5
**When** I run the test suite
**Then** tests verify:
- Prompt template loads correctly
- LangChain model initializes
- JSON response parsing works
- Category classification is accurate
- Confidence scoring is appropriate

**And** test dataset includes:
- 10 clear breakthrough moments (should detect)
- 10 regular conversation messages (should not detect)
- 5 edge cases (ambiguous, short messages, typos)

**And** tests achieve >= 80% detection accuracy on dataset
**And** false positive rate is < 20%
**And** all tests pass with `pytest app/test/test_breakthrough_detection.py`

**Prerequisites:** Stories 2.1-2.5 (detection service complete)

**Technical Notes:**
- File: `app/test/test_breakthrough_detection.py`
- Use pytest-asyncio
- Mock LangChain for deterministic tests (optional)
- Create test conversation fixtures
- Measure accuracy, precision, recall

---

### Story 2.7: Implement Breakthrough Event Persistence

As a **backend developer**,
I want **detected breakthroughs saved to the database**,
So that **we have a historical record of all detected moments**.

**Acceptance Criteria:**

**Given** a breakthrough is detected via real-time or post-analysis
**When** the breakthrough is saved
**Then** a record is created in `breakthrough_events` table with:
- user_profile_id (FK to user)
- session_id, chat_id (conversation context)
- detection_type (real_time | post_analysis | manual)
- category (emotion | courage | presence)
- confidence_score (0.00-1.00)
- insight_summary (AI's interpretation)
- emotional_indicators (JSON array)
- detected_at timestamp

**And** the save operation is idempotent (duplicate detection doesn't create duplicates)
**And** saves complete in < 100ms
**And** failed saves are retried (if in Celery task)

**Prerequisites:** Story 1.3 (BreakthroughEvent model)

**Technical Notes:**
- Use CRUD function from Story 1.3: `save_breakthrough_event()`
- Check for existing event (same chat_id + detection_type) before creating
- Handle database errors gracefully
- Add Logfire logging

---

### Story 2.8: Tune Detection Confidence Threshold

As a **backend developer**,
I want **the confidence threshold tuned to balance sensitivity and precision**,
So that **we detect real breakthroughs without too many false positives**.

**Acceptance Criteria:**

**Given** the detection service and test dataset from Story 2.6
**When** I test different confidence thresholds (0.60, 0.70, 0.80, 0.90)
**Then** metrics are calculated for each threshold:
- True positive rate
- False positive rate
- Precision and recall

**And** the threshold that best balances accuracy (<20% false positive) is selected
**And** the chosen threshold is documented in code comments
**And** threshold is configurable via environment variable:
```python
BREAKTHROUGH_CONFIDENCE_THRESHOLD = float(os.getenv("BREAKTHROUGH_THRESHOLD", "0.70"))
```

**And** monitoring alerts if detection rate drops significantly (may indicate prompt issues)

**Prerequisites:** Stories 2.3, 2.6 (detection service + tests)

**Technical Notes:**
- Create threshold tuning script: `scripts/tune_breakthrough_threshold.py`
- Test with sample dataset (50+ conversations)
- Document findings in comments or README
- Make threshold externally configurable for production tuning

---

## Epic 3: Constellation Service & Unlock Logic

**Goal:** Implement constellation unlock mechanics, progress tracking, and constellation service business logic.

**Business Value:** Enables users to earn constellations through breakthroughs and tracks their progress across categories. Core gamification mechanics that make growth visible.

**Technical Scope:** Unlock logic, progress calculation, stats aggregation, constellation selection

---

### Story 3.1: Implement Constellation Unlock Logic (Idempotent)

As a **backend developer**,
I want **idempotent constellation unlock logic**,
So that **users receive constellations reliably without duplicates even on retries**.

**Acceptance Criteria:**

**Given** a breakthrough is detected for a user in a specific category
**When** the unlock function is called
**Then** the function `check_and_unlock_constellation(user_id, category, unlock_type, context)` executes:

**And** the unlock process:
1. Queries available constellations in category (not yet unlocked by user)
2. Selects random constellation from available set
3. Creates `user_constellation` record (calls function from Story 1.3)
4. Links to breakthrough (if unlock_type == "breakthrough")
5. Returns unlock details

**And** if called twice with same parameters, returns existing unlock (no duplicate)
**And** if no constellations available in category, returns None (graceful)
**And** unlock is transactional (all-or-nothing)
**And** unlock completes in < 1 second

**Prerequisites:** Stories 1.2, 1.3 (models), 2.7 (breakthrough persistence)

**Technical Notes:**
- File: `app/service/constellation_service.py`
- Check existing unlock before creating (idempotency)
- Use database transaction
- Handle edge cases (category empty, all unlocked)
- Return Pydantic schema: `ConstellationUnlockResult`

---

### Story 3.2: Implement Progress Calculation Service

As a **backend developer**,
I want **a service that calculates user's constellation progress**,
So that **users can see their overall stats and completion percentage**.

**Acceptance Criteria:**

**Given** a user with unlocked constellations
**When** progress is calculated
**Then** the function `get_user_constellation_progress(user_id)` returns:
```python
{
  "stats": {
    "total_unlocked": 5,
    "total_available": 30,
    "completion_percentage": 16.7,
    "by_category": {
      "emotion": {"unlocked": 2, "total": 12},
      "courage": {"unlocked": 2, "total": 9},
      "presence": {"unlocked": 1, "total": 9}
    },
    "by_rarity": {
      "common": 3, "rare": 2, "epic": 0, "legendary": 0
    }
  },
  "recent_unlocks": [...],  # Last 5
  "next_milestones": [...]   # Upcoming achievements
}
```

**And** calculation uses `user_constellation_stats` table (fast query)
**And** stats are accurate and up-to-date
**And** response time is < 100ms

**Prerequisites:** Story 1.3 (UserConstellationStats model)

**Technical Notes:**
- File: `app/service/constellation_service.py`
- Query stats table (don't recalculate from scratch)
- Calculate completion percentage
- Recent unlocks: Query user_constellations ordered by unlocked_at DESC
- Return Pydantic schema: `ProgressStatsSchema`

---

### Story 3.3: Implement Constellation Sky Data Aggregation

As a **backend developer**,
I want **a service that aggregates all user's unlocked constellations with details**,
So that **the frontend can display the constellation sky view**.

**Acceptance Criteria:**

**Given** a user with multiple unlocked constellations
**When** sky data is requested
**Then** the function `get_user_constellation_sky(user_id)` returns:
```python
{
  "constellations": [
    {
      "id": 1,
      "constellation": {...},  # Full constellation data
      "unlocked_at": "2024-10-10T14:30:00Z",
      "unlock_type": "breakthrough",
      "rarity_tier": "rare",
      "breakthrough_link": {
        "chat_id": 123,
        "session_id": 45,
        "message_preview": "I just realized..."
      } | null
    }
  ],
  "progress": {...}  # From Story 3.2
}
```

**And** query uses efficient JOINs:
- user_constellations → constellation_library
- user_constellations → chats (for breakthrough link)

**And** response includes only user's unlocked constellations
**And** sorted by unlocked_at DESC (most recent first)
**And** query performance < 1 second for 88 constellations

**Prerequisites:** Stories 1.2, 1.3 (models), 3.2 (progress service)

**Technical Notes:**
- File: `app/service/constellation_service.py`
- Use SQLAlchemy `joinedload()` to avoid N+1 queries
- Include breakthrough message preview (first 100 chars)
- Handle null breakthrough links (manual unlocks)
- Return Pydantic schema: `ConstellationSkyResponse`

---

### Story 3.4: Implement Breakthrough Anchoring (Link to Chat Messages)

As a **backend developer**,
I want **constellations linked to the specific chat messages that triggered them**,
So that **users can tap a constellation and revisit that breakthrough conversation**.

**Acceptance Criteria:**

**Given** a constellation unlocked via breakthrough detection
**When** the unlock is saved
**Then** the `user_constellation` record includes:
- `breakthrough_chat_id` (FK to chats.id)
- `breakthrough_session_id` (FK to sessions.id)

**And** the `breakthrough_event` record includes:
- `chat_id` (the specific message)
- `insight_summary` (AI's interpretation)

**And** a service function exists:
```python
async def get_constellation_breakthrough_context(user_constellation_id: int) -> dict
```

**And** the function returns:
- Full chat message text
- Session context (other messages in conversation)
- Timestamp of breakthrough
- AI's insight summary

**And** links don't break if chat messages are deleted (soft delete or handle gracefully)

**Prerequisites:** Story 1.3 (UserConstellation model with FK fields)

**Technical Notes:**
- File: `app/service/constellation_service.py`
- Query chat message via FK relationship
- Load session messages for context (±5 messages)
- Handle deleted messages gracefully (return placeholder)
- Return structured dict or Pydantic schema

---

### Story 3.5: Implement Category Completion Detection

As a **backend developer**,
I want **logic to detect when a user completes all constellations in a category**,
So that **future Celestial Levels can be unlocked (Phase 3)**.

**Acceptance Criteria:**

**Given** a user unlocks a constellation
**When** the unlock completes
**Then** the function `check_category_completion(user_id, category)` executes:

**And** the function:
- Counts user's unlocked constellations in category
- Counts total active constellations in category
- Returns True if counts match (category complete)

**And** if category is complete:
- Updates `user_constellation_stats.{category}_complete = True`
- Logs completion event
- (Phase 3 will trigger Celestial Level unlock)

**And** completion check runs after every unlock
**And** check completes in < 50ms

**Prerequisites:** Stories 1.2, 1.3 (models), 3.1 (unlock logic)

**Technical Notes:**
- File: `app/service/constellation_service.py`
- Simple count query with filter
- Update stats table when complete
- Emit event for future Celestial Levels integration
- Add unit test for completion detection

---

### Story 3.6: Implement Manual Breakthrough Marking Logic

As a **backend developer**,
I want **logic for users to manually mark past messages as breakthroughs**,
So that **users can capture meaningful moments the AI missed**.

**Acceptance Criteria:**

**Given** a user wants to mark a past chat message as meaningful
**When** the manual marking function is called
**Then** the function `mark_user_breakthrough(user_id, chat_id, category?, note?)` executes:

**And** the function:
- Validates chat_id belongs to user (authorization check)
- Determines category (use provided OR run AI classification on message)
- Creates `breakthrough_event` with `user_marked = True`
- Checks if should trigger constellation unlock
- Saves optional user note

**And** manual markings have same weight as AI-detected
**And** duplicate marking of same message is prevented (idempotent)
**And** rate limiting prevents abuse (max 10 marks per hour)

**Prerequisites:** Stories 1.3 (models), 2.3 (category classification), 3.1 (unlock logic)

**Technical Notes:**
- File: `app/service/constellation_service.py`
- Verify user owns the chat message (security)
- If category not provided, run lightweight AI classification
- Set `detection_type = "manual"`
- Implement rate limiting (Redis-based counter)

---

### Story 3.7: Implement Constellation Library Query Service

As a **backend developer**,
I want **a service that returns the constellation library with user's unlock status**,
So that **the frontend can show locked and unlocked constellations**.

**Acceptance Criteria:**

**Given** a user requests the constellation library
**When** the function `get_constellation_library(user_id, category?, unlocked_only?)` is called
**Then** the function returns:
```python
{
  "constellations": [
    {
      "id": 1,
      "key": "leo",
      "name": "Leo",
      "category": "courage",
      "mythology_short": "The lion who...",
      "is_unlocked": True/False,  # User-specific
      "unlocked_at": "timestamp" | null,
      "unlock_details": {...} | null
    }
  ],
  "stats": {
    "total_available": 30,
    "total_unlocked": 5,
    "by_category": {...}
  }
}
```

**And** uses Redis cache for constellation library (Story 1.6)
**And** JOIN with user_constellations to get unlock status
**And** filters work correctly (category filter, unlocked_only filter)
**And** response time < 500ms

**Prerequisites:** Stories 1.2, 1.3 (models), 1.6 (caching), 3.2 (progress stats)

**Technical Notes:**
- File: `app/service/constellation_service.py`
- Use cached library + JOIN with user progress
- Handle user with no unlocks (return all as locked)
- Return Pydantic schema with is_unlocked flag

---

### Story 3.8: Create Unit Tests for Constellation Service Logic

As a **backend developer**,
I want **unit tests for all constellation service functions**,
So that **business logic is verified and protected from regressions**.

**Acceptance Criteria:**

**Given** the constellation service from Stories 3.1-3.7
**When** I run the test suite
**Then** tests verify:
- Unlock logic is idempotent (calling twice doesn't duplicate)
- Progress calculation is accurate
- Sky aggregation includes correct data
- Breakthrough anchoring links correctly
- Category completion detection works
- Manual marking validates ownership

**And** test coverage is >= 80% for constellation_service.py
**And** all tests pass with `pytest app/test/test_constellation_service.py`
**And** tests use test database (isolated from dev/prod)

**Prerequisites:** Stories 3.1-3.7 (all service functions)

**Technical Notes:**
- File: `app/test/test_constellation_service.py`
- Create fixtures for test data (users, constellations, unlocks)
- Test edge cases (empty category, all unlocked, concurrent unlocks)
- Mock external dependencies if needed
- Clean up test data after tests

---

## Epic 4: API Endpoints

**Goal:** Implement FastAPI REST endpoints that expose constellation functionality to the Flutter mobile app.

**Business Value:** Provides the API contract for frontend integration. Enables Flutter app to display constellation sky, show progress, and handle user interactions.

**Technical Scope:** FastAPI routers, endpoint implementation, request/response handling, authentication integration

---

### Story 4.1: Create Constellation API Router and Register in API v1

As a **backend developer**,
I want **a new API router for constellation endpoints**,
So that **constellation functionality is organized and discoverable**.

**Acceptance Criteria:**

**Given** the existing API structure in `app/api/api_v1/`
**When** I create the constellation router
**Then** a file exists: `app/api/api_v1/endpoints/constellation.py`

**And** the file contains:
```python
from fastapi import APIRouter, Depends, HTTPException
from app.api.deps import validate_token, get_current_user

router = APIRouter()

# Endpoints will be added in subsequent stories
```

**And** the router is registered in `app/api/api_v1/api.py`:
```python
from app.api.api_v1.endpoints import constellation

api_router.include_router(
    constellation.router,
    prefix="/constellations",
    tags=["constellations"]
)
```

**And** the router is accessible at `/api/v1/constellations`
**And** OpenAPI docs show the constellation tag

**Prerequisites:** Story 1.4 (Pydantic schemas)

**Technical Notes:**
- File: `app/api/api_v1/endpoints/constellation.py`
- Follow existing pattern from `metrics.py`, `chat.py`
- Use existing auth dependencies
- Tag: "constellations" for OpenAPI grouping

---

### Story 4.2: Implement GET /constellations/library Endpoint

As a **backend developer**,
I want **an endpoint that returns the constellation library with user's unlock status**,
So that **the Flutter app can display locked and unlocked constellations**.

**Acceptance Criteria:**

**Given** the constellation router from Story 4.1
**When** I implement the endpoint
**Then** `GET /api/v1/constellations/library` exists with:

**Query Parameters:**
- `category`: Optional filter (emotion|courage|presence)
- `unlocked_only`: Boolean (default false)

**Authentication:** Requires Firebase token (`dependencies=[Depends(validate_token)]`)
**Authorization:** Uses `currentUserId = Depends(get_current_user)`

**Response:**
```json
{
  "constellations": [
    {
      "id": 1,
      "key": "leo",
      "name": "Leo",
      "category": "courage",
      "mythology_short": "The lion who...",
      "is_unlocked": true,
      "unlocked_at": "2024-10-10T14:30:00Z",
      "unlock_details": {...}
    }
  ],
  "stats": {
    "total_available": 30,
    "total_unlocked": 5,
    "by_category": {...}
  }
}
```

**And** response time < 500ms (P95)
**And** invalid category returns 400 error
**And** unauthenticated request returns 401 error

**Prerequisites:** Stories 3.7 (library query service), 4.1 (router)

**Technical Notes:**
- File: `app/api/api_v1/endpoints/constellation.py`
- Call service: `await get_constellation_library(currentUserId, category, unlocked_only)`
- Use `Query()` for query parameter validation
- Return JSON (FastAPI auto-serializes Pydantic)

---

### Story 4.3: Implement GET /constellations/sky Endpoint

As a **backend developer**,
I want **an endpoint that returns user's constellation sky**,
So that **the Flutter app can display the constellation overview screen**.

**Acceptance Criteria:**

**Given** the constellation router from Story 4.1
**When** I implement the endpoint
**Then** `GET /api/v1/constellations/sky` exists

**Authentication:** Requires Firebase token
**Authorization:** Auto-filtered by currentUserId

**Response:**
```json
{
  "constellations": [
    {
      "id": 1,
      "constellation": {...},
      "unlocked_at": "2024-10-10T14:30:00Z",
      "unlock_type": "breakthrough",
      "rarity_tier": "rare",
      "breakthrough_link": {
        "chat_id": 123,
        "session_id": 45,
        "message_preview": "I just realized..."
      }
    }
  ],
  "progress": {
    "total_unlocked": 5,
    "emotion_count": 2,
    "courage_count": 2,
    "presence_count": 1,
    "completion_percentage": 16.7
  }
}
```

**And** response time < 1 second (P95)
**And** empty array if user has no unlocks (not error)
**And** includes all unlock details for frontend rendering

**Prerequisites:** Story 3.3 (sky aggregation service), 4.1 (router)

**Technical Notes:**
- Call service: `await get_user_constellation_sky(currentUserId)`
- No query parameters needed (always shows user's own sky)
- Add Logfire span for performance tracking

---

### Story 4.4: Implement GET /constellations/{constellation_id} Endpoint

As a **backend developer**,
I want **an endpoint that returns detailed info about a specific constellation**,
So that **the Flutter app can display the constellation detail screen**.

**Acceptance Criteria:**

**Given** the constellation router from Story 4.1
**When** I implement the endpoint
**Then** `GET /api/v1/constellations/{constellation_id}` exists

**Path Parameter:** `constellation_id` (integer)
**Authentication:** Requires Firebase token

**Response:**
```json
{
  "constellation": {
    "id": 1,
    "key": "leo",
    "name": "Leo",
    "category": "courage",
    "mythology_short": "The lion who..."
  },
  "user_progress": {
    "is_unlocked": true,
    "unlocked_at": "2024-10-10T14:30:00Z",
    "unlock_story": {
      "type": "breakthrough",
      "breakthrough_message": {...},
      "session_context": {...}
    }
  },
  "mythology": {
    "short": "Brief text",
    "full": "Complete story (Phase 2)"
  }
}
```

**And** if constellation not found, return 404
**And** if user hasn't unlocked, show locked state (is_unlocked: false)
**And** response time < 500ms

**Prerequisites:** Stories 3.3, 3.4 (sky service, breakthrough context), 4.1 (router)

**Technical Notes:**
- Query constellation by ID
- JOIN with user_constellations for unlock status
- Include breakthrough context if unlocked via breakthrough
- Handle locked state gracefully

---

### Story 4.5: Implement POST /constellations/breakthrough/mark Endpoint

As a **backend developer**,
I want **an endpoint for users to manually mark breakthrough moments**,
So that **users can capture meaningful messages the AI missed**.

**Acceptance Criteria:**

**Given** the constellation router from Story 4.1
**When** I implement the endpoint
**Then** `POST /api/v1/constellations/breakthrough/mark` exists

**Request Body:**
```json
{
  "chat_id": 123,
  "category": "emotion",  // Optional
  "note": "This helped me realize..."  // Optional
}
```

**Authentication:** Requires Firebase token
**Authorization:** Validates chat_id belongs to currentUserId

**Response:**
```json
{
  "breakthrough_id": 456,
  "constellation_unlocked": {
    "id": 789,
    "constellation": {...},
    "celebration": {
      "message": "You've unlocked Leo!",
      "category": "courage"
    }
  } | null,
  "status": "breakthrough_recorded" | "constellation_unlocked"
}
```

**And** if chat_id doesn't belong to user, return 403 Forbidden
**And** if chat_id doesn't exist, return 404
**And** rate limiting enforced (10 marks per hour)
**And** response time < 1 second

**Prerequisites:** Story 3.6 (manual marking service), 4.1 (router)

**Technical Notes:**
- Use Pydantic model: `MarkBreakthroughRequest`
- Verify ownership: Check chat.user_id == currentUserId
- Call service: `await mark_user_breakthrough(...)`
- Handle unlock trigger (may or may not unlock constellation)

---

### Story 4.6: Implement GET /constellations/progress Endpoint

As a **backend developer**,
I want **an endpoint that returns user's constellation progress stats**,
So that **the Flutter app can show progress indicators and milestones**.

**Acceptance Criteria:**

**Given** the constellation router from Story 4.1
**When** I implement the endpoint
**Then** `GET /api/v1/constellations/progress` exists

**Authentication:** Requires Firebase token
**Authorization:** Auto-filtered by currentUserId

**Response:**
```json
{
  "stats": {
    "total_unlocked": 5,
    "total_available": 30,
    "completion_percentage": 16.7,
    "by_category": {
      "emotion": {"unlocked": 2, "total": 12},
      "courage": {"unlocked": 2, "total": 9},
      "presence": {"unlocked": 1, "total": 9}
    },
    "by_rarity": {
      "common": 3,
      "rare": 2,
      "epic": 0,
      "legendary": 0
    }
  },
  "recent_unlocks": [...],"next_milestones": [...]
}
```

**And** response time < 100ms
**And** works for users with no unlocks (returns zeros)

**Prerequisites:** Story 3.2 (progress service), 4.1 (router)

**Technical Notes:**
- Call service: `await get_user_constellation_progress(currentUserId)`
- Simple passthrough endpoint
- Add caching (optional, stats change infrequently)

---

### Story 4.7: Implement POST /admin/constellations/unlock Endpoint (Admin Only)

As a **backend developer**,
I want **an admin endpoint to manually unlock constellations**,
So that **support team can award constellations for special cases or testing**.

**Acceptance Criteria:**

**Given** the constellation router from Story 4.1
**When** I implement the admin endpoint
**Then** `POST /api/v1/constellations/admin/unlock` exists

**Request Body:**
```json
{
  "user_id": "uuid",
  "constellation_key": "leo",
  "unlock_type": "manual",
  "reason": "Support request - user missed unlock due to bug"
}
```

**Authentication:** Requires Firebase token
**Authorization:** Requires admin role (use existing `get_current_user_from_admin` dependency)

**Response:**
```json
{
  "success": true,
  "constellation_unlocked": {...},
  "message": "Leo unlocked for user"
}
```

**And** if user is not admin, return 403 Forbidden
**And** if constellation_key invalid, return 400
**And** if user already has constellation, return 409 Conflict
**And** audit log records manual unlock (who, when, why)

**Prerequisites:** Story 3.1 (unlock service), 4.1 (router)

**Technical Notes:**
- Use existing admin auth pattern
- Call unlock service with unlock_type="manual"
- Log to audit table or Logfire with reason
- Bypass normal unlock triggers

---

### Story 4.8: Create Integration Tests for All API Endpoints

As a **backend developer**,
I want **integration tests for all constellation endpoints**,
So that **API contracts are verified and breaking changes are caught**.

**Acceptance Criteria:**

**Given** all endpoints from Stories 4.2-4.7
**When** I run the integration test suite
**Then** tests verify each endpoint:
- **GET /library:** Returns correct data, filters work, auth required
- **GET /sky:** Returns user's constellations, empty array if none
- **GET /{id}:** Returns detail, 404 if not found, shows locked state
- **POST /breakthrough/mark:** Creates breakthrough, validates ownership, rate limits
- **GET /progress:** Returns accurate stats
- **POST /admin/unlock:** Requires admin, logs audit trail

**And** tests use test client (FastAPI TestClient)
**And** tests create test users, constellations, and unlocks
**And** auth is tested (401 for missing token, 403 for wrong user)
**And** all tests pass with `pytest app/test/test_constellation_api.py`

**Prerequisites:** Stories 4.1-4.7 (all endpoints)

**Technical Notes:**
- File: `app/test/test_constellation_api.py`
- Use FastAPI TestClient for endpoint testing
- Create fixtures for test auth tokens
- Test happy path + error cases
- Clean up test data after tests

---

## Epic 5: Integration & Notifications

**Goal:** Integrate constellation system with existing chat flow and notification infrastructure to enable real-time breakthrough detection and unlock celebrations.

**Business Value:** Makes the constellation system come alive in the user experience - breakthrough moments are detected during conversations and celebrated immediately.

**Technical Scope:** Chat endpoint integration, Firebase notifications, Celery task wiring, event flow

---

### Story 5.1: Add Breakthrough Detection Hook to Chat Endpoint

As a **backend developer**,
I want **breakthrough detection triggered after each chat message**,
So that **breakthrough moments are detected in real-time during conversations**.

**Acceptance Criteria:**

**Given** the existing POST /chats endpoint in `app/api/api_v1/endpoints/chat.py`
**When** a chat message is saved
**Then** after the message is persisted to database:

**And** a background task is triggered:
```python
from fastapi import BackgroundTasks

@router.post("/", dependencies=[Depends(validate_token)])
async def create_chat_message(
    request: ChatRequest,
    background_tasks: BackgroundTasks,
    currentUserId: str = Depends(get_current_user)
):
    # ... existing chat logic ...
    chat = await create_chat(message_data)

    # [NEW] Trigger breakthrough analysis
    background_tasks.add_task(
        trigger_breakthrough_analysis,
        chat_id=chat.id,
        user_id=currentUserId
    )

    # ... continue with AI response ...
    return response
```

**And** the background task is non-blocking (doesn't delay chat response)
**And** chat functionality continues to work if breakthrough detection fails
**And** detection runs for every user message (not Jaimee's responses)

**Prerequisites:** Stories 2.3 (detection service), 3.1 (unlock service)

**Technical Notes:**
- File: Modify `app/api/api_v1/endpoints/chat.py`
- Use FastAPI BackgroundTasks (lightweight, no Celery overhead)
- Import: `from app.service.constellation_service import trigger_breakthrough_analysis`
- Only trigger for user messages, not AI responses
- Add feature flag to disable if needed

---

### Story 5.2: Implement Breakthrough Analysis Orchestration Function

As a **backend developer**,
I want **an orchestration function that coordinates detection, saving, and unlock**,
So that **the breakthrough detection flow is executed properly**.

**Acceptance Criteria:**

**Given** a chat message that needs breakthrough analysis
**When** the orchestration function runs
**Then** the function `trigger_breakthrough_analysis(chat_id, user_id)` executes:

**And** the function flow:
1. Load chat message + conversation context (last 5 messages)
2. Call breakthrough detection service (Story 2.3)
3. If breakthrough detected and confidence >= 0.70:
   - Save breakthrough_event to database
   - Call unlock service (Story 3.1)
   - If constellation unlocked: Send notification (Story 5.4)
4. Log detection result (for analytics)
5. Handle errors gracefully (log, don't throw)

**And** function completes in < 3 seconds total
**And** errors don't crash the background task
**And** partial failures are handled (detection works but unlock fails = retry unlock)

**Prerequisites:** Stories 2.3 (detection), 2.7 (event persistence), 3.1 (unlock)

**Technical Notes:**
- File: `app/service/constellation_service.py`
- Orchestrates multiple services
- Comprehensive error handling (try/except blocks)
- Add Logfire spans for observability
- Return result summary for logging

---

### Story 5.3: Add Session Close Hook for Post-Conversation Analysis

As a **backend developer**,
I want **post-conversation analysis triggered when chat sessions end**,
So that **missed breakthroughs are caught with deep analysis**.

**Acceptance Criteria:**

**Given** the existing session close functionality
**When** a session is closed
**Then** a Celery task is triggered:

**And** hook exists in session close endpoint/logic:
```python
from background.worker import analyze_completed_session_task

# After session close logic
analyze_completed_session_task.delay(session_id=session.id)
```

**And** task is queued (not blocking session close)
**And** session close succeeds even if task queueing fails
**And** task processes within 5 minutes

**Prerequisites:** Story 2.5 (post-conversation analysis service)

**Technical Notes:**
- Find session close endpoint (likely in `app/api/api_v1/endpoints/sessions.py` or similar)
- Use Celery `.delay()` for async execution
- Import task from `background.worker`
- No user-facing changes (transparent background process)

---

### Story 5.4: Implement Firebase Notification for Constellation Unlock

As a **backend developer**,
I want **push notifications sent when constellations unlock**,
So that **users are immediately notified and can celebrate**.

**Acceptance Criteria:**

**Given** a constellation is unlocked for a user
**When** the unlock completes
**Then** a notification function is called:
```python
async def notify_constellation_unlock(user_id: str, constellation: dict)
```

**And** the function:
- Loads user profile
- Constructs notification data:
  ```json
  {
    "notification_title": "New Constellation Unlocked!",
    "notification_text": "You've unlocked Leo 🌟",
    "notification_type": "constellation_unlock",
    "data": {
      "constellation_id": 1,
      "category": "courage",
      "action": "open_constellation_detail"
    }
  }
  ```
- Writes to Firestore `ff_push_notifications` collection
- Uses existing `ff_notifications.py` pattern

**And** notification is sent within 500ms of unlock
**And** notification failure doesn't block unlock (log error)
**And** Flutter app receives notification via Firebase Cloud Messaging

**Prerequisites:** Story 3.1 (unlock logic)

**Technical Notes:**
- File: `app/service/constellation_service.py` OR `app/integrations/ff_notifications.py`
- Follow existing notification pattern from `ff_notifications.py`
- Use `@background_task_wrapper` if needed
- Test notification delivery to Firebase console
- Include data payload for deep linking to constellation detail

---

### Story 5.5: Wire Celery Tasks in Background Worker

As a **backend developer**,
I want **constellation-related Celery tasks registered in the worker**,
So that **background processing works correctly**.

**Acceptance Criteria:**

**Given** the existing Celery worker in `background/worker.py`
**When** I add constellation tasks
**Then** the following tasks are registered:

**Task 1: analyze_message_for_breakthrough_task** (Real-time - optional, if using Celery instead of BackgroundTasks)
```python
@celery.task(
    name="analyze_message_for_breakthrough",
    retry_backoff=5,
    autoretry_for=(Exception,),
    max_retries=3
)
@sync
async def analyze_message_for_breakthrough_task(chat_id: int, user_id: str):
    async with init_db():
        from app.service.constellation_service import trigger_breakthrough_analysis
        await trigger_breakthrough_analysis(chat_id, user_id)
```

**Task 2: analyze_completed_session_task** (Post-conversation)
```python
@celery.task(name="analyze_completed_session")
@sync
async def analyze_completed_session_task(session_id: int):
    async with init_db():
        from app.service.breakthrough_detection_service import analyze_completed_session
        await analyze_completed_session(session_id)
```

**And** tasks follow existing patterns (@sync decorator, init_db() context)
**And** tasks are importable: `from background.worker import analyze_completed_session_task`
**And** tasks can be invoked: `task.delay(session_id)`
**And** Celery worker picks up and executes tasks

**Prerequisites:** Stories 2.3, 2.5, 5.2 (detection and orchestration services)

**Technical Notes:**
- File: Modify `background/worker.py`
- Use existing @sync decorator pattern
- Always use `async with init_db():` for database access
- Test task execution with `celery -A background.worker worker --loglevel=info`

---

### Story 5.6: Implement Error Handling and Retry Logic for Background Tasks

As a **backend developer**,
I want **robust error handling in constellation background tasks**,
So that **transient failures are retried and permanent failures are logged**.

**Acceptance Criteria:**

**Given** constellation Celery tasks from Story 5.5
**When** tasks encounter errors
**Then** the retry configuration works:
- Max retries: 3
- Retry backoff: 5 seconds (exponential)
- Auto-retry for: (Exception,)
- Max backoff: 60 seconds

**And** specific error handling:
- **LangChain timeout:** Log warning, don't retry (skip this message)
- **Database connection error:** Retry (transient)
- **Constellation unlock conflict:** Don't retry (user already has it)
- **Unknown errors:** Retry up to max, then log to error tracking

**And** failed tasks after max retries are logged to dead letter queue
**And** errors include context (user_id, chat_id, error message)
**And** monitoring alerts on task failure rate > 5%

**Prerequisites:** Story 5.5 (Celery tasks registered)

**Technical Notes:**
- Configure in task decorator
- Add specific exception handling in task functions
- Use Logfire for error logging
- Consider Sentry or similar for error tracking (if exists)

---

### Story 5.7: Add Breakthrough Detection Monitoring and Instrumentation

As a **backend developer**,
I want **Logfire instrumentation for breakthrough detection flow**,
So that **we can monitor performance and troubleshoot issues**.

**Acceptance Criteria:**

**Given** the existing Logfire integration in the codebase
**When** breakthrough detection runs
**Then** the following spans are created:
- `breakthrough_detection` (overall detection)
- `langchain_analysis` (AI model call)
- `constellation_unlock` (unlock logic)
- `notification_send` (Firebase notification)

**And** each span includes context:
```python
with logfire.span("breakthrough_detection", chat_id=chat_id, user_id=user_id):
    logfire.info("Starting analysis")
    result = await detect_breakthrough(message)
    logfire.info("Detection complete",
                 detected=result.is_breakthrough,
                 confidence=result.confidence,
                 category=result.category)
```

**And** metrics are tracked:
- Detection latency (P50, P95, P99)
- Detection rate (per hour, per day)
- Unlock rate (conversions from detection to unlock)
- Category distribution (are categories balanced?)

**And** dashboards show real-time metrics

**Prerequisites:** Stories 2.3, 3.1, 5.2, 5.4 (all services)

**Technical Notes:**
- Add Logfire spans in service functions
- Use existing Logfire instrumentation patterns
- Track custom metrics where needed
- Create dashboard queries/alerts

---

### Story 5.8: Create End-to-End Integration Test for Breakthrough Flow

As a **backend developer**,
I want **an end-to-end test that verifies the complete breakthrough-to-unlock flow**,
So that **the entire integration is validated**.

**Acceptance Criteria:**

**Given** all integration components from Epic 5
**When** the E2E test runs
**Then** the test simulates:
1. User sends chat message via API
2. Message is saved to database
3. Background task triggers breakthrough detection
4. AI detects breakthrough (mock or real LangChain)
5. Breakthrough event is saved
6. Constellation unlock is triggered
7. Stats are updated (via trigger)
8. Firebase notification is sent (verify Firestore write)

**And** test verifies:
- Chat endpoint returns 200
- Breakthrough event exists in database
- User constellation record created
- Stats incremented
- Notification written to Firestore

**And** test runs in < 30 seconds
**And** test is repeatable (cleans up data)

**Prerequisites:** All Epic 5 stories (5.1-5.7)

**Technical Notes:**
- File: `app/test/test_constellation_e2e.py`
- Use TestClient + test database
- Mock LangChain for deterministic results (or use real with test prompts)
- Verify Firestore write (or mock Firebase)
- This is the critical integration validation test

---

## Epic 6: Testing, Monitoring & Deployment

**Goal:** Ensure quality, performance, and successful production launch through comprehensive testing, monitoring setup, and phased rollout.

**Business Value:** De-risks launch, ensures system performs well under load, catches bugs before users encounter them, enables confident production deployment.

**Technical Scope:** Performance testing, security audit, monitoring dashboards, feature flags, beta rollout, production launch

---

### Story 6.1: Implement Feature Flag for Constellation System

As a **backend developer**,
I want **a feature flag to control constellation system availability**,
So that **we can enable/disable the feature without code deployment**.

**Acceptance Criteria:**

**Given** the constellation system is implemented
**When** I add feature flag configuration
**Then** an environment variable exists:
```python
CONSTELLATION_FEATURE_ENABLED = os.getenv("CONSTELLATION_ENABLED", "false")
```

**And** all constellation endpoints check the flag:
```python
if CONSTELLATION_FEATURE_ENABLED != "true":
    raise HTTPException(status_code=404, detail="Feature not available")
```

**And** chat endpoint hook respects flag (skip detection if disabled)
**And** flag can be toggled without redeployment (via environment variable)
**And** disabled feature returns 404 (not 500 error)

**Prerequisites:** Stories 4.1-4.7 (endpoints), 5.1 (chat hook)

**Technical Notes:**
- File: `app/core/config.py` (add flag)
- Check flag at router level or individual endpoints
- Document flag in README/deployment docs
- Test both enabled and disabled states

---

### Story 6.2: Create Performance Test Suite for Constellation APIs

As a **backend developer**,
I want **load tests that verify API performance under realistic load**,
So that **we ensure <1s response times for 10,000 concurrent users**.

**Acceptance Criteria:**

**Given** all constellation endpoints are implemented
**When** I run performance tests
**Then** load testing tool (Locust, k6, or similar) simulates:
- 1,000 concurrent users querying /constellations/sky
- 500 concurrent breakthrough markings
- 100 constellation unlocks per minute

**And** performance targets are met:
- GET /library: P95 < 500ms
- GET /sky: P95 < 1s
- GET /progress: P95 < 100ms
- POST /breakthrough/mark: P95 < 1s

**And** database connections don't exhaust pool
**And** Redis cache hit rate > 80% for library queries
**And** breakthrough detection P95 < 2s

**Prerequisites:** Stories 4.2-4.6 (endpoints), 3.1-3.7 (services)

**Technical Notes:**
- File: `perf_test/constellation_load_test.py` or similar
- Use existing perf test infrastructure (if any)
- Test against staging environment with production-like data
- Generate load test report with graphs

---

### Story 6.3: Optimize Database Queries for Performance

As a **backend developer**,
I want **optimized database queries that minimize latency**,
So that **constellation APIs respond quickly even with 88 constellations**.

**Acceptance Criteria:**

**Given** performance test results from Story 6.2
**When** queries are optimized
**Then** the following optimizations are implemented:

**Query Optimization:**
- Use `joinedload()` for relationships (avoid N+1)
- Add `limit` to queries where appropriate
- Use database indexes effectively (verify with EXPLAIN ANALYZE)

**Example optimized query:**
```python
query = select(UserConstellation).options(
    joinedload(UserConstellation.constellation),
    joinedload(UserConstellation.breakthrough_chat)
).where(
    UserConstellation.user_profile_id == user_id
).order_by(
    UserConstellation.unlocked_at.desc()
)
```

**And** slow query log captures queries > 1s
**And** connection pool size is adequate (no connection timeouts)
**And** query response times meet targets (from Story 6.2)

**Prerequisites:** Story 6.2 (performance tests identify bottlenecks)

**Technical Notes:**
- Analyze slow queries with PostgreSQL EXPLAIN
- Add indexes if missing
- Consider database connection pooling config
- Test optimizations with load tests

---

### Story 6.4: Implement Security Audit and Rate Limiting

As a **backend developer**,
I want **security measures to protect constellation endpoints**,
So that **the system is resilient to abuse and attacks**.

**Acceptance Criteria:**

**Given** all constellation endpoints are implemented
**When** security measures are added
**Then** the following protections exist:

**Authentication:**
- All endpoints require Firebase token (already implemented)
- Token validation works correctly
- Expired tokens return 401

**Authorization:**
- Users can only access their own constellation data
- Admin endpoints require admin role
- Cross-user access attempts return 403

**Rate Limiting:**
- POST /breakthrough/mark: 10 requests per hour per user
- GET endpoints: 100 requests per minute per user
- Admin endpoints: No rate limit (trusted users)

**And** rate limiting uses Redis (existing infrastructure)
**And** rate limit exceeded returns 429 Too Many Requests
**And** rate limit headers included in response

**Prerequisites:** Stories 4.2-4.7 (endpoints)

**Technical Notes:**
- Implement rate limiting with Redis counters
- Use decorator or middleware pattern
- Follow existing rate limiting patterns (if any in codebase)
- Test rate limit enforcement

---

### Story 6.5: Create Monitoring Dashboards and Alerts

As a **backend developer**,
I want **Logfire dashboards and alerts for constellation metrics**,
So that **we can monitor system health and detect issues quickly**.

**Acceptance Criteria:**

**Given** Logfire instrumentation from Story 5.7
**When** dashboards are created
**Then** the following metrics are visible:

**Performance Metrics:**
- Breakthrough detection latency (P50, P95, P99)
- API endpoint response times
- Celery task durations
- Database query times

**Business Metrics:**
- Breakthrough detection rate (per hour, per day)
- Constellation unlock rate
- Category distribution (emotion/courage/presence balance)
- User engagement (API calls per user)

**And** alerts are configured:
- Breakthrough detection latency > 5s (P95)
- Unlock failure rate > 1%
- API error rate > 5%
- Celery task failure rate > 5%

**And** alerts notify development team (Slack, email, or PagerDuty)

**Prerequisites:** Story 5.7 (instrumentation)

**Technical Notes:**
- Use Logfire dashboard builder
- Create alert rules in Logfire
- Document dashboard URLs in README
- Test alerts by triggering conditions

---

### Story 6.6: Verify Data Privacy and GDPR Compliance

As a **backend developer**,
I want **constellation data included in GDPR compliance processes**,
So that **users can export and delete their constellation data**.

**Acceptance Criteria:**

**Given** constellation data contains sensitive breakthrough moments
**When** a user requests data export (GDPR)
**Then** the export includes:
- All user_constellation records
- All breakthrough_events for the user
- Constellation stats
- Weekly reflections (Phase 2)

**And** when user requests deletion:
- All constellation data is deleted (CASCADE foreign keys handle this)
- Breakthrough events are anonymized or deleted
- Stats are deleted

**And** data is encrypted at rest (existing PostgreSQL encryption)
**And** access logs exist for breakthrough data queries
**And** privacy policy is updated to mention constellation data

**Prerequisites:** Stories 1.1-1.3 (tables with CASCADE delete)

**Technical Notes:**
- Add constellation tables to existing GDPR export logic
- Verify ON DELETE CASCADE works correctly
- Test full user deletion flow
- Document in privacy policy

---

### Story 6.7: Create Deployment Runbook and Migration Plan

As a **backend developer**,
I want **a deployment runbook for the constellation system**,
So that **deployment to production is smooth and documented**.

**Acceptance Criteria:**

**Given** all Epic 1-5 stories are complete
**When** the runbook is created
**Then** a document exists: `docs/deployment-runbook-constellation.md`

**And** the runbook includes:
- **Pre-deployment checklist:**
  - Migration tested on staging
  - Seed data script tested
  - All tests passing
  - Feature flag configured (disabled initially)

- **Deployment steps:**
  1. Apply database migration
  2. Run seed data script
  3. Deploy code (API + worker)
  4. Verify health checks pass
  5. Enable feature flag for 10% users (beta)
  6. Monitor metrics for 48 hours
  7. Full rollout if metrics positive

- **Rollback plan:**
  - Disable feature flag
  - Revert code deployment
  - Rollback database migration (if necessary)

- **Monitoring checklist:**
  - Logfire dashboards showing data
  - Alerts configured and tested
  - Error rates within acceptable range

**And** deployment steps are tested on staging
**And** rollback plan is tested (verify migration downgrade works)

**Prerequisites:** All Epic 1-5 stories

**Technical Notes:**
- File: `docs/architecture/deployment-runbook-constellation.md`
- Include screenshots of dashboards
- Document environment variables
- Include troubleshooting section

---

### Story 6.8: Execute Beta Rollout (10% Users)

As a **backend developer**,
I want **constellation system enabled for 10% of users first**,
So that **we can validate the system with real users before full rollout**.

**Acceptance Criteria:**

**Given** the deployment runbook from Story 6.7
**When** beta rollout executes
**Then** the following steps are completed:
1. Migration applied to production database
2. Seed script populates 30 constellations
3. Code deployed (API + worker)
4. Feature flag enabled for 10% of users (user ID hash-based selection)
5. Monitoring dashboards observed for 48 hours
6. User feedback collected

**And** beta cohort selection is deterministic (same users each time)
**And** metrics are tracked:
- Breakthrough detection rate (2+ per user per week target)
- Unlock rate
- API error rate
- User engagement with constellation feature

**And** critical issues are fixed before full rollout
**And** decision is made: proceed to full rollout OR iterate

**Prerequisites:** Story 6.7 (runbook), all other Epic 6 stories

**Technical Notes:**
- Implement percentage-based feature flag (hash user_id % 100 < 10)
- Monitor closely for first 48 hours
- Gather user feedback (surveys, support tickets)
- Document learnings for full rollout

---

### Story 6.9: Performance Tuning Based on Beta Metrics

As a **backend developer**,
I want **performance optimizations based on real beta metrics**,
So that **the system performs well before full rollout**.

**Acceptance Criteria:**

**Given** 48 hours of beta metrics from Story 6.8
**When** performance issues are identified
**Then** optimizations are implemented:

**If detection latency > 2s:**
- Switch to faster LLM model (Gemini Flash)
- Reduce conversation context (5 messages → 3)
- Add timeout enforcement

**If API response times > targets:**
- Increase Redis cache TTL
- Add database query optimization
- Increase connection pool size

**If unlock rate too low (<2 per week):**
- Lower confidence threshold (0.70 → 0.65)
- Refine prompt to be more sensitive

**If unlock rate too high (>10 per week):**
- Raise confidence threshold
- Refine prompt to be more selective

**And** optimizations are tested on staging before production
**And** metrics improve after optimizations

**Prerequisites:** Story 6.8 (beta rollout with real metrics)

**Technical Notes:**
- Analyze Logfire metrics
- Make data-driven optimization decisions
- Test changes on staging first
- Document tuning decisions

---

### Story 6.10: Execute Full Production Rollout

As a **backend developer**,
I want **constellation system enabled for all users**,
So that **the full user base can benefit from constellation gamification**.

**Acceptance Criteria:**

**Given** beta rollout is successful (Story 6.8)
**When** full rollout executes
**Then** the following steps are completed:
1. Performance tuning applied (Story 6.9)
2. Critical bugs fixed (if any from beta)
3. Feature flag set to 100% (all users)
4. Monitoring confirms metrics are healthy
5. Support team briefed on new feature
6. User-facing documentation updated

**And** rollout is gradual:
- Hour 1: 25% of users
- Hour 4: 50% of users
- Hour 8: 75% of users
- Hour 12: 100% of users

**And** rollback can be triggered immediately if issues arise
**And** metrics are monitored continuously for first 7 days

**And** success criteria are met:
- API error rate < 1%
- Breakthrough detection working (users unlocking constellations)
- No critical bugs reported
- User sentiment positive

**Prerequisites:** Stories 6.8, 6.9 (beta complete, tuned)

**Technical Notes:**
- Update feature flag percentage gradually
- Monitor Logfire dashboards continuously
- Have rollback plan ready (disable flag)
- Celebrate successful launch! 🎉

---

### Story 6.11: Create AI Detection Accuracy Report

As a **backend developer**,
I want **a report on AI detection accuracy after 30 days of production data**,
So that **we can measure actual performance vs targets and improve the system**.

**Acceptance Criteria:**

**Given** 30 days of production constellation data
**When** the accuracy analysis runs
**Then** a report is generated with:

**Metrics:**
- Total breakthroughs detected (AI + manual)
- Detection rate per user per week (target: 2+)
- Category distribution (emotion/courage/presence balance)
- Confidence score distribution
- User manual marking rate (indicates false negatives)

**Comparison to Targets:**
- False positive rate (target: <20%)
- Category accuracy (target: >75%)
- Detection latency (target: <2s P95)

**And** recommendations are provided:
- Prompt refinement suggestions
- Threshold adjustments
- Category definition improvements

**And** report is saved: `docs/reports/constellation-accuracy-30day.md`

**Prerequisites:** Story 6.10 (full rollout, 30 days of data)

**Technical Notes:**
- Query breakthrough_events table
- Analyze user_marked breakthroughs (user corrections)
- Calculate precision/recall if ground truth available
- Create Python script for analysis: `scripts/analyze_detection_accuracy.py`

---

### Story 6.12: Document API for Frontend Team

As a **backend developer**,
I want **comprehensive API documentation for the Flutter team**,
So that **frontend developers can integrate constellation endpoints correctly**.

**Acceptance Criteria:**

**Given** all constellation endpoints are implemented
**When** API documentation is generated
**Then** OpenAPI/Swagger documentation includes:
- All 6 constellation endpoints
- Request/response schemas
- Authentication requirements
- Error responses
- Example requests and responses

**And** documentation is accessible at:
- `/docs` (Swagger UI)
- `/redoc` (ReDoc)

**And** additional documentation exists:
- API integration guide: `docs/api-integration-guide.md`
- Sample API calls with curl examples
- Firebase notification payload format
- Error handling guide

**And** documentation is reviewed by Flutter team

**Prerequisites:** Stories 4.1-4.7 (all endpoints)

**Technical Notes:**
- FastAPI auto-generates OpenAPI docs
- Add detailed docstrings to endpoints
- Create supplementary guide with examples
- Include authentication setup instructions
- Document notification payload structure

---

## Epic Breakdown Summary

### Total Stories: 48 Backend Implementation Stories

**Epic 1: Foundation & Data Layer** - 6 stories
- Database migration, models, schemas, seed data, caching

**Epic 2: AI Breakthrough Detection** - 8 stories
- LangChain integration, prompts, detection logic, testing

**Epic 3: Constellation Service & Unlock Logic** - 8 stories
- Unlock mechanics, progress tracking, breakthrough anchoring

**Epic 4: API Endpoints** - 8 stories
- FastAPI REST endpoints, authentication, integration tests

**Epic 5: Integration & Notifications** - 8 stories
- Chat hooks, Firebase notifications, Celery wiring, E2E tests

**Epic 6: Testing, Monitoring & Deployment** - 10 stories
- Feature flags, performance testing, security, monitoring, beta/production rollout

---

## Implementation Sequencing

### Phase 1: Foundation (Weeks 1-4)
**Epic 1 Complete** → Enables all other work
- Stories 1.1 through 1.6
- Deliverable: Database ready, models working, seed data loaded

### Phase 2: Core Logic (Weeks 5-12) - Can Parallelize
**Epic 2 + Epic 3** → Build detection and unlock mechanics
- Stories 2.1 through 2.8 (AI detection)
- Stories 3.1 through 3.8 (constellation service)
- Deliverable: Business logic complete, tested

### Phase 3: API Layer (Weeks 13-16)
**Epic 4 Complete** → Expose functionality
- Stories 4.1 through 4.8
- Deliverable: REST APIs working, documented

### Phase 4: Integration (Weeks 17-20)
**Epic 5 Complete** → Wire everything together
- Stories 5.1 through 5.8
- Deliverable: End-to-end flow working

### Phase 5: Launch (Weeks 21-24)
**Epic 6 Complete** → Production deployment
- Stories 6.1 through 6.12
- Deliverable: Beta rollout → Full production launch

**Total Timeline: 24 weeks (6 months)**

---

## Success Criteria for Epic Completion

**Epic 1 Complete When:**
- ✅ All 5 tables exist in database
- ✅ Models and schemas working
- ✅ 30 constellations seeded
- ✅ Redis caching functional

**Epic 2 Complete When:**
- ✅ Breakthrough detection working (<2s latency)
- ✅ Category classification accurate (>75%)
- ✅ Post-analysis catching missed breakthroughs
- ✅ Unit tests passing (>80% coverage)

**Epic 3 Complete When:**
- ✅ Idempotent unlock logic working
- ✅ Progress stats accurate
- ✅ Breakthrough anchoring functional
- ✅ Manual marking working with rate limits

**Epic 4 Complete When:**
- ✅ All 6 API endpoints implemented
- ✅ Authentication/authorization working
- ✅ Integration tests passing
- ✅ OpenAPI docs generated

**Epic 5 Complete When:**
- ✅ Chat integration working (detects breakthroughs)
- ✅ Firebase notifications sending
- ✅ Celery tasks processing
- ✅ E2E test validating full flow

**Epic 6 Complete When:**
- ✅ Performance tests passing (targets met)
- ✅ Security audit complete
- ✅ Beta rollout successful
- ✅ Full production launch complete

---

_For implementation: Use the BMad Method `create-story` workflow to generate detailed implementation plans for each story. Stories are sequenced with clear prerequisites to enable focused, autonomous development by AI agents._

_Next Step: Sprint Planning - Organize these 48 stories into development sprints._

