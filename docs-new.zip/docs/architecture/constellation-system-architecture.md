# Constellation Gamification System - Technical Architecture

**Project:** Jaimee AI Companion - Constellation Backend
**Architect:** Winston
**Date:** 2025-11-22
**Version:** 1.0
**Architecture Type:** Brownfield Integration (Modular Extension)

---

## Executive Summary

### Architectural Vision

The Constellation Gamification System integrates into the existing **Ultra API AWS** codebase as a **modular feature extension**, following established patterns while maintaining clear service boundaries for potential future extraction as a microservice.

### Core Architectural Principles

**1. Leverage Existing Infrastructure**
- Reuse FastAPI, PostgreSQL, Redis, Celery, LangChain stack
- Follow existing patterns (async services, Pydantic schemas, SQLAlchemy models)
- Integrate with existing auth, notifications, and background processing

**2. Modular Design**
- Clear service boundaries (Constellation Service is self-contained)
- Minimal coupling to chat/session logic
- Event-driven integration points
- Future-ready for microservice extraction

**3. Boring Technology**
- No new infrastructure required
- Use proven patterns from existing codebase
- Only innovate where necessary (breakthrough AI detection)

**4. Performance First**
- Real-time breakthrough detection (<2s latency)
- Efficient database queries with proper indexing
- Background processing for non-critical operations
- Redis caching for static constellation library

---

## Table of Contents

1. [System Context](#system-context)
2. [Architecture Decisions](#architecture-decisions)
3. [Service Architecture](#service-architecture)
4. [Data Architecture](#data-architecture)
5. [API Design](#api-design)
6. [Integration Architecture](#integration-architecture)
7. [AI Pipeline](#ai-pipeline)
8. [Background Processing](#background-processing)
9. [Event Flow](#event-flow)
10. [Security Architecture](#security-architecture)
11. [Deployment Architecture](#deployment-architecture)
12. [Migration Strategy](#migration-strategy)

---

## System Context

### Existing System: Ultra API AWS

**Current Architecture:**
- **Framework:** Python 3.10 + FastAPI
- **Database:** PostgreSQL 13+ (async via asyncpg)
- **Cache/Queue:** Redis 4.5.5
- **Background:** Celery 5.4.0 + Celery Beat
- **AI/ML:** LangChain 0.3.9, LlamaIndex, Multi-LLM providers
- **Auth:** Firebase authentication
- **Monitoring:** Logfire instrumentation

**Existing Capabilities:**
- 87 API endpoints (61 public, 25 admin)
- 12 database tables (users, sessions, chats, metrics, etc.)
- Multi-LLM chat with character profiles
- Background task processing
- Push notifications via Firebase

### New System: Constellation Gamification

**What We're Adding:**
- Breakthrough moment AI detection
- Constellation unlock mechanics
- Progress tracking and visualization
- Weekly reflection system (Phase 2)
- Celestial levels meta-progression (Phase 3)

**Integration Points:**
- Hook into chat message flow (detect breakthroughs)
- Extend user metrics system
- Add new API endpoints under `/api/v1/constellations`
- Use existing Celery for background processing
- Leverage existing Firebase notifications

---

## Architecture Decisions

### Decision 1: Monolith Extension vs Microservice

**Decision:** **Monolith Extension with Modular Design**

**Rationale:**
- ✅ Existing codebase is monolithic (no microservices)
- ✅ Constellation feature tightly coupled to chat (needs message access)
- ✅ Shared database simplifies transactions
- ✅ Lower operational complexity
- ✅ Easier to iterate and develop
- ✅ Can extract later if needed (design with clear boundaries)

**Modularity Strategy:**
- Separate Python package: `app/constellation/`
- Clear service interface (no direct DB access from chat layer)
- Event-driven integration (loose coupling)
- Isolated business logic

**Future Extraction Path:**
- Package is self-contained
- Define API contracts explicitly
- Could become separate FastAPI app sharing same database
- Or migrate to separate database with event sourcing

---

### Decision 2: Database Integration Strategy

**Decision:** **Hybrid Schema Approach**

**Rationale:**
- ✅ New tables for constellation-specific data
- ✅ Foreign keys to existing tables (user_profile, chats, sessions)
- ✅ Follows existing patterns (user_metrics, nudges also reference user_profile)
- ✅ Allows atomic transactions
- ✅ Simple queries (JOINs vs distributed queries)

**New Tables:**
1. `constellation_library` - Static constellation definitions
2. `user_constellations` - User progress/unlocks
3. `breakthrough_events` - Detection history
4. `weekly_reflections` - Reflection data (Phase 2)
5. `user_constellation_stats` - Aggregated stats

**Existing Table References:**
- FK to `user_profile.id` (ON DELETE CASCADE)
- FK to `chats.id` (breakthrough anchoring)
- FK to `sessions.id` (conversation context)

---

### Decision 3: Breakthrough Detection Architecture

**Decision:** **Dual-Mode Detection (Real-Time + Post-Analysis)**

**Real-Time Mode:**
- **Trigger:** After chat message save (hook in endpoint)
- **Method:** Lightweight LangChain prompt (existing infrastructure)
- **Timeout:** 5s max
- **Fallback:** If timeout, skip (post-analysis catches it)

**Post-Analysis Mode:**
- **Trigger:** Session ends (existing session close hook)
- **Method:** Deep analysis of full conversation
- **Timeout:** No hard limit (background task)
- **Purpose:** Catch missed breakthroughs, refine categorization

**Why Both:**
- Real-time = Immediate celebration (magical user experience)
- Post-analysis = Accuracy and completeness (safety net)
- Decoupled = Real-time failure doesn't block chat

---

### Decision 4: Event Architecture

**Decision:** **Direct Service Calls + Firebase Notifications (No Event Bus)**

**Rationale:**
- ❌ Existing codebase has NO event bus (no Redis pub/sub, Kafka, RabbitMQ)
- ✅ Current pattern: Direct Firestore writes for notifications
- ✅ Simpler to maintain (fewer moving parts)
- ✅ Adequate for current scale

**Implementation:**
- Constellation service calls notification service directly
- Use existing `ff_notifications.py` pattern
- Write to Firestore `ff_push_notifications` collection
- Frontend subscribes to Firestore changes

**Future Event Bus (If Needed):**
- Could add Redis pub/sub later
- Would require minimal refactoring (service layer abstraction exists)
- Not needed for MVP

---

### Decision 5: AI Detection Pipeline

**Decision:** **Extend Existing LangChain Integration**

**Leverage Existing:**
- LangChain 0.3.9 (already installed)
- Multi-provider support (OpenAI, Bedrock, Gemini, Mistral)
- Existing prompt templates in `chat/templates.py`
- Existing model initialization in `chat/models.py`

**New Addition:**
- New prompt template: "breakthrough_detection.txt"
- New topic: "breakthrough_detection" in `TOPIC_MODELS`
- Reuse existing async LangChain invocation pattern

**Pipeline Flow:**
```
Chat Message Saved
    ↓
Trigger: analyze_message_for_breakthrough(chat_id, user_id)
    ↓
Load: Message + last 5 messages (context)
    ↓
LangChain: Breakthrough detection prompt
    ↓
Response: {detected: boolean, category: string, confidence: float}
    ↓
If detected + confidence > 0.70:
    ↓
Save: breakthrough_event record
    ↓
Check: Should unlock constellation?
    ↓
Unlock: Award constellation from category
    ↓
Notify: Firebase push notification
```

---

### Decision 6: Caching Strategy

**Decision:** **Redis Caching for Constellation Library**

**What to Cache:**
- Constellation library (static data, rarely changes)
- User progress stats (invalidate on unlock)
- Category definitions

**Cache Keys:**
```
constellation:library:all          TTL: 1 hour
constellation:library:{category}   TTL: 1 hour
constellation:progress:{user_id}   TTL: 5 minutes
constellation:stats:{user_id}      TTL: 5 minutes
```

**Cache Invalidation:**
- Library: Manual invalidation on data updates (admin operation)
- Progress: Invalidate on constellation unlock
- Stats: Auto-refresh or invalidate on changes

**Leverage Existing:**
- Redis already running (used for Celery broker + cache)
- Use existing redis connection pool
- Follow existing caching patterns (if any in codebase)

---

## Service Architecture

### Package Structure (New)

```
src/ultra-api-aws/app/app/
├── constellation/          # NEW: Self-contained package
│   ├── __init__.py
│   ├── models.py           # SQLAlchemy models
│   ├── schemas.py          # Pydantic schemas
│   ├── service.py          # Business logic
│   ├── detection.py        # AI breakthrough detection
│   └── unlock.py           # Unlock logic
├── api/api_v1/endpoints/
│   └── constellation.py    # NEW: REST endpoints
├── db/
│   ├── constellation.py    # NEW: Constellation model (or add to constellation/ package)
│   └── constellation_progress.py  # NEW: Progress model
└── background/
    └── worker.py           # MODIFY: Add constellation tasks
```

**Design Pattern:** Feature-based packaging
- All constellation logic in one place
- Easy to find and modify
- Can be extracted as package later

**Alternative (Simpler):**
Follow existing flat structure:
```
app/db/constellation.py          # Models
app/schemas/schemas.py           # Add constellation schemas
app/service/constellation_service.py  # Service logic
app/api/api_v1/endpoints/constellation.py  # Endpoints
background/worker.py             # Add tasks
```

**Recommendation:** Use simpler flat structure to match existing patterns.

---

### Service Layer Design

**constellation_service.py** (New File)

**Responsibilities:**
- Constellation unlock logic
- Progress calculation
- Category completion detection
- Celestial tier unlocks (Phase 3)

**Key Functions:**
```python
# app/service/constellation_service.py

async def check_and_unlock_constellation(
    user_id: str,
    category: str,
    unlock_type: str,
    context: dict
) -> Optional[ConstellationUnlock]:
    """
    Idempotent constellation unlock

    Returns:
        ConstellationUnlock if new unlock, None if no unlocks available
    """
    # 1. Check available constellations in category
    # 2. Select random unlocked constellation
    # 3. Create user_constellation record (idempotent)
    # 4. Update stats
    # 5. Trigger notification
    # 6. Return unlock details

async def get_user_constellation_sky(user_id: str) -> ConstellationSkyResponse:
    """Get all user's unlocked constellations with details"""

async def get_constellation_progress(user_id: str) -> ProgressStats:
    """Get user's overall progress stats"""

async def detect_category_completion(user_id: str, category: str) -> bool:
    """Check if user completed all constellations in category"""

async def link_constellation_to_breakthrough(
    user_constellation_id: str,
    chat_id: str,
    session_id: str
) -> None:
    """Create breakthrough anchor link"""
```

**Follows Existing Pattern:**
- Async functions (not classes)
- Uses `get_db().session` for database access
- Returns Pydantic schemas
- Error handling with exceptions

---

### Breakthrough Detection Service

**constellation/detection.py** (New File or add to service)

**Responsibilities:**
- AI-powered breakthrough analysis
- Category classification
- Confidence scoring

**Key Functions:**
```python
async def analyze_message_for_breakthrough(
    message: str,
    conversation_context: List[str],
    user_id: str
) -> BreakthroughDetectionResult:
    """
    Uses LangChain to detect breakthrough moments

    Returns:
        - detected: boolean
        - category: emotion | courage | presence
        - confidence: 0.0 - 1.0
        - insight_summary: string
    """
    # 1. Construct prompt with context
    # 2. Call LangChain (existing integration)
    # 3. Parse response
    # 4. Return structured result

async def classify_breakthrough_category(
    message: str,
    context: List[str]
) -> tuple[str, float]:
    """Determine category (emotion/courage/presence) with confidence"""
```

**LangChain Integration:**
- Use existing `initialize_language_model()` from `chat/models.py`
- Add "breakthrough_detection" topic to `TOPIC_MODELS`
- Create prompt template (JSON output format for parsing)

---

## Data Architecture

### Database Schema

**Following Existing Patterns:**
- Use `Column(JSON)` for flexible metadata (like `user_metrics.metric_data`)
- Foreign keys with `ON DELETE CASCADE`
- Standalone async CRUD functions (not class methods)
- Relationships with `back_populates`

**New Tables (5):**

#### 1. constellation_library
```python
# app/db/constellation.py

from app.db.base_class import Base
from sqlalchemy import Column, Integer, String, Text, Boolean, JSON, DateTime
from datetime import datetime

class ConstellationLibrary(Base):
    __tablename__ = "constellation_library"

    id = Column(Integer, primary_key=True, autoincrement=True)
    constellation_key = Column(String(50), unique=True, nullable=False)
    name = Column(String(100), nullable=False)
    category = Column(String(20), nullable=False)  # emotion, courage, presence
    mythology_short = Column(Text)
    mythology_full = Column(Text)  # Phase 2
    sort_order = Column(Integer)
    is_active = Column(Boolean, default=True)  # MVP subset flag
    is_hybrid = Column(Boolean, default=False)
    required_categories = Column(JSON)  # For hybrid constellations
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

# CRUD Functions (following existing pattern)
async def get_constellation_by_key(constellation_key: str):
    result = await get_db().session.execute(
        select(ConstellationLibrary).where(
            ConstellationLibrary.constellation_key == constellation_key
        )
    )
    return result.scalar_one_or_none()

async def get_active_constellations(category: str = None):
    query = select(ConstellationLibrary).where(
        ConstellationLibrary.is_active == True
    )
    if category:
        query = query.where(ConstellationLibrary.category == category)
    result = await get_db().session.execute(query)
    return result.scalars().all()
```

#### 2. user_constellations
```python
# app/db/constellation_progress.py

class UserConstellation(Base):
    __tablename__ = "user_constellations"

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_profile_id = Column(Integer, ForeignKey("user_profile.id", ondelete="CASCADE"), nullable=False)
    constellation_id = Column(Integer, ForeignKey("constellation_library.id"), nullable=False)

    # Unlock details
    unlocked_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    unlock_type = Column(String(20), nullable=False)  # breakthrough, reflection, manual
    rarity_tier = Column(String(20), default="common")

    # Evolution (Phase 2)
    evolution_stage = Column(Integer, default=1)
    stage_2_unlocked_at = Column(DateTime)
    stage_3_unlocked_at = Column(DateTime)
    revisit_count = Column(Integer, default=0)

    # Breakthrough anchor
    breakthrough_chat_id = Column(Integer, ForeignKey("chats.id"))
    breakthrough_session_id = Column(Integer, ForeignKey("sessions.id"))

    # Reflection anchor (Phase 2)
    reflection_id = Column(Integer)

    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    user_profile = relationship("UserProfile", back_populates="constellations")
    constellation = relationship("ConstellationLibrary")
    breakthrough_chat = relationship("Chat")

    __table_args__ = (
        UniqueConstraint('user_profile_id', 'constellation_id', name='uq_user_constellation'),
    )

# CRUD
async def unlock_constellation_for_user(
    user_profile_id: int,
    constellation_id: int,
    unlock_type: str,
    context: dict
):
    """Idempotent constellation unlock"""
    # Check if already unlocked
    existing = await get_user_constellation(user_profile_id, constellation_id)
    if existing:
        return existing  # Already unlocked, return existing

    # Create new unlock
    user_const = UserConstellation(
        user_profile_id=user_profile_id,
        constellation_id=constellation_id,
        unlock_type=unlock_type,
        rarity_tier=context.get('rarity_tier', 'common'),
        breakthrough_chat_id=context.get('chat_id'),
        breakthrough_session_id=context.get('session_id'),
    )

    get_db().session.add(user_const)
    await get_db().session.commit()
    await get_db().session.refresh(user_const)

    return user_const
```

#### 3. breakthrough_events
```python
class BreakthroughEvent(Base):
    __tablename__ = "breakthrough_events"

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_profile_id = Column(Integer, ForeignKey("user_profile.id", ondelete="CASCADE"))
    session_id = Column(Integer, ForeignKey("sessions.id"))
    chat_id = Column(Integer, ForeignKey("chats.id"))

    detected_at = Column(DateTime, default=datetime.utcnow)
    detection_type = Column(String(20), nullable=False)  # real_time, post_analysis, manual
    category = Column(String(20), nullable=False)
    confidence_score = Column(Numeric(3, 2))

    insight_summary = Column(Text)
    emotional_indicators = Column(JSON)

    user_confirmed = Column(Boolean)
    user_marked = Column(Boolean, default=False)

    constellation_unlocked_id = Column(Integer, ForeignKey("user_constellations.id"))

    created_at = Column(DateTime, default=datetime.utcnow)
```

#### 4. user_constellation_stats
```python
class UserConstellationStats(Base):
    __tablename__ = "user_constellation_stats"

    user_profile_id = Column(Integer, ForeignKey("user_profile.id", ondelete="CASCADE"), primary_key=True)

    total_unlocked = Column(Integer, default=0)
    emotion_count = Column(Integer, default=0)
    courage_count = Column(Integer, default=0)
    presence_count = Column(Integer, default=0)

    emotion_complete = Column(Boolean, default=False)
    courage_complete = Column(Boolean, default=False)
    presence_complete = Column(Boolean, default=False)

    common_count = Column(Integer, default=0)
    rare_count = Column(Integer, default=0)
    epic_count = Column(Integer, default=0)
    legendary_count = Column(Integer, default=0)

    celestial_tier = Column(Integer, default=0)

    first_unlock_at = Column(DateTime)
    last_unlock_at = Column(DateTime)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
```

**Auto-Update via Database Triggers:**
```sql
-- Trigger to auto-update stats on constellation unlock
CREATE OR REPLACE FUNCTION update_constellation_stats()
RETURNS TRIGGER AS $$
BEGIN
    -- Update or insert stats
    INSERT INTO user_constellation_stats (
        user_profile_id,
        total_unlocked,
        last_unlock_at
    )
    VALUES (NEW.user_profile_id, 1, NEW.unlocked_at)
    ON CONFLICT (user_profile_id) DO UPDATE
    SET
        total_unlocked = user_constellation_stats.total_unlocked + 1,
        last_unlock_at = NEW.unlocked_at,
        updated_at = NOW();

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_update_constellation_stats
AFTER INSERT ON user_constellations
FOR EACH ROW
EXECUTE FUNCTION update_constellation_stats();
```

**Migration File:**
- Create Alembic migration: `alembic revision --autogenerate -m "Add constellation gamification tables"`
- Will be migration #14 (currently at #13)

---

### Database Indexes (Performance)

**Critical Indexes:**
```sql
-- user_constellations (high read/write)
CREATE INDEX idx_user_const_user ON user_constellations(user_profile_id);
CREATE INDEX idx_user_const_unlocked ON user_constellations(unlocked_at DESC);
CREATE INDEX idx_user_const_chat ON user_constellations(breakthrough_chat_id);

-- breakthrough_events (analytical queries)
CREATE INDEX idx_breakthrough_user ON breakthrough_events(user_profile_id);
CREATE INDEX idx_breakthrough_detected ON breakthrough_events(detected_at DESC);
CREATE INDEX idx_breakthrough_category ON breakthrough_events(category);

-- constellation_library (read-heavy, cache in Redis)
CREATE INDEX idx_constellation_category ON constellation_library(category);
CREATE INDEX idx_constellation_active ON constellation_library(is_active);
```

---

## API Design

### Endpoint Organization

**Following Existing Pattern:**
- Add to `/app/api/api_v1/endpoints/constellation.py`
- Register in `/app/api/api_v1/api.py`
- Use existing auth dependencies (`validate_token`, `get_current_user`)

### Endpoints (Phase 1 MVP)

**1. GET /api/v1/constellations/library**
```python
# app/api/api_v1/endpoints/constellation.py

from fastapi import APIRouter, Depends, HTTPException, Query
from app.api.deps import validate_token, get_current_user
from app.service.constellation_service import get_constellation_library

router = APIRouter()

@router.get("/library", dependencies=[Depends(validate_token)])
async def get_available_constellations(
    category: Optional[str] = Query(None, regex="^(emotion|courage|presence)$"),
    unlocked_only: bool = Query(False),
    currentUserId: str = Depends(get_current_user)
):
    """
    Get constellation library with user's unlock status

    Query Params:
        category: Filter by category (optional)
        unlocked_only: Show only unlocked constellations

    Response:
        - constellations: List of constellation objects with is_unlocked status
        - stats: Category counts
    """
    library = await get_constellation_library(
        user_id=currentUserId,
        category=category,
        unlocked_only=unlocked_only
    )

    return {
        "constellations": library.constellations,
        "stats": library.stats
    }
```

**2. GET /api/v1/constellations/sky**
```python
@router.get("/sky", dependencies=[Depends(validate_token)])
async def get_user_constellation_sky(
    currentUserId: str = Depends(get_current_user)
):
    """
    Get user's complete constellation sky (all unlocked)

    Returns:
        - constellations: User's unlocked constellations with details
        - progress: Category counts and completion percentage
    """
    sky_data = await get_user_constellation_sky(currentUserId)
    return sky_data
```

**3. POST /api/v1/constellations/breakthrough/mark**
```python
from app.api.api_v1.endpoints.models.constellation_data import MarkBreakthroughRequest

@router.post("/breakthrough/mark", dependencies=[Depends(validate_token)])
async def mark_breakthrough_moment(
    request: MarkBreakthroughRequest,
    currentUserId: str = Depends(get_current_user)
):
    """
    User manually marks a chat message as breakthrough

    Request Body:
        - chat_id: UUID of meaningful message
        - category: Optional category override
        - note: Optional user note

    Response:
        - breakthrough_id: Created event ID
        - constellation_unlocked: Unlock details if triggered
        - status: breakthrough_recorded | constellation_unlocked
    """
    result = await mark_user_breakthrough(
        user_id=currentUserId,
        chat_id=request.chat_id,
        category=request.category,
        note=request.note
    )

    return result
```

**4. GET /api/v1/constellations/progress**
```python
@router.get("/progress", dependencies=[Depends(validate_token)])
async def get_constellation_progress(
    currentUserId: str = Depends(get_current_user)
):
    """Get user's overall progress and stats"""
    progress = await get_user_constellation_progress(currentUserId)
    return progress
```

**5. POST /admin/constellations/unlock** (Admin only)
```python
from app.api.deps import get_current_user_from_admin

@router.post("/admin/unlock", dependencies=[Depends(validate_token)])
async def admin_unlock_constellation(
    request: AdminUnlockRequest,
    currentUserId: str = Depends(get_current_user_from_admin)
):
    """Admin tool to manually unlock constellation for testing/support"""
    # Verify admin role
    # Perform unlock
    # Log audit trail
```

### Pydantic Request/Response Models

**constellation_data.py** (New File)

```python
# app/api/api_v1/endpoints/models/constellation_data.py

from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime

class MarkBreakthroughRequest(BaseModel):
    chat_id: int = Field(..., description="Chat message ID")
    category: Optional[str] = Field(None, regex="^(emotion|courage|presence)$")
    note: Optional[str] = Field(None, max_length=500)

class ConstellationSchema(BaseModel):
    id: int
    constellation_key: str
    name: str
    category: str
    mythology_short: str
    is_unlocked: bool = False
    unlocked_at: Optional[datetime] = None

    class Config:
        from_attributes = True

class ConstellationSkyResponse(BaseModel):
    constellations: List[ConstellationSchema]
    progress: dict

class BreakthroughResponse(BaseModel):
    breakthrough_id: int
    constellation_unlocked: Optional[dict] = None
    status: str  # "breakthrough_recorded" | "constellation_unlocked"
```

---

## Integration Architecture

### Chat Message Flow Integration

**Existing Flow:**
```
User sends message → POST /chats
    ↓
Save to database (Chat model)
    ↓
Call LangChain for AI response
    ↓
Save AI response to database
    ↓
Return response to user
```

**New Flow (With Breakthrough Detection):**
```
User sends message → POST /chats
    ↓
Save to database (Chat model)
    ↓
[NEW] Trigger: analyze_message_for_breakthrough (async, non-blocking)
    ↓
Call LangChain for AI response (existing)
    ↓
Save AI response to database
    ↓
Return response to user
    ║
    ║ (Background task completes)
    ↓
[NEW] If breakthrough detected:
    Save breakthrough_event
    Check unlock eligibility
    Award constellation if applicable
    Send Firebase notification
```

**Integration Point:**
- **File:** `/app/api/api_v1/endpoints/chat.py` (existing)
- **Hook:** After chat message save, before response
- **Method:** `background_tasks.add_task(analyze_breakthrough, chat.id, user_id)`
- **Non-blocking:** Uses FastAPI BackgroundTasks

**Code Addition:**
```python
# In chat endpoint
from app.service.constellation_service import trigger_breakthrough_analysis

@router.post("/", dependencies=[Depends(validate_token)])
async def create_chat_message(
    request: ChatRequest,
    background_tasks: BackgroundTasks,  # FastAPI feature
    currentUserId: str = Depends(get_current_user)
):
    # ... existing chat logic ...

    # Save message
    chat = await create_chat(message_data)

    # [NEW] Trigger breakthrough analysis (non-blocking)
    background_tasks.add_task(
        trigger_breakthrough_analysis,
        chat_id=chat.id,
        user_id=currentUserId
    )

    # ... continue with AI response generation ...

    return response
```

---

### Session End Integration

**Existing Pattern:**
- Session close endpoint exists
- Can hook into session state change

**Integration:**
```python
# When session closes
@router.post("/sessions/{session_id}/close", ...)
async def close_session(session_id: int, ...):
    # ... existing close logic ...

    # [NEW] Trigger post-conversation analysis
    background_tasks.add_task(
        analyze_completed_session,
        session_id=session_id
    )

    return response
```

---

### Metrics System Integration

**Existing:** `user_metrics` table with `metric_type` and `metric_data` (JSON)

**Integration Strategy:**
Add constellation metrics to existing system:
```python
# New metric types (stored in ref_data or hardcoded)
CONSTELLATION_METRICS = [
    "constellations_total",
    "constellations_emotion",
    "constellations_courage",
    "constellations_presence",
    "breakthroughs_detected",
    "reflections_submitted",
]

# Reuse existing metric_service.py patterns
async def update_constellation_metric(user_profile_id: int, metric_type: str, value: int):
    await update_metric(user_profile_id, metric_type, value)
```

**Benefits:**
- Consistent with existing metrics dashboard
- No new infrastructure
- Existing analytics capture constellation progress

---

## AI Pipeline

### Breakthrough Detection Pipeline

**Architecture:**
```
Chat Message → Detection Service → LangChain → Classification → Unlock Service
```

**Step-by-Step:**

**1. Message Received**
- Endpoint: POST /chats (existing)
- Triggered via `background_tasks.add_task()`

**2. Context Assembly**
```python
async def assemble_detection_context(chat_id: int):
    """Get message + recent conversation history"""
    current_message = await get_chat_by_id(chat_id)
    recent_messages = await get_recent_messages(
        session_id=current_message.session_id,
        limit=5
    )
    return {
        "current": current_message.message,
        "context": [msg.message for msg in recent_messages]
    }
```

**3. LangChain Detection**
```python
from app.chat.models import initialize_language_model
from langchain_core.prompts import PromptTemplate

async def detect_breakthrough(message: str, context: List[str]) -> dict:
    """
    Uses existing LangChain infrastructure
    """
    # Build prompt
    prompt_template = """
    Analyze this conversation message for therapeutic breakthrough moments.

    Recent context:
    {context}

    Current message:
    {message}

    Detect if this is a breakthrough moment (genuine insight, emotional awareness, courageous vulnerability, mindful presence).

    Respond in JSON:
    {{
        "is_breakthrough": true/false,
        "category": "emotion" | "courage" | "presence",
        "confidence": 0.0-1.0,
        "insight_summary": "What the user realized"
    }}
    """

    prompt = PromptTemplate(
        input_variables=["context", "message"],
        template=prompt_template
    )

    # Use existing model initialization
    llm = initialize_language_model("breakthrough_detection")

    chain = prompt | llm | StrOutputParser()
    result = await chain.ainvoke({
        "context": "\n".join(context),
        "message": message
    })

    # Parse JSON response
    return json.loads(result)
```

**4. Decision Logic**
```python
async def process_breakthrough_detection(detection_result: dict, chat_id: int, user_id: str):
    """Handle detection result"""
    if not detection_result["is_breakthrough"]:
        return None  # No action

    if detection_result["confidence"] < 0.70:
        return None  # Confidence too low

    # Save breakthrough event
    breakthrough = await save_breakthrough_event(
        user_id=user_id,
        chat_id=chat_id,
        category=detection_result["category"],
        confidence=detection_result["confidence"],
        insight=detection_result["insight_summary"]
    )

    # Check unlock eligibility
    unlock_result = await check_and_unlock_constellation(
        user_id=user_id,
        category=detection_result["category"],
        unlock_type="breakthrough",
        context={
            "chat_id": chat_id,
            "breakthrough_id": breakthrough.id
        }
    )

    if unlock_result:
        # Send notification
        await notify_constellation_unlock(user_id, unlock_result)

    return unlock_result
```

**LLM Provider Selection:**
- Use existing topic-based routing
- Default: Gemini 2.5 (fast, cost-effective)
- Fallback: OpenAI GPT-4 if Gemini unavailable
- Configured in `chat/models.py TOPIC_MODELS`

---

## Background Processing

### Celery Tasks (Add to worker.py)

**Following Existing Pattern:**
```python
# background/worker.py

from celery import Celery
from background.util.sync import sync
from app.db.db import init_db

# [NEW TASK 1] Real-time breakthrough analysis
@celery.task(
    name="analyze_message_for_breakthrough",
    retry_backoff=5,
    autoretry_for=(Exception,),
    max_retries=3,
    retry_backoff_max=60
)
@sync
async def analyze_message_for_breakthrough_task(chat_id: int, user_id: str):
    """Real-time breakthrough detection"""
    async with init_db():  # CRITICAL: Database context
        from app.service.constellation_service import analyze_breakthrough
        await analyze_breakthrough(chat_id, user_id)

# [NEW TASK 2] Post-conversation analysis
@celery.task(
    name="analyze_completed_session",
    retry_backoff=10,
    autoretry_for=(Exception,),
    max_retries=3
)
@sync
async def analyze_completed_session_task(session_id: int):
    """Deep analysis after session ends"""
    async with init_db():
        from app.service.constellation_service import deep_session_analysis
        await deep_session_analysis(session_id)

# [NEW TASK 3] Progress recalculation (maintenance)
@celery.task(name="recalculate_constellation_stats")
@sync
async def recalculate_constellation_stats_task(user_id: str):
    """Recalculate user's constellation stats"""
    async with init_db():
        from app.service.constellation_service import recalculate_stats
        await recalculate_stats(user_id)
```

**Task Invocation (from endpoints):**
```python
# Option 1: FastAPI BackgroundTasks (lightweight, no retry)
background_tasks.add_task(analyze_breakthrough, chat_id, user_id)

# Option 2: Celery task (with retry, for critical operations)
from background.worker import analyze_message_for_breakthrough_task
analyze_message_for_breakthrough_task.delay(chat_id, user_id)
```

**Recommendation:** Use FastAPI BackgroundTasks for real-time (fast, simple), Celery for post-analysis (retry needed).

---

### Scheduled Tasks (Optional - Phase 2)

**Add to beat.py** (if weekly reflection prompts needed):
```python
# background/beat.py

@celery.on_after_configure.connect
def setup_constellation_tasks(sender: Celery, **kwargs):
    # Weekly reflection prompts (every Sunday 9am)
    sender.add_periodic_task(
        crontab(day_of_week=0, hour=9, minute=0),  # Sunday 9am
        send_weekly_reflection_prompts_task.s(),
        name='weekly_reflection_prompts'
    )
```

---

## Event Flow

### Real-Time Unlock Notification Flow

**Architecture:**
```
Constellation Unlocked
    ↓
constellation_service.unlock_constellation()
    ↓
Save to database (user_constellations table)
    ↓
Trigger: update_constellation_stats (DB trigger)
    ↓
Call: notify_constellation_unlock(user_id, constellation_data)
    ↓
Write to Firestore: ff_push_notifications collection
    ↓
Firebase Cloud Messaging → Flutter app
    ↓
Show unlock celebration modal in app
```

**Implementation (Following Existing Pattern):**
```python
# app/service/constellation_service.py

from app.integrations.ff_notifications import notify_current_user

async def notify_constellation_unlock(user_id: str, constellation: dict):
    """Send push notification for constellation unlock"""
    user = await UserProfile.get_user(user_id)

    notification_data = {
        "notification_title": "New Constellation Unlocked!",
        "notification_text": f"You've unlocked {constellation['name']} 🌟",
        "notification_type": "constellation_unlock",
        "data": {
            "constellation_id": constellation['id'],
            "category": constellation['category'],
            "action": "open_constellation_detail"
        }
    }

    # Use existing notification infrastructure
    await notify_current_user_custom(user, notification_data)
```

**No New Infrastructure:**
- Reuses existing Firestore notifications
- No Redis pub/sub needed
- No WebSocket needed
- Simpler = fewer failure modes

---

## Security Architecture

### Authentication & Authorization

**Leverage Existing:**
- Firebase JWT tokens (`validate_token` dependency)
- User context via `get_current_user`
- Admin role checking (for admin endpoints)

**Constellation-Specific Security:**

**1. Data Access Control**
```python
async def verify_constellation_ownership(user_id: str, constellation_unlock_id: int):
    """Ensure user can only access their own constellations"""
    const = await get_user_constellation(constellation_unlock_id)
    if const.user_profile_id != user_id:
        raise HTTPException(status_code=403, detail="Access denied")
    return const
```

**2. Rate Limiting (Manual Breakthrough Marking)**
```python
# Prevent abuse (users spamming breakthrough marks)
from app.core.rate_limiting import check_rate_limit

@router.post("/breakthrough/mark", ...)
async def mark_breakthrough_moment(...):
    # Check rate limit: 10 marks per hour
    await check_rate_limit(
        user_id=currentUserId,
        action="mark_breakthrough",
        limit=10,
        window=3600
    )
    # ... proceed with marking
```

**3. Sensitive Data Protection**
- Breakthrough data contains vulnerable moments
- Ensure logs don't leak breakthrough text
- GDPR: Include constellation data in user export
- Data retention: Keep breakthrough events for analytics (anonymize after 90 days)

---

## Deployment Architecture

### No Changes Required

**Existing Deployment:**
- Docker + Docker Compose
- Gunicorn + Uvicorn workers
- PostgreSQL container
- Redis container
- Celery worker container

**Constellation Feature Deployment:**
- Add migrations to existing Alembic workflow
- No new containers needed
- No new environment variables (reuses existing DB/Redis)
- Same deployment process

**Migration Deployment:**
```bash
# Run migration
alembic upgrade head

# Seed constellation library data
python scripts/seed_constellations.py

# Restart services
docker-compose restart api worker
```

---

## Migration Strategy

### Phase 1: MVP Rollout

**Step 1: Database Migration**
```bash
# Create migration
alembic revision --autogenerate -m "Add constellation gamification tables"

# Review migration file
# Edit if needed (triggers, indexes)

# Apply migration
alembic upgrade head
```

**Step 2: Seed Data**
```python
# scripts/seed_constellations.py

MVP_CONSTELLATIONS = [
    # Emotion (12 constellations - 40%)
    {"key": "pisces", "name": "Pisces", "category": "emotion", "mythology": "..."},
    {"key": "cancer", "name": "Cancer", "category": "emotion", "mythology": "..."},
    # ... (10 more)

    # Courage (9 constellations - 30%)
    {"key": "leo", "name": "Leo", "category": "courage", "mythology": "..."},
    {"key": "aries", "name": "Aries", "category": "courage", "mythology": "..."},
    # ... (7 more)

    # Presence (9 constellations - 30%)
    {"key": "libra", "name": "Libra", "category": "presence", "mythology": "..."},
    # ... (8 more)
]

async def seed_constellation_library():
    for const_data in MVP_CONSTELLATIONS:
        await create_constellation(const_data)
```

**Step 3: Deploy Code**
- Add new files (models, services, endpoints, tasks)
- Update existing files (chat endpoint hook)
- Deploy via existing CI/CD (GitHub Actions)

**Step 4: Feature Flag (Optional)**
```python
# app/core/config.py
CONSTELLATION_FEATURE_ENABLED = os.getenv("CONSTELLATION_ENABLED", "false") == "true"

# In endpoints
if not CONSTELLATION_FEATURE_ENABLED:
    raise HTTPException(status_code=404, detail="Feature not available")
```

**Gradual Rollout:**
1. Deploy with feature flag OFF
2. Test on staging environment
3. Enable for 10% of users (beta test)
4. Monitor metrics (breakthrough detection rate, errors)
5. Full rollout if metrics positive

---

## Performance Considerations

### Caching Strategy

**What to Cache (Redis):**
```python
# Constellation library (static, read-heavy)
CACHE_KEY = f"constellation:library:{category}"
TTL = 3600  # 1 hour

# User progress (dynamic, but read often)
CACHE_KEY = f"constellation:progress:{user_id}"
TTL = 300  # 5 minutes

# Invalidation
# - Library: Manual (on admin update)
# - Progress: On constellation unlock
```

**Implementation:**
```python
from app.core.redis_client import get_redis

async def get_cached_constellation_library(category: str = None):
    cache_key = f"constellation:library:{category or 'all'}"

    # Try cache first
    cached = await get_redis().get(cache_key)
    if cached:
        return json.loads(cached)

    # Cache miss - query database
    library = await get_active_constellations(category)

    # Store in cache
    await get_redis().setex(
        cache_key,
        3600,  # 1 hour TTL
        json.dumps([c.to_dict() for c in library])
    )

    return library
```

### Database Query Optimization

**1. Index Usage:**
- All foreign keys have indexes
- Composite index on (user_profile_id, unlocked_at DESC) for recent unlocks

**2. Pagination:**
```python
# For large result sets (88+ constellations)
@router.get("/library")
async def get_library(
    skip: int = Query(0, ge=0),
    limit: int = Query(50, le=100)
):
    constellations = await get_constellations_paginated(skip, limit)
    return constellations
```

**3. Eager Loading:**
```python
# Avoid N+1 queries
query = select(UserConstellation).options(
    joinedload(UserConstellation.constellation),
    joinedload(UserConstellation.breakthrough_chat)
)
```

---

## Monitoring & Observability

### Metrics to Track (Logfire)

**Leverage Existing Logfire:**
```python
import logfire

# In breakthrough detection
with logfire.span("breakthrough_detection"):
    logfire.info("Analyzing message", chat_id=chat_id)
    result = await detect_breakthrough(message)
    logfire.info("Detection complete",
                 detected=result["is_breakthrough"],
                 confidence=result["confidence"])

# In unlock logic
with logfire.span("constellation_unlock"):
    unlock = await unlock_constellation(user_id, category)
    logfire.info("Constellation unlocked",
                 user_id=user_id,
                 constellation=unlock.constellation.name)
```

**Key Metrics:**
- `breakthrough_detection.latency` - How long detection takes
- `breakthrough_detection.rate` - How many per day
- `constellation_unlock.rate` - Unlock frequency
- `constellation_api.response_time` - Endpoint performance

**Alerts:**
- Breakthrough detection latency > 5s (P95)
- Unlock failure rate > 1%
- API error rate > 5%

---

## File Organization Summary

### New Files to Create

```
src/ultra-api-aws/app/app/
├── db/
│   ├── constellation.py              # ConstellationLibrary model
│   └── constellation_progress.py     # UserConstellation, BreakthroughEvent models
├── service/
│   └── constellation_service.py      # Business logic
├── api/api_v1/endpoints/
│   ├── constellation.py              # REST endpoints
│   └── models/
│       └── constellation_data.py     # Pydantic request/response models
└── chat/
    └── templates/
        └── breakthrough_detection.txt # LangChain prompt template

background/
└── worker.py                         # MODIFY: Add constellation tasks

scripts/
└── seed_constellations.py            # NEW: Seed MVP constellation data

alembic/versions/
└── xxx_add_constellation_tables.py   # NEW: Migration file
```

**Total New Files:** 7
**Modified Files:** 3 (worker.py, chat endpoint, api router)

---

## Architecture Diagrams

### System Context Diagram

```
┌─────────────────────────────────────────────────────┐
│                  Jaimee Mobile App                  │
│                   (Flutter - iOS/Android)           │
└────────┬────────────────────────────────┬───────────┘
         │                                │
         │ REST API                       │ Firebase
         │ (Constellations)               │ (Push Notifications)
         │                                │
┌────────▼────────────────────────────────▼───────────┐
│                                                      │
│            Ultra API AWS (FastAPI)                   │
│  ┌─────────────────────────────────────────────┐   │
│  │  Constellation Service (NEW)                 │   │
│  │  - Breakthrough detection                    │   │
│  │  - Unlock logic                              │   │
│  │  - Progress tracking                         │   │
│  └───┬──────────────────────┬───────────────────┘   │
│      │                      │                        │
│  ┌───▼────────┐        ┌───▼────────┐              │
│  │ Chat       │        │ Metrics    │              │
│  │ Service    │        │ Service    │              │
│  │ (Existing) │        │ (Existing) │              │
│  └───┬────────┘        └────────────┘              │
│      │                                               │
│  ┌───▼──────────────────────────────────────────┐   │
│  │        PostgreSQL Database                    │   │
│  │  - Existing tables (chats, users, sessions)   │   │
│  │  - New tables (constellations, progress)      │   │
│  └───────────────────────────────────────────────┘   │
│                                                      │
│  ┌────────────────────────────────────────────────┐ │
│  │  Celery Worker (Background Tasks)             │ │
│  │  - Breakthrough analysis                       │ │
│  │  - Post-conversation deep analysis             │ │
│  └────────────────────────────────────────────────┘ │
│                                                      │
│  ┌────────────────────────────────────────────────┐ │
│  │  Redis (Cache + Celery Broker)                │ │
│  │  - Constellation library cache                 │ │
│  │  - Task queue                                  │ │
│  └────────────────────────────────────────────────┘ │
│                                                      │
└──────────────────────────────────────────────────────┘
         │
         │ LangChain
         │
┌────────▼────────────────────────┐
│  AI Providers (Existing)        │
│  - OpenAI, Bedrock, Gemini      │
└─────────────────────────────────┘
```

### Breakthrough Detection Sequence

```
sequenceDiagram
    participant User
    participant Flutter App
    participant FastAPI
    participant BackgroundTask
    participant LangChain
    participant Database
    participant Firebase

    User->>Flutter App: Send chat message
    Flutter App->>FastAPI: POST /chats
    FastAPI->>Database: Save chat message
    FastAPI->>BackgroundTask: Trigger breakthrough analysis (async)
    FastAPI-->>Flutter App: Return chat response (immediate)

    BackgroundTask->>Database: Load message + context
    BackgroundTask->>LangChain: Analyze for breakthrough
    LangChain-->>BackgroundTask: Detection result

    alt Breakthrough Detected (confidence > 0.70)
        BackgroundTask->>Database: Save breakthrough_event
        BackgroundTask->>Database: Unlock constellation
        Database->>Database: Trigger: Update stats
        BackgroundTask->>Firebase: Send push notification
        Firebase-->>Flutter App: Constellation unlocked!
        Flutter App->>User: Show celebration modal
    else No Breakthrough
        BackgroundTask->>Database: Log (no action)
    end
```

---

## Risk Mitigation

### Technical Risks

**Risk 1: Breakthrough Detection Latency**
- **Mitigation:** Use lightweight LangChain model (Gemini 2.5 Flash)
- **Fallback:** If >5s, skip real-time, rely on post-analysis
- **Monitoring:** Alert if P95 latency > 5s

**Risk 2: False Positive Breakthrough Detection**
- **Mitigation:** Confidence threshold (0.70)
- **Validation:** User can dismiss false detections
- **Learning:** Track user feedback to refine prompts

**Risk 3: Database Locking on Stats Update**
- **Mitigation:** Use database trigger (atomic)
- **Alternative:** Background task for stats (eventual consistency)
- **Monitoring:** Track lock wait times

**Risk 4: Celery Task Failures**
- **Mitigation:** Retry logic (max 3 retries)
- **Dead Letter Queue:** Log failed tasks
- **Monitoring:** Alert on task failure rate > 5%

---

## Scalability Considerations

### Current Scale: MVP (1,000-10,000 users)

**Database:**
- PostgreSQL handles 10k users easily
- Proper indexes prevent slow queries
- Connection pooling (existing SQLAlchemy async pool)

**Celery:**
- Current worker pool sufficient
- Add workers if queue depth increases
- Monitor queue length

**Redis:**
- Caching reduces DB load
- Existing Redis instance handles additional cache keys

### Future Scale: Growth (100,000+ users)

**If Needed Later:**
- **Read replicas:** For constellation library queries
- **Separate Celery queue:** Dedicated constellation workers
- **Microservice extraction:** Move to separate service
- **CDN:** Cache static constellation images (Phase 2)

**Not Needed Now:**
- ❌ Sharding
- ❌ Message queue (Kafka/RabbitMQ)
- ❌ Separate databases
- ❌ Load balancers (depends on deployment)

---

## Implementation Roadmap

### Phase 1: MVP (Months 1-9)

**Month 1-2: Foundation**
- Create database migration (5 tables)
- Implement models following existing patterns
- Seed constellation library data (20-30 constellations)

**Month 3-4: Core Services**
- constellation_service.py (unlock logic, progress)
- detection.py (LangChain integration)
- Unit tests for business logic

**Month 5-6: API Layer**
- constellation.py endpoints
- Pydantic request/response models
- Integration tests

**Month 7-8: Integration & Testing**
- Hook into chat message flow
- Celery tasks for background processing
- Firebase notification integration
- End-to-end testing

**Month 9: Deployment & Monitoring**
- Deploy to staging
- Beta test with 10% users
- Monitor metrics, tune AI detection
- Full rollout

### Phase 2: Weekly Reflections (Months 10-15)

- Add weekly_reflections table
- Implement reflection depth analysis
- Scheduled Celery Beat tasks
- Reflection submission endpoints

### Phase 3: Celestial Levels (Months 16-24)

- Custom constellation creation UI/API
- Meta-abilities implementation
- Mentor wisdom notes (if desired)

---

## Acceptance Criteria

**Architecture is Complete When:**
- ✅ All integration points clearly defined
- ✅ Database schema designed with migrations
- ✅ Service boundaries established
- ✅ API contracts specified
- ✅ Background processing strategy defined
- ✅ Security model documented
- ✅ Deployment strategy clear
- ✅ Follows existing Ultra API AWS patterns
- ✅ No unnecessary new infrastructure
- ✅ Modular enough for future extraction

---

## References

**Project Documents:**
- PRD: `docs/PRD.md`
- UX Specification: `docs/ux-design-specification.md`
- Brainstorming: `docs/bmm-brainstorming-session-2025-11-07.md`
- Design Spec: `docs/constellation-system-complete-design.md`

**Existing Codebase:**
- Project Documentation: `docs/existing-code-analysis/index.md`
- Source Code: `src/ultra-api-aws/`

**Design Prototypes:**
- `docs/ux-ui/poc-hybrid-card-window.html`
- `docs/ux-ui/poc-full-sky-hybrid-dark.html`

---

## Next Steps

1. **Review & Approve Architecture** - Ensure alignment with technical team
2. **Create Epic Breakdown** - Transform architecture into implementable stories
3. **Solutioning Gate Check** - Validate PRD + UX + Architecture cohesion
4. **Sprint Planning** - Organize stories into sprints
5. **Implementation** - Begin development

---

_This architecture document defines the technical implementation strategy for integrating constellation gamification into the existing Ultra API AWS codebase. It maximizes reuse of existing patterns and infrastructure while maintaining modularity for future flexibility._

_Designed by Winston (Architect) on 2025-11-22 for BMad's jaimee-constellations project._
