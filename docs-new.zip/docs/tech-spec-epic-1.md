# Epic Technical Specification: Foundation & Data Layer

Date: 2025-11-22
Author: BMad
Epic ID: 1
Status: Draft

---

## Overview

Epic 1 establishes the foundational data layer for the Constellation Gamification System, creating the database schema, ORM models, and seed data required for all constellation functionality. This epic implements 5 new PostgreSQL tables that integrate with the existing Ultra API AWS database through foreign key relationships to `user_profile`, `chats`, and `sessions` tables. The foundation enables the core constellation mechanics: tracking which constellations users unlock, recording breakthrough moments that trigger unlocks, and maintaining aggregated progress statistics. This work follows existing codebase patterns (async SQLAlchemy models, Pydantic schemas, standalone CRUD functions) to ensure consistency and maintainability.

Without this foundation, no other constellation features can be implemented. Epic 1 creates the data infrastructure that Epics 2-6 will build upon for AI detection, unlock logic, API endpoints, and user-facing features.

## Objectives and Scope

**In Scope:**

- Create 5 new database tables via Alembic migration (#14)
- Implement SQLAlchemy async ORM models following existing patterns
- Create Pydantic request/response schemas for constellation data
- Build standalone async CRUD functions (not class methods, matching existing style)
- Seed 30 MVP constellations (12 Emotion, 9 Courage, 9 Presence) via Python script
- Implement Redis caching for constellation library (static data, 1-hour TTL)
- Database triggers for auto-updating user_constellation_stats on unlock
- Proper indexing for performance (foreign keys, category filters, date sorting)
- Integration with existing tables via ON DELETE CASCADE foreign keys

**Out of Scope:**

- AI breakthrough detection logic (Epic 2)
- Constellation unlock business logic (Epic 3)
- API endpoints (Epic 4)
- Integration with chat flow (Epic 5)
- Weekly reflection system (Phase 2)
- Multi-stage constellation evolution (Phase 2)
- Celestial levels meta-progression (Phase 3)
- Frontend implementation (separate PRD)

## System Architecture Alignment

This epic aligns with the **Hybrid Schema Approach** defined in the architecture document, extending the existing monolithic PostgreSQL database with new constellation-specific tables while maintaining foreign key relationships to existing tables. The implementation follows the **Modular Design principle**: all new code lives in clearly defined locations (`app/db/constellation.py`, `app/db/constellation_progress.py`, `app/schemas/schemas.py`) to enable future extraction as a microservice if needed.

**Architectural Components Referenced:**
- **Database Layer:** PostgreSQL 13+ with async via asyncpg (existing)
- **ORM Layer:** SQLAlchemy async models inheriting from `Base` (existing pattern)
- **Schema Layer:** Pydantic schemas with `from_attributes=True` for ORM compatibility
- **Caching Layer:** Redis 4.5.5 for constellation library caching (existing infrastructure)
- **Migration Tool:** Alembic (existing workflow)

**Key Constraints:**
- Must use Integer IDs (not UUIDs) to match existing table patterns
- Must use async functions with `get_db().session` for database access (existing pattern)
- Must NOT create class methods on models (existing codebase uses standalone functions)
- Foreign key types must match existing tables (Integer for user_profile.id, chats.id, sessions.id)
- All constellation logic must be self-contained to enable future extraction

## Detailed Design

### Services and Modules

| Module | Responsibilities | Inputs | Outputs | Owner Story |
|--------|-----------------|--------|---------|-------------|
| **constellation.py** | Constellation library model and CRUD operations | Query params (category, key) | Constellation objects, lists | Story 1.2 |
| **constellation_progress.py** | User progress tracking models and CRUD | User ID, constellation ID, unlock context | UserConstellation objects, stats | Story 1.3 |
| **schemas.py** (extended) | Pydantic validation schemas | ORM model instances, API requests | Validated data objects for API layer | Story 1.4 |
| **seed_constellations.py** | Populate constellation library | Constellation definition data (JSON/code) | 30 seeded constellation records | Story 1.5 |
| **Migration #14** | Database schema creation | Alembic upgrade command | 5 new tables + indexes + triggers | Story 1.1 |
| **Redis caching layer** | Cache constellation library queries | Category filter, cache key | Cached constellation data (1hr TTL) | Story 1.6 |

**Key Design Decisions:**
- All database functions are **async** and use `get_db().session` (existing pattern)
- Functions are **standalone** (not class methods) following existing codebase style
- Models inherit from `Base` (existing SQLAlchemy base class)
- CRUD operations are **idempotent** where applicable (e.g., constellation unlock checks for duplicates)

### Data Models and Contracts

#### 1. constellation_library (Reference Data)

**Purpose:** Static library of all available constellations (MVP: 30, Full: 88)

**Table Definition:**
```sql
CREATE TABLE constellation_library (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    constellation_key VARCHAR(50) UNIQUE NOT NULL,  -- e.g., "leo", "pisces"
    name VARCHAR(100) NOT NULL,                      -- Display name "Leo"
    category VARCHAR(20) NOT NULL,                   -- emotion, courage, presence
    mythology_short TEXT,                            -- 1-2 sentences (MVP)
    mythology_full TEXT,                             -- Complete story (Phase 2)
    sort_order INTEGER,                              -- Display ordering
    is_active BOOLEAN DEFAULT true,                  -- MVP subset flag
    is_hybrid BOOLEAN DEFAULT false,                 -- Requires multiple categories (Phase 2)
    required_categories JSON,                        -- For hybrid constellations
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_constellation_category ON constellation_library(category);
CREATE INDEX idx_constellation_active ON constellation_library(is_active);
```

**SQLAlchemy Model (app/db/constellation.py):**
```python
class ConstellationLibrary(Base):
    __tablename__ = "constellation_library"

    id = Column(Integer, primary_key=True, autoincrement=True)
    constellation_key = Column(String(50), unique=True, nullable=False)
    name = Column(String(100), nullable=False)
    category = Column(String(20), nullable=False)
    mythology_short = Column(Text)
    mythology_full = Column(Text)
    sort_order = Column(Integer)
    is_active = Column(Boolean, default=True)
    is_hybrid = Column(Boolean, default=False)
    required_categories = Column(JSON)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
```

**Relationships:** None (reference data table)

---

#### 2. user_constellations (User Progress)

**Purpose:** Track which constellations each user has unlocked and how

**Table Definition:**
```sql
CREATE TABLE user_constellations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_profile_id INTEGER NOT NULL REFERENCES user_profile(id) ON DELETE CASCADE,
    constellation_id INTEGER NOT NULL REFERENCES constellation_library(id),

    -- Unlock details
    unlocked_at TIMESTAMP NOT NULL DEFAULT NOW(),
    unlock_type VARCHAR(20) NOT NULL,                -- breakthrough, reflection, manual
    rarity_tier VARCHAR(20) DEFAULT 'common',        -- common, rare, epic, legendary

    -- Evolution (Phase 2)
    evolution_stage INTEGER DEFAULT 1,               -- 1=stars, 2=lines, 3=glory
    stage_2_unlocked_at TIMESTAMP,
    stage_3_unlocked_at TIMESTAMP,
    revisit_count INTEGER DEFAULT 0,

    -- Breakthrough anchor (if unlocked via breakthrough)
    breakthrough_chat_id INTEGER REFERENCES chats(id),
    breakthrough_session_id INTEGER REFERENCES sessions(id),

    -- Reflection anchor (Phase 2)
    reflection_id INTEGER,

    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),

    CONSTRAINT uq_user_constellation UNIQUE(user_profile_id, constellation_id)
);

CREATE INDEX idx_user_const_user ON user_constellations(user_profile_id);
CREATE INDEX idx_user_const_unlocked ON user_constellations(unlocked_at DESC);
CREATE INDEX idx_user_const_chat ON user_constellations(breakthrough_chat_id);
```

**SQLAlchemy Model (app/db/constellation_progress.py):**
```python
class UserConstellation(Base):
    __tablename__ = "user_constellations"

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_profile_id = Column(Integer, ForeignKey("user_profile.id", ondelete="CASCADE"), nullable=False)
    constellation_id = Column(Integer, ForeignKey("constellation_library.id"), nullable=False)

    unlocked_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    unlock_type = Column(String(20), nullable=False)
    rarity_tier = Column(String(20), default="common")

    evolution_stage = Column(Integer, default=1)
    stage_2_unlocked_at = Column(DateTime)
    stage_3_unlocked_at = Column(DateTime)
    revisit_count = Column(Integer, default=0)

    breakthrough_chat_id = Column(Integer, ForeignKey("chats.id"))
    breakthrough_session_id = Column(Integer, ForeignKey("sessions.id"))
    reflection_id = Column(Integer)

    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    user_profile = relationship("UserProfile", back_populates="constellations")
    constellation = relationship("ConstellationLibrary")
    breakthrough_chat = relationship("Chat")

    __table_args__ = (
        UniqueConstraint('user_profile_id', 'constellation_id', name='uq_user_constellation'),
    )
```

---

#### 3. breakthrough_events (Detection History)

**Purpose:** Record all detected breakthrough moments (AI and manual)

**Table Definition:**
```sql
CREATE TABLE breakthrough_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_profile_id INTEGER NOT NULL REFERENCES user_profile(id) ON DELETE CASCADE,
    session_id INTEGER REFERENCES sessions(id),
    chat_id INTEGER REFERENCES chats(id),

    detected_at TIMESTAMP NOT NULL DEFAULT NOW(),
    detection_type VARCHAR(20) NOT NULL,             -- real_time, post_analysis, manual
    category VARCHAR(20) NOT NULL,                   -- emotion, courage, presence
    confidence_score DECIMAL(3,2),                   -- 0.00-1.00 (AI confidence)

    insight_summary TEXT,                            -- What the AI detected
    emotional_indicators JSON,                       -- Specific markers found

    user_confirmed BOOLEAN,
    user_marked BOOLEAN DEFAULT false,

    constellation_unlocked_id INTEGER REFERENCES user_constellations(id),

    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_breakthrough_user ON breakthrough_events(user_profile_id);
CREATE INDEX idx_breakthrough_session ON breakthrough_events(session_id);
CREATE INDEX idx_breakthrough_chat ON breakthrough_events(chat_id);
CREATE INDEX idx_breakthrough_category ON breakthrough_events(category);
CREATE INDEX idx_breakthrough_detected ON breakthrough_events(detected_at DESC);
```

**SQLAlchemy Model (app/db/constellation_progress.py):**
```python
class BreakthroughEvent(Base):
    __tablename__ = "breakthrough_events"

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_profile_id = Column(Integer, ForeignKey("user_profile.id", ondelete="CASCADE"))
    session_id = Column(Integer, ForeignKey("sessions.id"))
    chat_id = Column(Integer, ForeignKey("chats.id"))

    detected_at = Column(DateTime, default=datetime.utcnow)
    detection_type = Column(String(20), nullable=False)
    category = Column(String(20), nullable=False)
    confidence_score = Column(Numeric(3, 2))

    insight_summary = Column(Text)
    emotional_indicators = Column(JSON)

    user_confirmed = Column(Boolean)
    user_marked = Column(Boolean, default=False)

    constellation_unlocked_id = Column(Integer, ForeignKey("user_constellations.id"))

    created_at = Column(DateTime, default=datetime.utcnow)
```

---

#### 4. user_constellation_stats (Aggregated Progress)

**Purpose:** Fast lookup of user's overall progress (auto-updated via trigger)

**Table Definition:**
```sql
CREATE TABLE user_constellation_stats (
    user_profile_id INTEGER PRIMARY KEY REFERENCES user_profile(id) ON DELETE CASCADE,

    total_unlocked INTEGER DEFAULT 0,
    emotion_count INTEGER DEFAULT 0,
    courage_count INTEGER DEFAULT 0,
    presence_count INTEGER DEFAULT 0,

    emotion_complete BOOLEAN DEFAULT false,
    courage_complete BOOLEAN DEFAULT false,
    presence_complete BOOLEAN DEFAULT false,

    common_count INTEGER DEFAULT 0,
    rare_count INTEGER DEFAULT 0,
    epic_count INTEGER DEFAULT 0,
    legendary_count INTEGER DEFAULT 0,

    stage_2_count INTEGER DEFAULT 0,                 -- Phase 2
    stage_3_count INTEGER DEFAULT 0,                 -- Phase 2

    celestial_tier INTEGER DEFAULT 0,                -- Phase 3 (0=none, 1-3=tier)

    first_unlock_at TIMESTAMP,
    last_unlock_at TIMESTAMP,
    updated_at TIMESTAMP DEFAULT NOW()
);
```

**Database Trigger (Auto-update on constellation unlock):**
```sql
CREATE OR REPLACE FUNCTION update_constellation_stats()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO user_constellation_stats (user_profile_id, total_unlocked, last_unlock_at)
    VALUES (NEW.user_profile_id, 1, NEW.unlocked_at)
    ON CONFLICT (user_profile_id) DO UPDATE
    SET
        total_unlocked = user_constellation_stats.total_unlocked + 1,
        last_unlock_at = NEW.unlocked_at,
        updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_update_constellation_stats
AFTER INSERT ON user_constellations
FOR EACH ROW EXECUTE FUNCTION update_constellation_stats();
```

**SQLAlchemy Model (app/db/constellation_progress.py):**
```python
class UserConstellationStats(Base):
    __tablename__ = "user_constellation_stats"

    user_profile_id = Column(Integer, ForeignKey("user_profile.id", ondelete="CASCADE"), primary_key=True)

    total_unlocked = Column(Integer, default=0)
    emotion_count = Column(Integer, default=0)
    courage_count = Column(Integer, default=0)
    presence_count = Column(Integer, default=0)

    emotion_complete = Column(Boolean, default=False)
    courage_complete = Column(Boolean, default=False)
    presence_complete = Column(Boolean, default=False)

    common_count = Column(Integer, default=0)
    rare_count = Column(Integer, default=0)
    epic_count = Column(Integer, default=0)
    legendary_count = Column(Integer, default=0)

    stage_2_count = Column(Integer, default=0)
    stage_3_count = Column(Integer, default=0)

    celestial_tier = Column(Integer, default=0)

    first_unlock_at = Column(DateTime)
    last_unlock_at = Column(DateTime)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
```

---

#### 5. weekly_reflections (Phase 2 - Schema Only in Epic 1)

**Purpose:** Store weekly reflection submissions and depth analysis

**Note:** Table created in migration but not actively used until Phase 2

**Table Definition:**
```sql
CREATE TABLE weekly_reflections (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_profile_id INTEGER NOT NULL REFERENCES user_profile(id) ON DELETE CASCADE,

    week_start_date DATE NOT NULL,
    week_end_date DATE NOT NULL,
    reflection_text TEXT NOT NULL,
    self_rating INTEGER,                             -- 1-5 stars (user self-assessment)

    ai_quality_score DECIMAL(3,2),                   -- 0.00-1.00
    depth_score DECIMAL(3,2),                        -- 0.00-1.00 (combined metric)
    rarity_tier VARCHAR(20),

    constellations_unlocked JSON,                    -- Array of constellation IDs

    submitted_at TIMESTAMP NOT NULL DEFAULT NOW(),
    analyzed_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW(),

    CONSTRAINT uq_user_week UNIQUE(user_profile_id, week_start_date)
);

CREATE INDEX idx_reflection_user ON weekly_reflections(user_profile_id);
CREATE INDEX idx_reflection_week ON weekly_reflections(week_start_date);
CREATE INDEX idx_reflection_submitted ON weekly_reflections(submitted_at DESC);
```

### APIs and Interfaces

**Note:** Epic 1 creates CRUD functions, NOT REST endpoints (REST APIs are Epic 4)

#### Constellation Library CRUD (app/db/constellation.py)

```python
async def get_constellation_by_key(constellation_key: str) -> Optional[ConstellationLibrary]:
    """Get constellation by unique key"""

async def get_constellation_by_id(constellation_id: int) -> Optional[ConstellationLibrary]:
    """Get constellation by ID"""

async def get_active_constellations(category: str = None) -> List[ConstellationLibrary]:
    """Get all active constellations, optionally filtered by category"""

async def create_constellation(data: dict) -> ConstellationLibrary:
    """Create new constellation (used by seed script)"""

async def update_constellation(constellation_id: int, data: dict) -> ConstellationLibrary:
    """Update constellation metadata (admin operation)"""
```

#### User Progress CRUD (app/db/constellation_progress.py)

```python
async def unlock_constellation_for_user(
    user_profile_id: int,
    constellation_id: int,
    unlock_type: str,
    context: dict
) -> UserConstellation:
    """
    Idempotent constellation unlock

    Args:
        user_profile_id: User's ID
        constellation_id: Constellation to unlock
        unlock_type: "breakthrough" | "reflection" | "manual"
        context: Dict with rarity_tier, chat_id, session_id, etc.

    Returns:
        UserConstellation instance (new or existing)
    """

async def get_user_constellation(
    user_profile_id: int,
    constellation_id: int
) -> Optional[UserConstellation]:
    """Check if user has unlocked specific constellation"""

async def get_user_constellations(
    user_profile_id: int,
    category: str = None
) -> List[UserConstellation]:
    """Get all user's unlocked constellations, optionally filtered by category"""

async def get_constellation_by_chat(chat_id: int) -> Optional[UserConstellation]:
    """Find constellation linked to specific breakthrough message"""

async def save_breakthrough_event(
    user_profile_id: int,
    chat_id: int,
    category: str,
    confidence: float,
    insight: str
) -> BreakthroughEvent:
    """Save detected breakthrough moment"""

async def get_user_breakthroughs(
    user_profile_id: int,
    limit: int = 10
) -> List[BreakthroughEvent]:
    """Get user's recent breakthrough events"""

async def get_user_stats(user_profile_id: int) -> UserConstellationStats:
    """Get user's constellation stats (creates if not exists)"""

async def increment_category_count(user_profile_id: int, category: str) -> None:
    """Helper to increment category count (for testing trigger)"""
```

#### Redis Caching Interface (app/core/redis_client.py extension)

```python
async def get_cached_constellation_library(category: str = None) -> List[dict]:
    """
    Get constellation library from cache or database

    Cache key: constellation:library:{category or 'all'}
    TTL: 3600 seconds (1 hour)
    """

async def invalidate_constellation_cache() -> None:
    """Clear all constellation library cache keys (admin operation)"""
```

### Workflows and Sequencing

#### Workflow 1: Database Migration Execution

```
Developer → Alembic CLI
    ↓
1. Create migration: alembic revision --autogenerate -m "Add constellation tables"
    ↓
2. Review generated migration file
   - Verify all 5 tables created
   - Verify indexes created
   - Verify triggers created
   - Verify foreign keys correct
    ↓
3. Apply migration: alembic upgrade head
    ↓
4. Verify tables exist: psql check or SQLAlchemy query
    ↓
5. Test rollback: alembic downgrade -1
    ↓
6. Reapply: alembic upgrade head
    ↓
Database ready for constellation system
```

**Migration will be #14** (current codebase has 13 migrations)

---

#### Workflow 2: Constellation Library Seed Data

```
Developer → Python Script
    ↓
1. Run: python scripts/seed_constellations.py
    ↓
2. Script loads constellation definitions
   - 12 Emotion constellations
   - 9 Courage constellations
   - 9 Presence constellations
    ↓
3. For each constellation:
   - Check if constellation_key exists (idempotency)
   - If exists: Skip
   - If not exists: Create via create_constellation()
    ↓
4. Verify: Query constellation_library table
   - Count should be 30
   - Category distribution: 12/9/9
    ↓
Constellation library populated
```

**Script Location:** `scripts/seed_constellations.py`

---

#### Workflow 3: Constellation Query (With Caching)

```
Service Layer → get_active_constellations(category="courage")
    ↓
1. Check Redis cache
   Key: "constellation:library:courage"
    ↓
2. Cache HIT:
   - Return cached JSON
   - Deserialize to objects
    ↓
3. Cache MISS:
   - Query PostgreSQL
   - Filter: category="courage" AND is_active=true
   - Serialize to JSON
   - Store in Redis (TTL: 1 hour)
   - Return objects
    ↓
Constellation data returned (< 50ms cached, < 200ms uncached)
```

---

#### Workflow 4: User Constellation Unlock (Database Interaction)

```
Service calls: unlock_constellation_for_user(user_id=123, constellation_id=5, type="breakthrough")
    ↓
1. Check existing unlock:
   SELECT * FROM user_constellations
   WHERE user_profile_id=123 AND constellation_id=5
    ↓
2. If EXISTS:
   - Return existing record (idempotent)
    ↓
3. If NOT EXISTS:
   - BEGIN TRANSACTION
   - INSERT INTO user_constellations
   - TRIGGER fires: update_constellation_stats()
   - COMMIT TRANSACTION
    ↓
4. Stats automatically updated:
   - total_unlocked += 1
   - last_unlock_at = NOW()
    ↓
UserConstellation returned
```

**Key:** Trigger ensures stats are always in sync with unlocks

## Non-Functional Requirements

### Performance

**Database Query Performance:**
- Constellation library queries: < 200ms (P95) uncached, < 50ms cached
- User constellation queries: < 500ms (P95) for 88 constellations
- Stats lookup (user_constellation_stats): < 100ms (P95) - single row query
- CRUD operations: < 100ms (P95) for single record operations

**Migration Performance:**
- Migration execution: < 30 seconds for all 5 tables + indexes + triggers
- Seed script execution: < 2 minutes for 30 constellations (idempotent checks included)
- Rollback capability: < 10 seconds to downgrade migration

**Caching Effectiveness:**
- Redis cache hit rate: > 80% for constellation library queries
- Cache TTL: 3600 seconds (1 hour) for static constellation data
- Cache invalidation: < 1 second to clear all constellation cache keys

**Index Usage:**
- All foreign key columns indexed for JOIN performance
- Category and date columns indexed for common filter/sort operations
- Query plans verified with `EXPLAIN ANALYZE` to confirm index usage

**Scalability Targets (MVP: 1,000-10,000 users):**
- Database connection pool: 10-20 connections (existing infrastructure)
- Concurrent unlocks: Support 100 simultaneous constellation unlocks
- No table locking issues (row-level locking on INSERT)

**Source:** PRD Section "Non-Functional Requirements > Performance"

### Security

**Data Privacy (CRITICAL - Breakthrough data is sensitive):**
- Breakthrough events contain vulnerable moments and must be treated as highly sensitive
- Encrypted at rest: PostgreSQL encryption (existing infrastructure)
- Access control: Users can only query their own constellation/breakthrough data (enforced in Epic 4 API layer)
- No logging of breakthrough text in application logs (log IDs only, not content)

**Database Security:**
- Foreign key constraints prevent orphaned records
- ON DELETE CASCADE ensures user data deletion compliance (GDPR)
- No SQL injection risk (using SQLAlchemy parameterized queries)
- Database user permissions: Application user has INSERT/SELECT/UPDATE only (no DROP/ALTER)

**GDPR Compliance:**
- User data export must include:
  - All user_constellations records
  - All breakthrough_events records
  - user_constellation_stats
  - weekly_reflections (Phase 2)
- User data deletion: CASCADE deletes handle cleanup automatically
- Data retention: breakthrough_events retained for analytics (anonymize after 90 days in future phase)

**Access Logging:**
- Log all constellation unlock operations (user_id, constellation_id, timestamp)
- Log manual admin unlocks with reason (Epic 4)
- No PII in logs (use user_id, not names/emails)

**Pydantic Schema Validation:**
- All inputs validated via Pydantic schemas (Epic 1.4)
- Type safety prevents invalid data insertion
- Required fields enforced at schema level

**Source:** PRD Section "Non-Functional Requirements > Security & Privacy", Architecture Section "Security Architecture"

### Reliability/Availability

**Migration Safety:**
- Reversible migrations: `alembic downgrade -1` must work cleanly
- Migration tested on staging before production
- Backup database before running migration (operational procedure)
- No data loss on rollback (DDL only, no data transformations in Epic 1)

**Data Integrity:**
- UNIQUE constraints prevent duplicate constellations per user
- Foreign key constraints ensure referential integrity
- Database triggers ensure stats always in sync with unlocks (atomic transactions)
- Idempotent CRUD operations (retry-safe)

**Transactional Guarantees:**
- Constellation unlock is atomic (INSERT + trigger in single transaction)
- Rollback on any error (no partial unlocks)
- Isolation level: READ COMMITTED (PostgreSQL default)

**Graceful Degradation:**
- Redis cache failure: Fallback to direct database queries (slower but functional)
- Migration failure: Rollback automatically, database remains in previous state
- Seed script failure: Idempotent, can re-run after fixing issues

**Availability Target:**
- Epic 1 has no runtime services (only database tables)
- Database availability: 99.9% (existing PostgreSQL SLA)
- No single point of failure (database replication in production environment)

**Data Recovery:**
- Database backups: Daily (existing operational procedure)
- Point-in-time recovery: Available via PostgreSQL WAL
- Constellation data is not mission-critical (user progress, not health records)

**Source:** PRD Section "Non-Functional Requirements > Reliability", Architecture Section "Risk Mitigation"

### Observability

**Migration Logging:**
- Alembic migration output captured in deployment logs
- Table creation confirmation logged
- Index creation logged with timing
- Trigger creation verified and logged

**Query Performance Monitoring:**
- Slow query log enabled for queries > 1 second (PostgreSQL configuration)
- Monitor query patterns:
  - Constellation library queries (by category)
  - User constellation lookups (by user_id)
  - Stats queries (by user_id)
- EXPLAIN ANALYZE used during development to verify index usage

**Database Metrics (via existing monitoring):**
- Table row counts (constellation_library: 30, user_constellations: growing)
- Index hit ratio (should be > 95%)
- Connection pool usage
- Transaction commit/rollback rates

**Structured Logging:**
- Log level: INFO for normal operations, ERROR for failures
- Log constellation CRUD operations with context:
  ```python
  logger.info("Constellation unlocked",
              user_id=user_id,
              constellation_id=constellation_id,
              unlock_type=unlock_type)
  ```
- Log cache hits/misses:
  ```python
  logger.debug("Cache hit", cache_key=cache_key)
  logger.debug("Cache miss", cache_key=cache_key)
  ```

**Tracing (Logfire Integration):**
- Database query spans tracked automatically (existing SQLAlchemy instrumentation)
- Constellation CRUD operations wrapped in Logfire spans (added in Epic 3 service layer)
- Cache operations tracked (hits, misses, invalidations)

**Key Signals to Track:**
- `constellation.library.query.duration` - Library query latency
- `constellation.unlock.duration` - Unlock operation latency
- `constellation.cache.hit_ratio` - Cache effectiveness
- `database.constellation_library.row_count` - Total constellations
- `database.user_constellations.row_count` - Total unlocks across all users

**Alerting (Epic 6):**
- Alert if constellation library query P95 > 1 second (indicates cache failure or index issue)
- Alert if migration fails (deployment pipeline)
- Alert if seed script fails (deployment pipeline)

**Retention:**
- Application logs: 90 days (existing policy)
- Database query logs: 30 days (existing policy)
- Metrics: 1 year (existing Logfire retention)

**Source:** PRD Section "Non-Functional Requirements > Observability", Architecture Section "Monitoring & Observability"

## Dependencies and Integrations

**Note:** All dependencies already exist in the Ultra API AWS codebase. Epic 1 requires NO new package installations.

### Python Package Dependencies (Existing)

| Package | Version | Purpose | Used In |
|---------|---------|---------|---------|
| **SQLAlchemy** | 2.0+ (async) | ORM for database models | All model files, CRUD functions |
| **alembic** | 1.x | Database migrations | Migration #14 creation and execution |
| **Pydantic** | 2.x | Request/response validation | Schema definitions (Story 1.4) |
| **asyncpg** | 0.29+ | PostgreSQL async driver | Database connection (via SQLAlchemy) |
| **redis** | 4.5.5 | Caching layer | Constellation library caching (Story 1.6) |
| **python-dateutil** | 2.x | Date/time handling | Timestamp operations |

**Source:** Existing `pyproject.toml` or `requirements.txt` (no changes needed)

### Database Dependencies

| Component | Version | Purpose |
|-----------|---------|---------|
| **PostgreSQL** | 13+ | Primary database | Tables, triggers, indexes |
| **pg_trgm extension** | Included | Full-text search (if needed in future) |

**Integration Points:**
- Connects to existing Ultra API AWS database
- No separate database required
- Uses existing connection pool configuration

### External Integrations

**Redis Cache:**
- **Connection:** Existing Redis instance (used for Celery broker + cache)
- **Host/Port:** Configured via environment variables (existing)
- **Database:** Same Redis instance, different key prefix (`constellation:*`)
- **TTL:** 3600 seconds for constellation library
- **Fallback:** Direct PostgreSQL queries if Redis unavailable

### Internal Codebase Integrations

**Existing Tables (Foreign Key Dependencies):**

| Epic 1 Table | References | Constraint |
|--------------|------------|------------|
| `user_constellations` | `user_profile.id` | ON DELETE CASCADE |
| `user_constellations` | `chats.id` | ON DELETE SET NULL (optional FK) |
| `user_constellations` | `sessions.id` | ON DELETE SET NULL (optional FK) |
| `user_constellations` | `constellation_library.id` | ON DELETE RESTRICT |
| `breakthrough_events` | `user_profile.id` | ON DELETE CASCADE |
| `breakthrough_events` | `chats.id` | ON DELETE SET NULL |
| `breakthrough_events` | `sessions.id` | ON DELETE SET NULL |
| `breakthrough_events` | `user_constellations.id` | ON DELETE SET NULL |
| `user_constellation_stats` | `user_profile.id` | ON DELETE CASCADE |
| `weekly_reflections` | `user_profile.id` | ON DELETE CASCADE |

**Existing Code Dependencies:**

| Epic 1 Module | Imports From Existing Codebase |
|---------------|-------------------------------|
| `app/db/constellation.py` | `from app.db.base_class import Base` |
| `app/db/constellation.py` | `from app.db.db import get_db` |
| `app/db/constellation_progress.py` | `from app.db.base_class import Base` |
| `app/db/constellation_progress.py` | `from app.db.db import get_db` |
| `app/schemas/schemas.py` | Existing Pydantic base schemas (if any) |
| `scripts/seed_constellations.py` | `from app.db.db import init_db` |
| `scripts/seed_constellations.py` | `from app.db.constellation import create_constellation` |

**Patterns to Follow (Existing):**
- Async database functions: `async def function_name(...)` with `get_db().session`
- Model inheritance: `class Model(Base)`
- Pydantic schemas: `class Config: from_attributes = True`
- Migration naming: `alembic/versions/xxx_descriptive_name.py`

### Integration Constraints

**Must NOT Change:**
- Existing table schemas (user_profile, chats, sessions)
- Existing database connection configuration
- Existing Redis configuration
- Existing logging patterns

**Must Follow:**
- Async/await patterns throughout
- Standalone CRUD functions (not class methods)
- Existing error handling patterns
- Existing Logfire instrumentation patterns (added in Epic 3+)

### Dependency Installation

**NONE REQUIRED** - All dependencies already installed in existing environment.

**Verification (Optional):**
```bash
# Verify SQLAlchemy async support
python -c "import sqlalchemy; print(sqlalchemy.__version__)"

# Verify alembic installed
alembic --version

# Verify redis-py installed
python -c "import redis; print(redis.__version__)"
```

### Migration Dependencies

**Alembic Migration Chain:**
- Current migration: #13 (last migration in codebase)
- New migration: #14 (Epic 1 constellation tables)
- Depends on: Migration #13 (must be applied first)
- Depended on by: None (Epic 1 is foundation)

**Migration Execution Order:**
1. Existing migrations (#1 through #13) - Already applied
2. **New:** Migration #14 - Constellation tables (Epic 1.1)
3. Future migrations - Epic 2+ (will depend on #14)

### Integration with Future Epics

**Epic 1 Provides for Epic 2:**
- `breakthrough_events` table for AI detection results
- `save_breakthrough_event()` CRUD function

**Epic 1 Provides for Epic 3:**
- `user_constellations` table for unlock tracking
- `unlock_constellation_for_user()` CRUD function
- `user_constellation_stats` table for progress

**Epic 1 Provides for Epic 4:**
- Pydantic schemas for API request/response
- CRUD functions for endpoint implementation

**Epic 1 Provides for Epic 5:**
- Database structure for notification triggers
- Stats table for progress indicators

## Acceptance Criteria (Authoritative)

### Epic-Level Acceptance Criteria

**Epic 1 is COMPLETE when:**

1. **AC1:** All 5 database tables exist in PostgreSQL database:
   - `constellation_library` table created with all columns and indexes
   - `user_constellations` table created with all columns, indexes, and UNIQUE constraint
   - `breakthrough_events` table created with all columns and indexes
   - `user_constellation_stats` table created with all columns (primary key only)
   - `weekly_reflections` table created with all columns, indexes, and UNIQUE constraint

2. **AC2:** Database migration (#14) is reversible:
   - `alembic upgrade head` creates all tables successfully
   - `alembic downgrade -1` removes all tables cleanly
   - No data loss on rollback (DDL only, no data transformations)

3. **AC3:** Database trigger auto-updates stats on constellation unlock:
   - `update_constellation_stats()` function exists
   - Trigger `trg_update_constellation_stats` fires AFTER INSERT on `user_constellations`
   - Stats table `total_unlocked` increments correctly
   - Stats table `last_unlock_at` updates correctly

4. **AC4:** All SQLAlchemy models follow existing patterns:
   - Models inherit from `Base` (existing base class)
   - All fields match database schema exactly
   - Relationships defined with `back_populates` where applicable
   - Models use `Column`, `Integer`, `String`, `DateTime`, `JSON`, `Boolean`, `Numeric` correctly

5. **AC5:** All CRUD functions are async and follow existing patterns:
   - Functions use `async def` syntax
   - Functions use `get_db().session` for database access (not class methods)
   - Functions return results compatible with Pydantic schemas
   - Idempotent operations check for existing records before creating

6. **AC6:** Pydantic schemas exist for constellation data:
   - Request schemas: `MarkBreakthroughRequest`, `AdminUnlockRequest`
   - Response schemas: `ConstellationSchema`, `UserConstellationSchema`, `ConstellationSkyResponse`, `ProgressStatsSchema`, `BreakthroughResponseSchema`
   - All schemas have `class Config: from_attributes = True`
   - Field validators enforce data constraints

7. **AC7:** Constellation library seeded with 30 MVP constellations:
   - 12 Emotion category constellations
   - 9 Courage category constellations
   - 9 Presence category constellations
   - All constellations have unique `constellation_key`
   - All constellations have `is_active = True`
   - Seed script is idempotent (can run multiple times without duplicates)

8. **AC8:** Redis caching implemented for constellation library:
   - Cache key format: `constellation:library:{category or 'all'}`
   - Cache TTL: 3600 seconds (1 hour)
   - Cache miss triggers database query and cache population
   - Cache invalidation function works correctly
   - Graceful fallback to database if Redis unavailable

9. **AC9:** All foreign key relationships work correctly:
   - `user_constellations.user_profile_id` references `user_profile.id` with CASCADE delete
   - `user_constellations.constellation_id` references `constellation_library.id`
   - `user_constellations.breakthrough_chat_id` references `chats.id`
   - `breakthrough_events.user_profile_id` references `user_profile.id` with CASCADE delete
   - All CASCADE deletes tested and working

10. **AC10:** Database indexes improve query performance:
    - All indexes created as specified in migration
    - EXPLAIN ANALYZE confirms index usage for common queries
    - No full table scans on filtered/sorted queries
    - Foreign key columns all indexed

### Story-Level Acceptance Criteria

**Story 1.1 (Migration):**
- Migration file created: `alembic/versions/xxx_add_constellation_tables.py`
- All 5 tables created with correct schema
- All indexes created
- Database trigger created and attached
- Foreign key constraints reference correct tables
- Migration can be rolled back cleanly

**Story 1.2 (Constellation Library Model):**
- `ConstellationLibrary` class exists in `app/db/constellation.py`
- Model includes all required fields
- CRUD functions implemented: `get_constellation_by_key()`, `get_active_constellations()`, `create_constellation()`, `update_constellation()`
- Functions follow existing patterns (async, use `get_db().session`)

**Story 1.3 (User Progress Models):**
- `UserConstellation`, `BreakthroughEvent`, `UserConstellationStats` classes exist in `app/db/constellation_progress.py`
- CRUD functions for UserConstellation: `unlock_constellation_for_user()` (idempotent), `get_user_constellation()`, `get_user_constellations()`, `get_constellation_by_chat()`
- CRUD functions for BreakthroughEvent: `save_breakthrough_event()`, `get_user_breakthroughs()`
- CRUD functions for Stats: `get_user_stats()`, `increment_category_count()`
- UNIQUE constraint prevents duplicate unlocks
- Relationships defined correctly

**Story 1.4 (Pydantic Schemas):**
- Request schemas exist with validation
- Response schemas exist with `from_attributes = True`
- All schemas have proper field validators
- Optional fields marked correctly
- Clear docstrings on all schemas

**Story 1.5 (Seed Data):**
- Script exists: `scripts/seed_constellations.py`
- 30 constellations created when run
- Category distribution correct: 12/9/9
- Each constellation has unique key, name, category, mythology
- Script is idempotent (running twice doesn't create duplicates)
- Script uses async with `init_db()` context

**Story 1.6 (Redis Caching):**
- Cache keys use format: `constellation:library:{category}`
- Cache TTL is 3600 seconds
- Cache invalidation clears all constellation keys
- Cache miss triggers DB query + cache population
- Cache failures don't break functionality (fallback to DB)

## Traceability Mapping

| AC # | PRD Requirement | Architecture Section | Epic 1 Component | Test Strategy |
|------|-----------------|---------------------|------------------|---------------|
| AC1 | Database Schema (PRD p.236-403) | Data Architecture (Arch p.419-587) | Migration #14, all 5 tables | Run migration, query information_schema to verify tables exist |
| AC2 | Migration Strategy (PRD p.1279) | Migration Strategy (Arch p.1279-1323) | Alembic migration | Execute upgrade/downgrade cycle, verify no errors |
| AC3 | Auto-update stats (PRD p.406-425) | Database Triggers (Arch p.404-425) | `update_constellation_stats()` trigger | Insert test unlock, verify stats incremented |
| AC4 | Model Patterns (PRD p.44-51) | Service Layer Design (Arch p.307-363) | All SQLAlchemy models | Code review, verify inheritance and field types |
| AC5 | Async patterns (PRD p.44-51) | Service Architecture (Arch p.266-363) | All CRUD functions | Code review, verify async def and get_db() usage |
| AC6 | API Schemas (PRD p.429-559) | Pydantic Models (Arch p.772-806) | All Pydantic schemas | Unit tests with sample data, verify validation |
| AC7 | 30 MVP constellations (PRD p.118-136) | Seed Data (Arch p.1294-1317) | `seed_constellations.py` | Run script, query table, verify count and distribution |
| AC8 | Redis caching (PRD p.924-934) | Caching Strategy (Arch p.244-263, 1347-1385) | `get_cached_constellation_library()` | Integration test: cache hit/miss scenarios |
| AC9 | FK relationships (PRD p.229-294) | Foreign Keys (Arch p.144-148, 801-815) | All FK constraints | Test CASCADE delete, verify orphan prevention |
| AC10 | Performance targets (PRD p.905-920) | Database Indexes (Arch p.623-642) | All CREATE INDEX statements | Run EXPLAIN ANALYZE on common queries |

### Test Coverage Matrix

| Component | Unit Tests | Integration Tests | Manual Verification |
|-----------|-----------|-------------------|---------------------|
| **Migration #14** | N/A | Yes - upgrade/downgrade cycle | Visual inspection of tables in psql |
| **ConstellationLibrary model** | Yes - field validation | Yes - CRUD operations | N/A |
| **UserConstellation model** | Yes - field validation, relationships | Yes - unlock idempotency | N/A |
| **BreakthroughEvent model** | Yes - field validation | Yes - save and query | N/A |
| **UserConstellationStats model** | Yes - field validation | Yes - trigger auto-update | N/A |
| **Pydantic schemas** | Yes - validation rules | Yes - ORM compatibility | N/A |
| **CRUD functions** | Yes - mocked DB | Yes - real DB (test env) | N/A |
| **Seed script** | N/A | Yes - idempotency test | Manual run, verify 30 constellations |
| **Redis caching** | Yes - mocked Redis | Yes - real Redis | Monitor cache hit ratio in logs |
| **Database trigger** | N/A | Yes - insert unlock, check stats | psql trigger verification |

### Test Scenarios (Detailed)

**Test 1: Migration Execution**
- **Setup:** Clean database with migrations #1-13 applied
- **Execute:** `alembic upgrade head`
- **Verify:** All 5 tables exist with correct schema
- **Execute:** `alembic downgrade -1`
- **Verify:** All 5 tables removed
- **Execute:** `alembic upgrade head` (reapply)
- **Result:** PASS if no errors, tables recreated

**Test 2: Seed Data Idempotency**
- **Setup:** Empty constellation_library table
- **Execute:** `python scripts/seed_constellations.py`
- **Verify:** 30 records created
- **Execute:** `python scripts/seed_constellations.py` (again)
- **Verify:** Still 30 records (no duplicates)
- **Result:** PASS if count remains 30

**Test 3: Constellation Unlock with Trigger**
- **Setup:** User exists, constellation exists
- **Execute:** `unlock_constellation_for_user(user_id=1, constellation_id=5, ...)`
- **Verify:** `user_constellations` record created
- **Verify:** `user_constellation_stats.total_unlocked` = 1 for user_id=1
- **Verify:** `user_constellation_stats.last_unlock_at` updated
- **Result:** PASS if trigger fired correctly

**Test 4: Cache Hit/Miss Behavior**
- **Setup:** Empty Redis cache, populated constellation_library
- **Execute:** `get_cached_constellation_library(category="emotion")`
- **Verify:** Cache MISS logged, DB queried, cache populated
- **Execute:** `get_cached_constellation_library(category="emotion")` (again)
- **Verify:** Cache HIT logged, no DB query
- **Wait:** 3601 seconds (TTL expired)
- **Execute:** `get_cached_constellation_library(category="emotion")`
- **Verify:** Cache MISS (expired), DB queried again
- **Result:** PASS if cache behavior correct

**Test 5: Foreign Key CASCADE Delete**
- **Setup:** User with unlocked constellation
- **Execute:** Delete user from `user_profile`
- **Verify:** `user_constellations` record deleted (CASCADE)
- **Verify:** `user_constellation_stats` record deleted (CASCADE)
- **Verify:** `breakthrough_events` deleted (CASCADE)
- **Result:** PASS if all orphan records removed

**Test 6: UNIQUE Constraint (Idempotency)**
- **Setup:** User exists, constellation exists
- **Execute:** `unlock_constellation_for_user(user_id=1, constellation_id=5, ...)`
- **Verify:** Record created
- **Execute:** `unlock_constellation_for_user(user_id=1, constellation_id=5, ...)` (duplicate)
- **Verify:** No error, existing record returned
- **Verify:** Only 1 record exists (not 2)
- **Result:** PASS if idempotent

**Test 7: Query Performance (with indexes)**
- **Setup:** 30 constellations, 100 user unlocks
- **Execute:** `EXPLAIN ANALYZE SELECT * FROM user_constellations WHERE user_profile_id = 1`
- **Verify:** Uses index `idx_user_const_user` (not sequential scan)
- **Execute:** `EXPLAIN ANALYZE SELECT * FROM constellation_library WHERE category = 'emotion'`
- **Verify:** Uses index `idx_constellation_category`
- **Result:** PASS if indexes used

### Definition of Done (DoD) for Epic 1

**Code Complete:**
- ✅ All 6 stories implemented (1.1 - 1.6)
- ✅ All files created in correct locations
- ✅ Code follows existing patterns (async, standalone functions)
- ✅ No linting errors (`flake8`, `black`)

**Testing Complete:**
- ✅ All unit tests passing (> 80% coverage)
- ✅ All integration tests passing
- ✅ Manual verification tests completed successfully

**Documentation Complete:**
- ✅ Migration script documented with comments
- ✅ CRUD function docstrings complete
- ✅ README updated with seed script instructions

**Deployment Ready:**
- ✅ Migration tested on staging environment
- ✅ Seed script tested on staging environment
- ✅ Rollback tested successfully
- ✅ Database backup taken before production migration

**Epic 1 Sign-Off:**
- ✅ All acceptance criteria met
- ✅ Code reviewed and approved
- ✅ Epic 2 can begin (foundation is ready)

## Risks, Assumptions, Open Questions

### Risks

**RISK-1: Migration Execution Failure in Production**
- **Description:** Migration #14 could fail on production database due to schema conflicts or permission issues
- **Likelihood:** Low (migrations tested on staging)
- **Impact:** High (blocks all Epic 1+ work)
- **Mitigation:**
  - Test migration on staging database first
  - Take database backup before migration
  - Plan rollback procedure
  - Execute during low-traffic maintenance window
  - Have DBA review migration script

**RISK-2: Database Trigger Performance Impact**
- **Description:** `update_constellation_stats()` trigger could slow down constellation unlocks
- **Likelihood:** Low (simple INSERT with ON CONFLICT)
- **Impact:** Medium (affects unlock latency)
- **Mitigation:**
  - Benchmark trigger execution time (< 50ms target)
  - Ensure stats table has proper index on user_profile_id
  - Consider moving to async background update if trigger too slow
  - Monitor transaction durations in production

**RISK-3: Foreign Key Type Mismatch**
- **Description:** Assumption about Integer IDs could be wrong; existing tables might use UUIDs
- **Likelihood:** Low (architecture doc specifies Integer based on existing patterns)
- **Impact:** High (migration fails, requires rework)
- **Mitigation:**
  - **Action Required:** Verify actual ID types in existing tables BEFORE creating migration
  - Query `user_profile`, `chats`, `sessions` to confirm ID column type
  - Adjust migration if UUIDs detected

**RISK-4: Redis Cache Availability**
- **Description:** Redis service could be unavailable, breaking caching layer
- **Likelihood:** Medium (external dependency)
- **Impact:** Low (graceful fallback to database)
- **Mitigation:**
  - Implement fallback logic (cache failure → direct DB query)
  - Log cache failures for monitoring
  - Don't block operations on cache errors
  - Already mitigated in design

**RISK-5: Seed Data Mythology Content Quality**
- **Description:** 30 constellation mythologies might be low quality or inconsistent
- **Likelihood:** Medium (content creation task)
- **Impact:** Low (can iterate post-launch)
- **Mitigation:**
  - Use placeholder text initially (MVP focus on mechanics)
  - Refine mythology in Phase 2
  - Gather user feedback on content quality

### Assumptions

**ASSUMPTION-1: Existing Database Uses Integer IDs**
- **Assumption:** `user_profile.id`, `chats.id`, `sessions.id` are INTEGER (not UUID)
- **Validation Required:** Query existing tables to confirm
- **Impact if Wrong:** Migration fails, requires rework with UUID types
- **Action:** Verify in Story 1.1 before creating migration

**ASSUMPTION-2: PostgreSQL Version Supports Required Features**
- **Assumption:** PostgreSQL 13+ supports JSON columns, ON CONFLICT, triggers
- **Validation:** Check `SELECT version()` in existing database
- **Impact if Wrong:** Migration syntax errors
- **Confidence:** High (architecture doc confirms PostgreSQL 13+)

**ASSUMPTION-3: Redis is Configured and Available**
- **Assumption:** Redis instance already running and accessible from application
- **Validation:** Check existing Celery configuration (uses Redis as broker)
- **Impact if Wrong:** Caching won't work (but has fallback)
- **Confidence:** High (architecture confirms Redis 4.5.5 exists)

**ASSUMPTION-4: Existing Codebase Uses Async SQLAlchemy**
- **Assumption:** All database operations use async patterns (not sync)
- **Validation:** Review existing model files (e.g., `app/db/user_metrics.py`)
- **Impact if Wrong:** Pattern mismatch, requires rewrite
- **Confidence:** High (architecture explicitly states async via asyncpg)

**ASSUMPTION-5: 30 Constellations is Sufficient for MVP**
- **Assumption:** Users will have adequate variety with 30 vs full 88 constellation set
- **Validation:** User testing during beta rollout (Epic 6)
- **Impact if Wrong:** Users get bored or run out of unlocks too quickly
- **Mitigation:** Can increase to 50 or 88 if needed (seed more constellations)

**ASSUMPTION-6: Standalone CRUD Functions are Preferred**
- **Assumption:** Existing codebase uses standalone functions (not class methods)
- **Validation:** Review existing `app/db/` files
- **Impact if Wrong:** Pattern inconsistency
- **Action:** Confirm pattern in Story 1.2 by reading existing model files

### Open Questions

**QUESTION-1: Should constellation_library use Integer or UUID for id?**
- **Status:** ANSWERED - Use Integer to match existing table patterns
- **Decision:** Integer (architecture doc specifies this)
- **Rationale:** Consistency with existing tables, simpler joins

**QUESTION-2: Should we create indexes on all foreign keys automatically?**
- **Status:** ANSWERED - Yes, index all foreign key columns
- **Decision:** Explicit CREATE INDEX for all FKs
- **Rationale:** JOIN performance, query optimization

**QUESTION-3: Should Redis cache failures raise errors or fall back silently?**
- **Status:** ANSWERED - Fall back silently to database
- **Decision:** Graceful degradation (log warning, query DB)
- **Rationale:** Caching is optimization, not requirement

**QUESTION-4: Should user_constellation_stats be updated via trigger or async task?**
- **Status:** ANSWERED - Use database trigger for MVP
- **Decision:** Trigger (atomic, immediate consistency)
- **Rationale:** Simpler, guarantees consistency
- **Future:** Could move to async if performance issues

**QUESTION-5: How to handle constellation_library updates (admin edits)?**
- **Status:** DEFERRED to Epic 4 (admin endpoints)
- **Decision:** Admin endpoint will handle updates + cache invalidation
- **Rationale:** Not needed for Epic 1 (one-time seed)

**QUESTION-6: Should we pre-create ConstellationLibrary for all 88 or just 30?**
- **Status:** ANSWERED - 30 for MVP (is_active flag)
- **Decision:** Seed 30, mark as `is_active=True`, others can be added later
- **Rationale:** MVP scope, can expand in Phase 2

## Test Strategy Summary

### Testing Approach

**Test Pyramid for Epic 1:**
```
                    /\
                   /  \     Manual (Exploratory)
                  /    \    - Migration verification
                 /      \   - Seed script execution
                /________\
               /          \  Integration Tests
              /            \ - Database operations
             /              \- Cache hit/miss
            /                \- Foreign key constraints
           /__________________\
          /                    \ Unit Tests
         /                      \- Model field validation
        /                        \- Schema validation
       /                          \- CRUD function logic (mocked)
      /____________________________\
```

**Target Coverage:**
- Unit tests: 80%+ code coverage
- Integration tests: 100% of CRUD functions
- Manual verification: All migration steps

### Test Levels

#### 1. Unit Tests (Fast, Isolated)

**Scope:**
- Pydantic schema validation (Story 1.4)
- Model field definitions
- CRUD function logic (with mocked database)

**Framework:** pytest, pytest-asyncio

**Example Tests:**
```python
# test_constellation_schemas.py
def test_constellation_schema_validation():
    """Test ConstellationSchema validates correctly"""

def test_mark_breakthrough_request_category_validation():
    """Test category must be emotion|courage|presence"""

# test_constellation_models.py
def test_constellation_library_model_fields():
    """Test ConstellationLibrary has all required fields"""

def test_user_constellation_unique_constraint():
    """Test UNIQUE constraint on (user_id, constellation_id)"""
```

**Target:** 20 unit tests

#### 2. Integration Tests (Database Required)

**Scope:**
- All CRUD functions with real database (test environment)
- Migration execution (upgrade/downgrade)
- Database trigger verification
- Redis caching behavior
- Foreign key CASCADE deletes

**Framework:** pytest with test database

**Setup:**
```python
# conftest.py
@pytest.fixture(scope="session")
async def test_db():
    """Create test database with migrations applied"""
    # Create test DB
    # Run alembic upgrade head
    # Yield connection
    # Cleanup
```

**Example Tests:**
```python
# test_constellation_crud.py
async def test_create_constellation(test_db):
    """Test creating constellation via CRUD"""

async def test_unlock_constellation_idempotent(test_db):
    """Test unlocking same constellation twice returns existing"""

async def test_get_user_constellations_by_category(test_db):
    """Test filtering constellations by category"""

# test_breakthrough_crud.py
async def test_save_breakthrough_event(test_db):
    """Test saving breakthrough event"""

# test_stats_trigger.py
async def test_stats_auto_update_on_unlock(test_db):
    """Test trigger increments stats correctly"""

# test_caching.py
async def test_constellation_cache_hit_miss(test_db, test_redis):
    """Test Redis cache behavior"""
```

**Target:** 30 integration tests

#### 3. Manual Verification Tests

**Scope:**
- Migration execution on staging
- Seed script execution
- Visual inspection of database schema
- Performance testing with EXPLAIN ANALYZE

**Checklist:**
- [ ] Run migration on staging database
- [ ] Verify all 5 tables exist with `\dt` in psql
- [ ] Inspect table schemas with `\d table_name`
- [ ] Run seed script, verify 30 constellations created
- [ ] Test rollback with `alembic downgrade -1`
- [ ] Verify trigger with manual INSERT test
- [ ] Run EXPLAIN ANALYZE on common queries
- [ ] Check Redis cache keys with `KEYS constellation:*`

### Test Frameworks and Tools

| Tool | Purpose | Used For |
|------|---------|----------|
| **pytest** | Unit testing framework | All Python tests |
| **pytest-asyncio** | Async test support | Testing async CRUD functions |
| **pytest-cov** | Code coverage | Verify 80%+ coverage |
| **faker** | Test data generation | Creating test constellations, users |
| **factory_boy** | Test fixtures | User, constellation, unlock fixtures |
| **psql** | Database inspection | Manual migration verification |
| **redis-cli** | Cache inspection | Manual cache verification |

### Edge Cases to Test

**Edge Case 1: User Unlocks All Constellations in Category**
- Create user with 11 emotion constellations
- Unlock 12th (last one)
- Verify `emotion_complete = True` in stats (Note: trigger doesn't handle this in Epic 1, will be Epic 3 logic)

**Edge Case 2: Constellation Already Unlocked (Idempotency)**
- Unlock constellation for user
- Call unlock again with same parameters
- Verify no duplicate, existing record returned

**Edge Case 3: Invalid Foreign Key (User Doesn't Exist)**
- Attempt unlock with non-existent user_profile_id
- Verify foreign key constraint error raised
- Verify no partial record created

**Edge Case 4: Seed Script Re-run (Idempotency)**
- Seed 30 constellations
- Modify 1 constellation manually
- Re-run seed script
- Verify modified constellation NOT overwritten (idempotent by key check)

**Edge Case 5: Redis Unavailable**
- Stop Redis service
- Call `get_cached_constellation_library()`
- Verify fallback to database works
- Verify no application crash

**Edge Case 6: Null Breakthrough Links (Manual Unlocks)**
- Create unlock with unlock_type="manual" (no chat_id)
- Verify breakthrough_chat_id is NULL
- Verify query doesn't fail on null FK

**Edge Case 7: Concurrent Unlocks (Race Condition)**
- Trigger 2 simultaneous unlock calls for same user/constellation
- Verify only 1 record created (UNIQUE constraint)
- Verify second call gets existing record (not error)

### Test Data Requirements

**Test Constellation Definitions:**
- Minimum 10 test constellations (4 emotion, 3 courage, 3 presence)
- Include edge cases: empty mythology, special characters in names
- Various sort_order values

**Test Users:**
- Minimum 3 test users
- User with 0 unlocks (new user)
- User with some unlocks (5-10)
- User with many unlocks (50+, for performance testing)

**Test Breakthrough Events:**
- Various confidence scores (0.70, 0.85, 1.00)
- All 3 categories represented
- Both AI-detected and user-marked

### Continuous Integration

**Test Execution in CI Pipeline:**
```yaml
# .github/workflows/test.yml (existing)
# Add constellation tests to existing test suite

- name: Run Epic 1 Tests
  run: |
    pytest app/test/test_constellation_models.py
    pytest app/test/test_constellation_schemas.py
    pytest app/test/test_constellation_crud.py
    pytest app/test/test_constellation_caching.py
    --cov=app/db/constellation
    --cov=app/db/constellation_progress
    --cov-report=html
```

**Coverage Requirements:**
- Minimum 80% coverage for new code
- 100% coverage for CRUD functions (critical paths)
- Test failures block merge to main

### Performance Testing (Story 1.6 validation)

**Test Scenarios:**
```python
# perf_test_epic1.py
async def test_constellation_query_performance():
    """Verify queries meet < 200ms target"""
    # Load 30 constellations
    # Query by category 100 times
    # Measure P95 latency
    # Assert P95 < 200ms

async def test_cache_performance():
    """Verify cache hit < 50ms target"""
    # Warm cache
    # Query 100 times
    # Measure cache hit latency
    # Assert P95 < 50ms

async def test_unlock_performance():
    """Verify unlock + trigger < 100ms"""
    # Execute unlock operation 50 times
    # Measure total duration (unlock + trigger)
    # Assert P95 < 100ms
```

**Performance Benchmarks:**
- Run on staging with production-like data volumes
- Document baseline metrics for future comparison

### Test Execution Order

**Phase 1: Pre-Migration**
1. Unit tests (Pydantic schemas, model definitions)
2. Review migration file manually

**Phase 2: Post-Migration (Staging)**
3. Run migration on staging
4. Integration tests (CRUD operations)
5. Trigger tests (stats auto-update)
6. Foreign key tests (CASCADE deletes)
7. Performance tests (query latency)

**Phase 3: Seed Data**
8. Run seed script on staging
9. Verify data quality (count, distribution)
10. Test idempotency (re-run)

**Phase 4: Caching**
11. Integration tests (cache hit/miss)
12. Fallback tests (Redis unavailable)

**Phase 5: Production Readiness**
13. Code review
14. Manual verification checklist
15. Deployment runbook validation

## Test Strategy Summary

### Overview

Epic 1 testing focuses on **data integrity, migration safety, and pattern compliance**. Since Epic 1 has no user-facing features or business logic, testing emphasizes foundational correctness: database schema, model definitions, CRUD operations, and caching behavior.

### Test Levels

**Unit Tests (Fast Feedback):**
- Pydantic schema validation (field types, constraints, validators)
- Model field definitions (verify all columns present)
- Mocked CRUD function logic (test branches without database)
- **Target:** 80% code coverage, < 5 seconds execution time

**Integration Tests (Confidence):**
- All CRUD functions with real test database
- Migration upgrade/downgrade cycle
- Database trigger verification
- Foreign key CASCADE delete behavior
- Redis cache hit/miss/invalidation scenarios
- **Target:** 100% CRUD function coverage, < 30 seconds execution time

**Manual Verification (Production Safety):**
- Migration execution on staging (DBA review)
- Seed script execution (verify data quality)
- Database schema inspection (psql commands)
- Query performance testing (EXPLAIN ANALYZE)
- **Target:** Complete checklist before production deployment

### Test Frameworks

**Primary:** pytest + pytest-asyncio (existing test infrastructure)

**Supporting:**
- pytest-cov (coverage reporting)
- faker (test data generation)
- factory_boy (fixture creation)
- pytest-benchmark (performance tests)

**Database:** Separate test database (isolated from dev/prod)

### Coverage Requirements

**Code Coverage:**
- app/db/constellation.py: 80%+ (models + CRUD)
- app/db/constellation_progress.py: 80%+ (models + CRUD)
- app/schemas/schemas.py (constellation schemas): 90%+ (validation critical)
- scripts/seed_constellations.py: 70%+ (execution path tested)

**Acceptance Criteria Coverage:**
- All 10 epic-level ACs must have corresponding tests
- All 6 story-level AC sets must be verified
- Traceability matrix shows test for each AC

### Test Execution Strategy

**Local Development:**
- Developers run unit tests before commit
- Pre-commit hook runs linting and quick tests
- Full test suite runs on demand

**CI/CD Pipeline:**
- All tests run on pull request
- Migration tests run on staging deployment
- Performance tests run nightly (optional)

**Staging Validation:**
- Migration tested before production
- Seed script tested before production
- Manual verification checklist completed

**Production:**
- Smoke tests after deployment (verify tables exist)
- Monitor query performance for 24 hours
- Alert on slow queries or errors

### Success Metrics

**Test Execution:**
- All tests pass (0 failures)
- Code coverage meets targets (80%+)
- No critical bugs found in code review

**Performance:**
- Migration completes < 30 seconds
- Seed script completes < 2 minutes
- Query performance meets targets (< 200ms uncached)

**Quality:**
- Zero foreign key constraint violations
- Zero UNIQUE constraint violations in idempotent operations
- Trigger executes correctly 100% of the time

### Regression Prevention

**For Future Epics:**
- Epic 1 tests become regression suite
- Any changes to models/CRUD must pass Epic 1 tests
- Database schema changes require migration compatibility tests

**Test Maintenance:**
- Update tests if models change (Phase 2 evolution)
- Add tests for new CRUD functions
- Keep test data realistic (use production-like values)
