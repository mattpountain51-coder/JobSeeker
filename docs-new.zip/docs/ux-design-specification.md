# Constellation Gamification - UX Design Specification

**Project:** Jaimee AI Companion - Constellation System
**Designer:** Sally (UX Designer)
**Date:** 2025-11-22
**Version:** 1.0
**Platform:** Mobile (Flutter) - iOS & Android

---

## Executive Summary

### Design Vision

The Constellation Gamification System creates an **emotional memory palace** where women using Jaimee can visualize their therapeutic growth journey through collectible constellations. Each constellation marks a breakthrough moment, creating beautiful, permanent bookmarks in their healing story.

### Design Direction: Hybrid Dark Window Aesthetic

**Core Principle:** Keep Jaimee's warm, safe structure while revealing mystical constellation magic through "windows into space."

**Visual Strategy:**
- **App structure** = Warm Jaimee (cream backgrounds, gold accents, soft cards)
- **Constellation content** = Traditional dark celestial (space windows with glowing stars)
- **Result** = Familiar safety + magical discovery

**Metaphor:** Like looking through a telescope - the warm room around you (Jaimee) contains a window to the stars (constellations).

---

## Table of Contents

1. [Design System](#design-system)
2. [Screen Inventory & Flows](#screen-inventory--flows)
3. [Component Specifications](#component-specifications)
4. [Interaction Patterns](#interaction-patterns)
5. [Animation & Micro-interactions](#animation--micro-interactions)
6. [State Management](#state-management)
7. [Accessibility](#accessibility)
8. [Flutter Implementation Guide](#flutter-implementation-guide)

---

## Design System

### Color Palette

#### Warm Jaimee Colors (Existing)
**Primary Backgrounds:**
- `#FFF8F0` - Cream white (main background)
- `#F5EDE0` - Warm beige (secondary background)
- `#FFFFFF` - Pure white (cards)

**Accent Colors:**
- `#E8B870` - Primary gold (CTAs, highlights)
- `#F4D9A6` - Light gold (badges, secondary accents)
- `#D4A868` - Medium gold (links, active states)

**Text Colors:**
- `#6B5945` - Primary text (dark warm brown)
- `#B8935C` - Secondary text (medium brown)
- `#8B7566` - Tertiary text (light brown)

#### Dark Celestial Colors (New - For Windows)
**Space Backgrounds:**
- `#0a0a1f` - Deep space navy (top)
- `#1a1a3e` - Space blue (bottom)
- `#0f0f2a` - Mid-space (transitions)

**Nebula Effects:**
- `rgba(80, 120, 200, 0.15)` - Blue nebula
- `rgba(120, 80, 180, 0.12)` - Purple nebula

**Stars & Constellations:**
- `#FFFFFF` - Background stars (white)
- `#FFE8D6` - Constellation star cores (warm white)
- `#F4D9A6` - Star glow (warm gold)
- `rgba(244, 217, 166, 0.6)` - Constellation lines (golden)

#### Category Color Coding (Subtle)
**Emotion Path:**
- Accent: `#A8C5DA` - Soft blue (water element)
- Use for: Category badges, subtle glows on Emotion constellations

**Courage Path:**
- Accent: `#E8B870` - Warm gold (fire element)
- Use for: Category badges, subtle glows on Courage constellations

**Presence Path:**
- Accent: `#C8A8BE` - Soft lavender (air element)
- Use for: Category badges, subtle glows on Presence constellations

#### Rarity Colors
**Badges only (subtle, not overwhelming):**
- **Common:** `#B0B0B0` - Silver-gray
- **Rare:** `#6495ED` - Cornflower blue
- **Epic:** `#9370DB` - Medium purple
- **Legendary:** `#FFD700` - Gold

---

### Typography

#### Font Families
**Primary (UI):** SF Pro / Roboto (system default)
**Secondary (Mythology):** Georgia / Garamond (serif for storytelling)

#### Type Scale

**Headers:**
- H1: 28px, Weight 600, Letter-spacing 0.5px (Screen titles)
- H2: 22px, Weight 600, Letter-spacing 0.3px (Section headers)
- H3: 18px, Weight 600 (Card titles)

**Body:**
- Body Large: 16px, Weight 400, Line-height 1.6 (Mythology text)
- Body: 15px, Weight 400, Line-height 1.5 (Standard content)
- Body Small: 13px, Weight 400, Line-height 1.4 (Metadata)

**Labels:**
- Label Large: 14px, Weight 600, Uppercase, Letter-spacing 1.5px
- Label Small: 11px, Weight 700, Uppercase, Letter-spacing 1.5px

---

### Spacing System

**Base Unit:** 4px

**Scale:**
- XXS: 4px (tight gaps)
- XS: 8px (small gaps)
- S: 12px (default component padding)
- M: 16px (card internal padding)
- L: 20px (section spacing)
- XL: 24px (major section spacing)
- XXL: 32px (screen margins)

**Card Padding:** 16px (M)
**Screen Padding:** 20px (L)
**Section Gaps:** 24px (XL)

---

### Border Radius

**Scale:**
- Small: 8px (badges, tags)
- Medium: 12px (celestial windows, buttons)
- Large: 16px (mini cards)
- XL: 20px (major cards, header)
- XXL: 24px (full-screen cards)

---

### Shadows

**Jaimee Card Shadow (Warm):**
```css
box-shadow: 0 4px 20px rgba(107, 89, 69, 0.12);
```

**Hover Shadow (Warm):**
```css
box-shadow: 0 8px 30px rgba(107, 89, 69, 0.18);
```

**Celestial Window Shadow (Inset):**
```css
box-shadow: inset 0 0 30px rgba(0, 0, 0, 0.4);
```

**Gold Border Glow:**
```css
box-shadow: 0 0 15px rgba(244, 217, 166, 0.3);
```

---

## Screen Inventory & Flows

### Navigation Structure

```
Jaimee App (Existing)
├── Home Tab (existing)
├── Chat Tab (existing)
├── Constellations Tab ⭐ (NEW)
│   ├── My Constellation Sky (full overview)
│   ├── Constellation Detail (tap any constellation)
│   └── Breakthrough History (optional view)
├── Profile Tab (existing)
└── Journal Tab (existing)
```

### New Screens

**Total New Screens:** 7 primary screens

1. **My Constellation Sky** (Main hub)
2. **Constellation Detail** (Individual view)
3. **Unlock Celebration** (Modal overlay)
4. **Breakthrough Marking** (In-chat action)
5. **Category Progress** (Stats view)
6. **Weekly Reflection Prompt** (Modal)
7. **Celebration Ritual** (Weekly review)

---

## Screen 1: My Constellation Sky (Main Hub)

**Purpose:** Overview of user's entire constellation collection organized by category

**Reference:** `docs/ux-ui/poc-full-sky-hybrid-dark.html`

### Layout Structure

```
┌─────────────────────────────┐
│ [←] My Constellation Sky [12/88] │  ← Sticky header
├─────────────────────────────┤
│                             │
│  Your journey with Jaimee   │  ← Intro card (warm)
│  5 Emotion • 4 Courage      │
│  3 Presence                 │
│                             │
├─────────────────────────────┤
│                             │
│  🌊 Path of Emotion    5/35 │  ← Category header
│                             │
│  ┌─────┐ ┌─────┐ ┌─────┐  │  ← Grid of mini cards
│  │ dark│ │ dark│ │ dark│  │     with dark windows
│  │ sky │ │ sky │ │ sky │  │
│  └─────┘ └─────┘ └─────┘  │
│  Pisces  Cancer  [Locked]  │
│                             │
│  🦁 Path of Courage    4/27 │
│                             │
│  ┌─────┐ ┌─────┐ ┌─────┐  │
│  │ dark│ │ dark│ │ dark│  │
│  └─────┘ └─────┘ └─────┘  │
│                             │
│  🧘 Path of Presence   3/26 │
│                             │
│  ┌─────┐ ┌─────┐          │
│  │ dark│ │ dark│          │
│  └─────┘ └─────┘          │
│                             │
└─────────────────────────────┘
  🏠  💬  ⭐  👤              ← Bottom nav
```

### Component Breakdown

**1. Sticky Header**
- Background: `rgba(255, 248, 240, 0.98)` with backdrop blur
- Back button (36px circle, white background)
- Title: "My Constellation Sky"
- Progress badge: "12 / 88" in gold gradient

**2. Intro Card (Warm)**
- Background: White (#FFF)
- Padding: 20px
- Border-radius: 20px
- Shadow: Warm Jaimee shadow
- Content:
  - Centered text: "Each constellation marks a moment of growth"
  - Stats row: Category counts (Emotion/Courage/Presence)

**3. Category Section (Repeats 3 times)**
- **Category Header:**
  - Background: `rgba(255, 255, 255, 0.7)`
  - Border-left: 4px solid (category color)
  - Emoji + Title + Progress count
  - Padding: 12px 16px
  - Border-radius: 16px

- **Constellation Grid:**
  - Responsive grid: `minmax(160px, 1fr)` on desktop, `minmax(140px, 1fr)` on mobile
  - Gap: 16px

**4. Mini Constellation Card**
- **Card Shell (Warm):**
  - Background: White (#FFF)
  - Padding: 12px
  - Border-radius: 16px
  - Border: 2px solid `rgba(244, 217, 166, 0.2)`
  - Shadow: `0 4px 15px rgba(107, 89, 69, 0.1)`
  - Hover: Lift 5px, increase shadow

- **Dark Celestial Window (Inside):**
  - Width: 100%
  - Height: 120px
  - Border-radius: 12px
  - Background: Linear gradient (`#0a0a1f` → `#1a1a3e`)
  - Border: 2px solid `rgba(244, 217, 166, 0.25)` (gold frame)
  - Inset shadow for depth
  - Contains: Nebula, background stars, constellation shape

- **Card Footer (Warm):**
  - Constellation name (14px, weight 600, color: `#6B5945`)
  - Rarity tier (11px, weight 500, color: `#B8935C`)

**5. Locked State**
- Opacity: 0.5
- Filter: Grayscale(0.7) on celestial window
- Background: `rgba(245, 245, 245, 0.7)`
- Text: "Locked" instead of rarity
- No hover effect
- Cursor: default

**6. Bottom Navigation (Existing Jaimee)**
- 4 tabs: Home, Chat, Constellations (active), Profile
- Active state: Gold color (`#E8B870`)
- Background: `rgba(255, 248, 240, 0.98)` with backdrop blur

### User Flow

**Entry Points:**
1. Tap "⭐ Constellations" tab in bottom nav
2. Tap "View your sky" from unlock celebration
3. Tap constellation count badge from profile

**Interactions:**
1. **Scroll** - Vertical scroll through all categories
2. **Tap constellation card** - Navigate to detail view (Screen 2)
3. **Pull to refresh** - Check for new unlocks
4. **Tap back** - Return to previous screen

### Empty State (0 constellations)

**When:** New user hasn't unlocked any constellations yet

**Display:**
- Intro card shows: "Your constellation sky is waiting for you"
- All categories show locked constellations (dimmed)
- Encouragement text: "Start chatting with Jaimee to unlock your first constellation"
- CTA button: "Start a conversation" → navigates to Chat tab

---

## Screen 2: Constellation Detail (Individual View)

**Purpose:** Deep dive into a specific constellation with mythology, breakthrough moment, and stats

**Reference:** `docs/ux-ui/poc-hybrid-card-window.html`

### Layout Structure

```
┌─────────────────────────────┐
│ [←]                         │  ← Header (minimal)
├─────────────────────────────┤
│                             │
│  ┌─────────────────────────┐│
│  │ Leo              [Rare] ││  ← Card header
│  ├─────────────────────────┤│
│  │                         ││
│  │    ┌───────────────┐    ││  ← Large dark
│  │    │  Dark Space   │    ││     celestial window
│  │    │   with Leo    │    ││     (280px height)
│  │    │ constellation │    ││
│  │    └───────────────┘    ││
│  │                         ││
│  │ 🦁 Courage              ││  ← Category tag
│  │                         ││
│  │ Mythology text...       ││  ← Story
│  │                         ││
│  │ ✨ Your Breakthrough    ││  ← Breakthrough
│  │ "I realize now..."      ││     moment
│  │ → View this conversation││
│  │                         ││
│  │ Unlocked Oct 10, 2024   ││  ← Date
│  └─────────────────────────┘│
│                             │
│  [View Breakthrough Chat]   │  ← Action button
│                             │
└─────────────────────────────┘
```

### Component Breakdown

**1. Header (Minimal for immersion)**
- Background: Transparent or slightly blurred
- Back button (left): 40px circle, white bg
- Constellation name (optional, can omit for clean look)

**2. Constellation Card (Full Detail)**
- **Card Shell:**
  - Background: White (#FFF)
  - Padding: 20px
  - Border-radius: 24px
  - Shadow: Warm elevated shadow
  - Max-width: 450px (centered on tablets)

- **Card Header:**
  - Constellation name: 24px, weight 600, color `#6B5945`
  - Rarity badge: Same as mini cards
  - Flex layout (space-between)
  - Padding-bottom: 16px
  - Border-bottom: 1px solid `rgba(244, 217, 166, 0.3)`

- **Celestial Window (Large):**
  - Height: 280px (larger for detail view)
  - All same properties as mini window
  - More constellation detail visible
  - Can show constellation lines more clearly

- **Category Tag:**
  - Emoji + "Path of [Category]"
  - Background: `rgba(232, 184, 112, 0.12)`
  - Padding: 10px 18px
  - Border-radius: 24px
  - Border: 1px solid category accent color

- **Mythology Section:**
  - Font: Georgia/Garamond (serif)
  - Size: 15px
  - Line-height: 1.7
  - Color: `#6B5945`
  - Padding: 16px 0
  - Text-align: Left

- **Breakthrough Moment Box:**
  - Background: `linear-gradient(135deg, rgba(244, 217, 166, 0.15), rgba(232, 184, 112, 0.1))`
  - Border-left: 4px solid `#E8B870`
  - Padding: 16px 18px
  - Border-radius: 0 12px 12px 0
  - Margin: 20px 0
  - **Label:** "✨ Your Breakthrough Moment" (11px, uppercase)
  - **Quote:** User's insight (14px, italic, serif)
  - **Link:** "→ View this conversation" (gold, underline on hover)

- **Unlock Date:**
  - Centered text
  - Size: 13px
  - Color: `#B8935C`
  - Padding-top: 18px
  - Border-top: 1px solid `rgba(244, 217, 166, 0.25)`

**3. Action Button (Bottom)**
- Full-width button below card
- Background: `linear-gradient(135deg, #F4D9A6, #E8B870)`
- Text: "View Breakthrough Chat"
- Padding: 16px
- Border-radius: 16px
- Shadow: `0 4px 15px rgba(232, 184, 112, 0.3)`

### Locked State (Detail View)

**If user taps a locked constellation:**
- Show same layout
- Celestial window: Dimmed (opacity 0.4, grayscale)
- Only show constellation outline (no colored stars)
- Mythology: Preview only (first sentence + "Unlock to read more...")
- No breakthrough moment section
- CTA: "Start chatting to unlock" button

### User Flow

**Entry:** Tap any constellation from Sky overview

**Interactions:**
1. **View mythology** - Read, scroll if long
2. **Read breakthrough** - See what triggered unlock
3. **Tap "View conversation"** - Navigate to chat history, scrolled to that message
4. **Swipe left/right** - Navigate to next/previous constellation (optional)
5. **Tap back** - Return to Sky overview

---

## Screen 3: Unlock Celebration (Modal Overlay)

**Purpose:** Real-time celebration when constellation unlocks during chat

**Trigger:** Breakthrough detected OR weekly reflection completed

### Layout Structure

```
┌─────────────────────────────┐
│                             │
│     [Dimmed chat behind]    │
│                             │
│   ┌───────────────────┐     │
│   │                   │     │
│   │   🌟 You've       │     │
│   │   unlocked        │     │
│   │                   │     │
│   │  ┌─────────────┐  │     │  ← Dark window
│   │  │  Leo in     │  │     │     with constellation
│   │  │  dark space │  │     │     appearing
│   │  └─────────────┘  │     │
│   │                   │     │
│   │      Leo          │     │
│   │   🦁 Courage      │     │
│   │                   │     │
│   │  [View Details]   │     │
│   │  [Continue Chat]  │     │
│   │                   │     │
│   └───────────────────┘     │
│                             │
└─────────────────────────────┘
```

### Component Breakdown

**Modal Overlay:**
- Background: `rgba(0, 0, 0, 0.6)` - dim chat behind
- Blur chat content slightly
- Center modal card

**Celebration Card (Warm):**
- Background: White (#FFF)
- Padding: 24px
- Border-radius: 24px
- Max-width: 340px
- Shadow: `0 10px 40px rgba(107, 89, 69, 0.25)`

**Content Structure:**
1. **Celebration Header**
   - Text: "🌟 You've unlocked a constellation!"
   - Size: 20px
   - Weight: 600
   - Color: `#6B5945`
   - Text-align: Center

2. **Celestial Window (Medium)**
   - Height: 200px
   - Same dark space aesthetic
   - Constellation appears with animation
   - Stars connect with lines
   - Gentle glow effect

3. **Constellation Info**
   - Name: 22px, centered
   - Category tag: Emoji + category name
   - Brief mythology teaser (1 sentence)

4. **Action Buttons**
   - **Primary:** "View Details" (gold gradient, full-width)
   - **Secondary:** "Continue Chat" (outlined, warm brown)
   - Gap: 12px between buttons

### Animation Sequence

**Duration:** 3 seconds total

**Timeline:**
1. **0.0s** - Modal fades in, chat blurs
2. **0.3s** - Celebration card slides up from bottom
3. **0.6s** - Dark window appears
4. **1.0s** - Stars appear one by one (0.2s intervals)
5. **2.0s** - Lines connect stars
6. **2.5s** - Gentle glow pulse
7. **3.0s** - Buttons become active

**User Control:**
- Can tap "Continue Chat" to dismiss immediately (no forced waiting)
- Can tap "View Details" to go to detail screen
- Can tap outside modal to dismiss (goes back to chat)

---

## Screen 4: Constellation Detail from Chat (Contextual)

**Purpose:** When user taps breakthrough moment link in past chat

**Trigger:** User reviewing old conversation, taps constellation reference

**Layout:** Same as Screen 2 (Constellation Detail)

**Additional Context:**
- Breadcrumb: "From your chat on Oct 10"
- Conversation snippet shown above breakthrough quote
- CTA: "Return to conversation" instead of "View conversation"

---

## Screen 5: Breakthrough Marking (In-Chat Action)

**Purpose:** User manually marks a message as meaningful

**Trigger:** Long-press on Jaimee's message OR tap "..." menu → "Mark as breakthrough"

### UI Flow

**Step 1: Message Action Menu**
```
┌─────────────────────┐
│ Jaimee's message    │
│ "That's a great..." │ ← Long-press this
└─────────────────────┘
         ↓
┌─────────────────────┐
│ Copy               │
│ ✨ Mark Breakthrough│ ← New option
│ Share              │
└─────────────────────┘
```

**Step 2: Category Selection (Optional)**
```
┌───────────────────────────┐
│  This moment feels like:  │
│                           │
│  🌊 Emotional insight     │
│  🦁 Courageous action     │
│  🧘 Mindful presence      │
│  ✨ Let Jaimee decide     │
│                           │
│  [Cancel]                 │
└───────────────────────────┘
```

**Step 3: Confirmation & Unlock**
- If triggers constellation unlock → Show Screen 3 (Celebration)
- If just recording (no unlock) → Toast: "Breakthrough moment saved ✨"

### Design Details

**Action Sheet (Bottom Sheet):**
- Background: White
- Border-radius: 24px 24px 0 0
- Padding: 20px
- Shadow: `0 -4px 20px rgba(107, 89, 69, 0.15)`

**Category Options:**
- Radio buttons or large tap targets
- Each option: 48px height (easy to tap)
- Icon + text
- Hover: Light gold background

**Accessibility:**
- Large tap targets (minimum 44x44px)
- Clear labels
- Can dismiss by tapping outside or Cancel button

---

## Screen 6: Category Progress (Stats View)

**Purpose:** Detailed progress for a specific category

**Trigger:** Tap category header from Sky overview (optional feature)

### Layout Structure

```
┌─────────────────────────────┐
│ [←] Path of Courage         │
├─────────────────────────────┤
│                             │
│  Progress Card (Warm)       │
│  ───────────────            │
│  4 / 27 constellations      │
│  ████████░░░░░░░░░░ 15%     │
│                             │
│  Next milestone:            │
│  Unlock 5 more for          │
│  "Brave Explorer" badge     │
│                             │
├─────────────────────────────┤
│                             │
│  Unlocked (4)               │
│  ┌─────┐ ┌─────┐           │
│  │ Leo │ │Aries│           │
│  └─────┘ └─────┘           │
│                             │
│  Locked (23)                │
│  ┌─────┐ ┌─────┐ ┌─────┐  │
│  │ dim │ │ dim │ │ dim │  │
│  └─────┘ └─────┘ └─────┘  │
│                             │
└─────────────────────────────┘
```

**Optional feature - Phase 2 or 3**

---

## Screen 7: Weekly Reflection Prompt (Modal)

**Purpose:** Prompt user for weekly reflection (Phase 2 feature)

**Trigger:** Sunday 9am (user's timezone) OR user-initiated

### Layout Structure

```
┌─────────────────────────────┐
│  Weekly Reflection          │
│  ─────────────────          │
│                             │
│  What's changed for you     │
│  this week? Any insights    │
│  or realizations?           │
│                             │
│  ┌─────────────────────────┐│
│  │                         ││
│  │  [Text input area]      ││  ← Multi-line
│  │                         ││     text field
│  │                         ││
│  └─────────────────────────┘│
│                             │
│  How would you rate your    │
│  growth this week?          │
│                             │
│  ⭐ ⭐ ⭐ ⭐ ☆             │  ← Self-rating
│                             │
│  [Submit Reflection]        │
│                             │
└─────────────────────────────┘
```

**Card Style:** Same warm Jaimee card aesthetic
**Background:** Dimmed app behind modal
**Dismissible:** Can skip, not forced

---

## Screen 8: Celebration Ritual (Weekly Review)

**Purpose:** Quick visual celebration of progress (2-3 min experience)

**Trigger:** After weekly reflection OR user-initiated "Celebrate my progress"

### Layout Structure

**Full-screen immersive experience:**

```
┌─────────────────────────────┐
│          [×]                │  ← Close (top-right)
├─────────────────────────────┤
│                             │
│   This Week's Journey       │  ← Title overlay
│                             │
│  [Warm background or        │  ← Could be warm
│   gentle twilight]          │     gradient or
│                             │     stay cream
│   ┌────┐  ┌────┐  ┌────┐   │  ← Highlighted
│   │Leo │  │New │  │New │   │     constellations
│   └────┘  └────┘  └────┘   │     from this week
│                             │
│   You unlocked 3 new        │  ← Summary text
│   constellations this week  │
│                             │
│  [See Full Sky]             │  ← CTA
│                             │
└─────────────────────────────┘
```

**Animation:**
- Fade in title
- Constellations appear one by one with gentle sparkle
- Summary text fades in
- Ambient music (optional, user can disable)

**Duration:**
- Auto-plays for ~10 seconds
- User can tap through faster
- User can dismiss anytime (× button)

---

## Component Specifications

### Component 1: Celestial Window (Reusable)

**Sizes:**
- **Mini:** 120px height (Sky overview grid)
- **Medium:** 200px height (Unlock celebration)
- **Large:** 280px height (Detail view)

**Base Structure:**
```dart
Container(
  height: size,
  decoration: BoxDecoration(
    borderRadius: BorderRadius.circular(12),
    gradient: LinearGradient(
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
      colors: [Color(0xFF0a0a1f), Color(0xFF1a1a3e)],
    ),
    border: Border.all(
      color: Color(0xFFF4D9A6).withOpacity(0.25),
      width: 2,
    ),
    boxShadow: [
      BoxShadow(
        color: Colors.black.withOpacity(0.3),
        blurRadius: 20,
        offset: Offset(0, 0),
        blurStyle: BlurStyle.inner,
      ),
    ],
  ),
  child: Stack(
    children: [
      // Nebula layer
      // Background stars layer
      // Constellation layer
      // Particles layer
    ],
  ),
)
```

**Layers (bottom to top):**

1. **Nebula Layer** (Background effect)
   - Radial gradient with low opacity blue/purple
   - Animated subtle drift (30s loop)
   - `AnimatedContainer` or `TweenAnimationBuilder`

2. **Background Stars Layer** (Ambient stars)
   - Random positioned white dots (1-2px)
   - Twinkling animation (3s ease-in-out loop)
   - Opacity varies (0.3 to 1.0)
   - Count: 5-10 stars depending on window size

3. **Constellation Layer** (Main content)
   - **Lines:** CustomPaint with warm gold color (`rgba(244, 217, 166, 0.6)`)
   - **Star nodes:** Positioned absolutely
   - **Glow effects:** BoxShadow with warm gold

4. **Particles Layer** (Optional ambient)
   - Floating golden particles
   - Slow upward drift
   - Very subtle, 3-5 particles

**Star Node (Inside Celestial Window):**
```dart
Container(
  width: starSize,  // 12-16px depending on window size
  height: starSize,
  decoration: BoxDecoration(
    shape: BoxShape.circle,
    gradient: RadialGradient(
      colors: [
        Colors.white,
        Color(0xFFFFE8D6),
        Color(0xFFF4D9A6),
      ],
    ),
    boxShadow: [
      BoxShadow(
        color: Color(0xFFF4D9A6).withOpacity(0.9),
        blurRadius: 10,
        spreadRadius: 2,
      ),
    ],
  ),
)
```

**Animation:** Gentle scale pulse (2s ease-in-out loop, scale 1.0 to 1.1)

---

### Component 2: Constellation Card (Shell)

**Variants:**
- **Mini** (Sky overview): 160px width, 12px padding
- **Full** (Detail view): Max 450px width, 20px padding

**Base Properties:**
```dart
Container(
  decoration: BoxDecoration(
    color: Colors.white,
    borderRadius: BorderRadius.circular(variant == 'mini' ? 16 : 24),
    border: Border.all(
      color: Color(0xFFF4D9A6).withOpacity(0.2),
      width: 2,
    ),
    boxShadow: [
      BoxShadow(
        color: Color(0xFF6B5945).withOpacity(0.1),
        blurRadius: 15,
        offset: Offset(0, 4),
      ),
    ],
  ),
  child: Column(
    children: [
      // Celestial Window
      // Card Footer/Content
    ],
  ),
)
```

**Hover/Press State:**
- `transform: translateY(-5px)` (lift)
- Increase shadow blur to 25
- Increase border opacity to 0.5
- Transition: 300ms ease

---

### Component 3: Category Header

**Structure:**
```dart
Container(
  padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
  decoration: BoxDecoration(
    color: Colors.white.withOpacity(0.7),
    borderRadius: BorderRadius.circular(16),
    border: Border(
      left: BorderSide(
        color: categoryColor,  // #E8B870 for Courage
        width: 4,
      ),
    ),
  ),
  child: Row(
    mainAxisAlignment: MainAxisAlignment.spaceBetween,
    children: [
      Row(
        children: [
          Text(categoryEmoji),  // 🌊, 🦁, or 🧘
          SizedBox(width: 10),
          Text('Path of ${categoryName}'),
        ],
      ),
      Text('$unlocked / $total'),
    ],
  ),
)
```

**Category Colors:**
- Emotion: `#A8C5DA` (soft blue)
- Courage: `#E8B870` (warm gold)
- Presence: `#C8A8BE` (soft lavender)

---

### Component 4: Rarity Badge

**Variants:**
- **Small** (12px height, 11px text) - Mini cards
- **Medium** (14px height, 12px text) - Detail cards

**Structure:**
```dart
Container(
  padding: EdgeInsets.symmetric(horizontal: 14, vertical: 6),
  decoration: BoxDecoration(
    gradient: LinearGradient(
      colors: rarityGradient,  // Based on tier
    ),
    borderRadius: BorderRadius.circular(20),
    boxShadow: [
      BoxShadow(
        color: rarityColor.withOpacity(0.3),
        blurRadius: 8,
        offset: Offset(0, 2),
      ),
    ],
  ),
  child: Text(
    rarityName.toUpperCase(),
    style: TextStyle(
      fontSize: 11,
      fontWeight: FontWeight.w700,
      letterSpacing: 1.2,
      color: Color(0xFF6B5945),
    ),
  ),
)
```

**Rarity Gradients:**
- Common: `[#F0F0F0, #E0E0E0]` (light gray)
- Rare: `[#E8B870, #D4A868]` (warm gold)
- Epic: `[#B8A0D8, #A890C8]` (soft purple)
- Legendary: `[#FFD700, #FFC700]` (bright gold with glow)

---

### Component 5: Breakthrough Moment Box

**Structure:**
```dart
Container(
  decoration: BoxDecoration(
    gradient: LinearGradient(
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
      colors: [
        Color(0xFFF4D9A6).withOpacity(0.15),
        Color(0xFFE8B870).withOpacity(0.1),
      ],
    ),
    borderRadius: BorderRadius.only(
      topRight: Radius.circular(12),
      bottomRight: Radius.circular(12),
    ),
    border: Border(
      left: BorderSide(
        color: Color(0xFFE8B870),
        width: 4,
      ),
    ),
  ),
  padding: EdgeInsets.all(16),
  margin: EdgeInsets.symmetric(vertical: 20),
  child: Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text('✨ YOUR BREAKTHROUGH MOMENT'),  // Label
      SizedBox(height: 8),
      Text('"$breakthroughText"'),          // Quote
      SizedBox(height: 12),
      GestureDetector(
        onTap: () => navigateToChat(),
        child: Text('→ View this conversation'),  // Link
      ),
    ],
  ),
)
```

---

### Component 6: Bottom Navigation (Enhanced)

**Constellation Tab Icon:**
- **Inactive:** `⭐` (outline star, gray)
- **Active:** `⭐` (filled star, gold gradient)
- **Notification Badge:** Red dot if new constellation unlocked (not yet viewed)

**Integration with existing nav:**
- Same style as current Jaimee bottom nav
- 4 items: Home, Chat, Constellations (new), Profile
- Height: 70px (including safe area)
- Haptic feedback on tap

---

## Interaction Patterns

### Tap Behaviors

**1. Tap Mini Constellation Card (Sky View)**
- **Immediate:** Card scales to 0.95 (press effect)
- **On Release:** Navigate to detail view with page transition
- **Transition:** Slide up from bottom (300ms ease)
- **Haptic:** Light impact

**2. Tap "View Breakthrough Chat" (Detail View)**
- **Action:** Navigate to Chat tab
- **State:** Chat scrolls to specific message
- **Highlight:** Breakthrough message briefly highlighted (gold background fade)
- **Duration:** Highlight fades after 2s

**3. Long-press Jaimee Message (Chat)**
- **Immediate:** Message scales slightly (1.02x)
- **After 600ms:** Show action menu with "Mark Breakthrough" option
- **Haptic:** Medium impact when menu appears

**4. Tap Outside Modal**
- **Action:** Dismiss modal (celebration, reflection prompt)
- **Animation:** Fade out modal, restore background
- **Duration:** 200ms

### Scroll Behaviors

**1. Sky Overview Scroll**
- **Behavior:** Standard vertical scroll
- **Header:** Sticky (stays visible during scroll)
- **Performance:** Lazy load constellation windows (render on-screen only)
- **Pull to refresh:** Check for new unlocks

**2. Detail View Scroll**
- **Behavior:** If mythology text is long, card scrolls internally
- **Alternative:** Full-screen scroll (card is part of scroll view)

### Swipe Gestures

**1. Swipe Between Constellations (Detail View - Optional)**
- **Left swipe:** Next constellation
- **Right swipe:** Previous constellation
- **Visual feedback:** Card slides, new card slides in
- **Boundary:** Can't swipe past first/last constellation

**2. Dismiss Modal**
- **Down swipe on celebration modal:** Dismiss (alternative to buttons)
- **Threshold:** 100px swipe distance
- **Visual:** Card follows finger, fades if past threshold

---

## Animation & Micro-interactions

### Animation Principles

**1. Gentle and Calming**
- No jarring or aggressive animations
- Smooth easing curves (ease-in-out)
- Therapeutic context requires calm movements

**2. Meaningful, Not Decorative**
- Every animation serves a purpose
- Celebration animations are joyful but not overwhelming
- Can be reduced or disabled (accessibility)

**3. Performance First**
- 60fps target on all animations
- GPU-accelerated transforms only (translate, scale, opacity)
- No layout-thrashing animations

### Key Animations

**1. Constellation Unlock Celebration**

**Sequence:**
```
1. Modal fade in (200ms)
   - Opacity 0 → 1
   - Background blur chat

2. Card slide up (400ms, ease-out)
   - TranslateY(50px) → TranslateY(0)
   - Slight overshoot for playfulness

3. Dark window appears (300ms)
   - Opacity 0 → 1
   - Scale 0.9 → 1.0

4. Stars appear sequentially (1000ms total)
   - Each star: Opacity 0 → 1, Scale 0 → 1
   - Stagger: 150ms between stars
   - Gold shimmer effect on appear

5. Lines draw connecting stars (800ms)
   - SVG line animation (stroke-dashoffset)
   - From center outward

6. Gentle glow pulse (ongoing)
   - Stars pulse softly
   - Scale 1.0 ↔ 1.1 (2s loop)

7. Buttons fade in (300ms)
   - Opacity 0 → 1
   - TranslateY(10px) → TranslateY(0)
```

**Total Duration:** ~3 seconds (can skip immediately)

**2. Star Twinkle (Background Stars)**
- **Loop:** 3-4 seconds
- **Property:** Opacity (0.3 → 1.0 → 0.3)
- **Easing:** ease-in-out
- **Stagger:** Random delay for each star (natural feel)

**3. Star Node Glow Pulse**
- **Loop:** 2.5 seconds
- **Property:** Scale (1.0 → 1.1 → 1.0)
- **Easing:** ease-in-out
- **Secondary:** Opacity (0.9 → 1.0)
- **Always active** on unlocked constellations

**4. Card Hover/Press**
- **On Press:** Scale to 0.97 (subtle press)
- **On Hover (tablets):** Lift -5px, increase shadow
- **Duration:** 200ms
- **Easing:** ease-out

**5. Page Transitions**
- **Sky → Detail:** Slide up (300ms)
- **Detail → Sky:** Slide down (300ms)
- **Chat → Sky:** Cross-fade (250ms)

**6. Nebula Drift (Subtle ambient)**
- **Loop:** 30-40 seconds
- **Property:** Transform (translateX, translateY)
- **Range:** ±10px movement
- **Easing:** ease-in-out
- **Purpose:** Adds life without distraction

---

### Micro-interactions

**1. Pull-to-Refresh (Sky View)**
- **Visual:** Warm gold spinner
- **Text:** "Checking for new constellations..."
- **Success:** Brief toast if new unlocks found
- **Empty:** Gentle bounce if no new unlocks

**2. Category Header Tap (Optional)**
- **Action:** Expand category to show stats
- **Visual:** Chevron icon rotates (▼ → ▲)
- **Expansion:** Smooth height animation
- **Content:** Progress bar, next milestone info

**3. Star Node Hover (Desktop/Tablet)**
- **Scale:** 1.0 → 1.2
- **Glow:** Increase intensity
- **Cursor:** Pointer
- **Tooltip:** Star name (optional)

**4. Breakthrough Link Tap**
- **Ripple:** Gold ripple effect from tap point
- **Navigation:** Smooth transition to chat
- **Highlight:** Target message highlighted briefly

**5. Achievement Unlocked (Confetti)**
- **Trigger:** Major milestones (category complete, celestial tier)
- **Visual:** Warm gold confetti particles
- **Duration:** 2 seconds
- **Style:** Subtle, not overwhelming (5-8 particles)

---

## State Management

### Constellation States

**Per Constellation:**
```typescript
{
  id: string
  constellation_key: string
  name: string
  category: 'emotion' | 'courage' | 'presence'

  // User-specific
  is_unlocked: boolean
  unlocked_at: timestamp | null
  unlock_type: 'breakthrough' | 'reflection' | 'manual'
  rarity_tier: 'common' | 'rare' | 'epic' | 'legendary'

  // Evolution (Phase 2)
  evolution_stage: 1 | 2 | 3
  revisit_count: number

  // Breakthrough anchor
  breakthrough_link: {
    chat_id: string
    session_id: string
    message_preview: string
  } | null

  // Content
  mythology_short: string
  mythology_full: string  // Phase 2
}
```

### Loading States

**1. Initial Load (Sky View)**
```
┌─────────────────────┐
│  Skeleton Screens   │
│                     │
│  ┌───┐ ┌───┐ ┌───┐ │  ← Shimmer effect
│  │░░░│ │░░░│ │░░░│ │     on placeholder cards
│  └───┘ └───┘ └───┘ │
└─────────────────────┘
```
- Show category headers immediately
- Skeleton cards for constellations
- Shimmer animation (warm gold shimmer)
- Duration: Until API data loads (~500ms target)

**2. Image Loading (Constellation Illustrations - Phase 2)**
- Placeholder: Constellation outline only
- Progressive: Fade in illustration when loaded
- Error: Fallback to outline + text

**3. Breakthrough Detection (Real-time)**
- No visible loading state (happens in background)
- User continues chatting normally
- Celebration appears when complete

### Error States

**1. Network Error (Can't Load Sky)**
```
┌─────────────────────┐
│   ☁️ Offline        │
│                     │
│  Can't load your    │
│  constellation sky  │
│                     │
│  Your progress is   │
│  saved. Try again   │
│  when connected.    │
│                     │
│  [Retry]            │
└─────────────────────┘
```
- Warm illustration (cloud icon)
- Reassuring copy (data is safe)
- Retry button (gold)

**2. Failed Breakthrough Detection**
- Silent failure (log error, don't interrupt chat)
- User can still manually mark breakthrough
- Background retry (post-conversation analysis catches it)

**3. Failed Unlock (Edge Case)**
- Show error toast: "Something went wrong. We're looking into it."
- Log detailed error for debugging
- Retry automatically in background

### Empty States

**1. No Constellations Yet (New User)**
```
┌─────────────────────────────┐
│                             │
│       ✨  ⭐  ✨            │
│                             │
│  Your Constellation Sky     │
│  is waiting for you         │
│                             │
│  Start chatting with Jaimee │
│  and watch your first       │
│  constellation appear when  │
│  you have a breakthrough    │
│  moment.                    │
│                             │
│  [Start Chatting]           │
│                             │
└─────────────────────────────┘
```

**2. Category Empty (0 unlocked in category)**
- Show locked constellation outlines
- Text: "Unlock your first [Category] constellation by [action]"
- Encouragement, not pressure

---

## User Flows

### Flow 1: First Constellation Unlock

**User Journey:**
```
1. User chatting with Jaimee (Chat tab)
   ↓
2. User has breakthrough moment
   "I just realized asking for help is brave!"
   ↓
3. AI detects breakthrough (background)
   ↓
4. Celebration modal appears (Screen 3)
   "You've unlocked Leo! 🦁"
   ↓
5. User choice:
   a) [View Details] → Navigate to detail screen
   b) [Continue Chat] → Dismiss modal, back to chat
   c) Tap outside → Dismiss, back to chat
   ↓
6. Red dot appears on ⭐ Constellations tab (unviewed)
   ↓
7. User taps Constellations tab
   ↓
8. Sees "My Constellation Sky" with first constellation
   ↓
9. Taps Leo card → Detail view
   ↓
10. Reads mythology, sees breakthrough quote
    ↓
11. Taps "View Breakthrough Chat"
    ↓
12. Returns to chat, scrolled to that message
```

**Total Steps:** 12
**Friction Points:** None (all optional, user-driven)
**Drop-off Risk:** Low (celebration is immediate and rewarding)

---

### Flow 2: Weekly Reflection (Phase 2)

**User Journey:**
```
1. Sunday 9am - Notification appears
   "Time for your weekly reflection ✨"
   ↓
2. User taps notification (optional - can skip)
   ↓
3. Reflection modal appears (Screen 7)
   "What's changed for you this week?"
   ↓
4. User writes reflection
   Types: "I've been more willing to speak up..."
   ↓
5. User rates growth (1-5 stars self-assessment)
   Selects: ⭐⭐⭐⭐ (4 stars)
   ↓
6. Taps [Submit Reflection]
   ↓
7. Loading state (30s max)
   "Jaimee is reflecting on your week..."
   ↓
8. AI analysis completes
   Depth score: 0.85 (high quality)
   Tier: Rare
   ↓
9. Unlock celebration appears
   "You've unlocked 2 constellations!"
   Shows both with staggered animation
   ↓
10. User views details or continues
```

**Total Time:** 2-5 minutes
**Can Skip:** Yes (no penalties)
**Frequency:** Weekly

---

### Flow 3: Manual Breakthrough Marking

**User Journey:**
```
1. User reviewing past chat with Jaimee
   ↓
2. Finds meaningful message from 2 days ago
   "You can't control others, only yourself"
   ↓
3. Long-presses message
   ↓
4. Action menu appears
   [Copy] [Mark Breakthrough] [Share]
   ↓
5. Taps "Mark Breakthrough"
   ↓
6. Category selection appears (optional)
   "This moment feels like:"
   🌊 Emotional insight
   🦁 Courageous action
   🧘 Mindful presence
   ✨ Let Jaimee decide
   ↓
7. User selects or lets AI decide
   ↓
8. System checks if triggers unlock
   ↓
9a. If YES: Unlock celebration appears
9b. If NO: Toast "Breakthrough saved ✨"
```

**Total Steps:** 9
**Time:** 10-15 seconds
**Friction:** Low (familiar long-press pattern)

---

### Flow 4: Browsing Constellation Sky

**User Journey:**
```
1. User taps ⭐ Constellations tab
   ↓
2. Sky view loads (500ms)
   Shows categories + unlocked/locked
   ↓
3. User scrolls through categories
   Sees: 5 Emotion, 4 Courage, 3 Presence
   ↓
4. Taps interesting constellation (e.g., Pisces)
   ↓
5. Detail view slides up
   Shows: Large celestial window + mythology + breakthrough
   ↓
6. User reads breakthrough quote
   "Oh, I remember this conversation!"
   ↓
7. Taps "View Breakthrough Chat"
   ↓
8. Navigates to chat, message highlighted
   ↓
9. User re-reads full conversation
   Emotional anchoring achieved ✓
   ↓
10. Taps back to return to Sky view
```

**Total Time:** 2-5 minutes (exploratory)
**Engagement Goal:** Users revisit breakthrough moments regularly

---

## Accessibility

### WCAG 2.1 AA Compliance

**Color Contrast:**
- **Text on warm backgrounds:** Minimum 4.5:1 ratio
  - `#6B5945` on `#FFF8F0` = 7.2:1 ✅
  - `#B8935C` on `#FFFFFF` = 4.8:1 ✅
- **Text in dark windows:** Minimum 4.5:1 ratio
  - `#FFFFFF` on `#0a0a1f` = 16:1 ✅

**Touch Targets:**
- Minimum: 44x44px (WCAG guideline)
- Constellation cards: 140px+ (well above minimum)
- Buttons: 48px height minimum
- Bottom nav: 50px+ tap targets

**Screen Reader Support:**
- **Constellation card:** "Leo constellation, courage category, unlocked October 10, rare tier"
- **Locked constellation:** "Pisces constellation, emotion category, locked. Unlock by having emotional breakthroughs."
- **Celestial window:** "Constellation visualization" (decorative, not critical info)
- **Breakthrough quote:** Read verbatim with context

**Reduced Motion:**
- Settings: "Reduce animations" toggle
- **If enabled:**
  - Disable star twinkling
  - Disable nebula drift
  - Disable celebration particles
  - Instant transitions (no slides)
  - Keep only essential feedback (scale on press)

**Dynamic Type:**
- Support iOS Dynamic Type scaling
- Text scales 80% to 150%
- Layout adjusts gracefully
- Celestial windows maintain aspect ratio

**Color Blind Modes:**
- Don't rely on color alone for category distinction
- Emoji + text labels always present
- Rarity uses text + position + badge shape
- Test with Deuteranopia and Protanopia simulators

---

## Flutter Implementation Guide

### Widget Architecture

**Screen Structure:**
```dart
ConstellationSkyScreen
├─ AppBar (Sticky)
│  ├─ BackButton
│  ├─ Title
│  └─ ProgressBadge
├─ Body (ScrollView)
│  ├─ IntroCard (Warm)
│  ├─ CategorySection (Emotion)
│  │  ├─ CategoryHeader
│  │  └─ ConstellationGrid
│  │     ├─ MiniConstellationCard
│  │     ├─ MiniConstellationCard
│  │     └─ ... (responsive grid)
│  ├─ CategorySection (Courage)
│  └─ CategorySection (Presence)
└─ BottomNavigationBar
```

### Key Widgets

**1. CelestialWindow (Reusable)**
```dart
class CelestialWindow extends StatefulWidget {
  final double height;
  final List<StarNode> stars;
  final List<ConstellationLine> lines;
  final bool isLocked;
  final ConstellationCategory category;

  @override
  _CelestialWindowState createState() => _CelestialWindowState();
}

class _CelestialWindowState extends State<CelestialWindow>
    with TickerProviderStateMixin {
  late AnimationController _nebulaController;
  late AnimationController _twinkleController;

  @override
  void initState() {
    super.initState();
    _nebulaController = AnimationController(
      duration: Duration(seconds: 30),
      vsync: this,
    )..repeat(reverse: true);

    _twinkleController = AnimationController(
      duration: Duration(seconds: 3),
      vsync: this,
    )..repeat();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: widget.height,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFF0a0a1f), Color(0xFF1a1a3e)],
        ),
        border: Border.all(
          color: Color(0xFFF4D9A6).withOpacity(0.25),
          width: 2,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 20,
            blurStyle: BlurStyle.inner,
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: Stack(
          children: [
            _buildNebula(),
            _buildBackgroundStars(),
            _buildConstellation(),
            if (!widget.isLocked) _buildParticles(),
          ],
        ),
      ),
    );
  }

  Widget _buildNebula() {
    return AnimatedBuilder(
      animation: _nebulaController,
      builder: (context, child) {
        return Transform.translate(
          offset: Offset(
            _nebulaController.value * 10,
            -_nebulaController.value * 10,
          ),
          child: Container(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                center: Alignment(0.5, 0.5),
                radius: 0.6,
                colors: [
                  Color(0xFF507898).withOpacity(0.15),
                  Colors.transparent,
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  // ... (additional build methods)
}
```

**2. MiniConstellationCard**
```dart
class MiniConstellationCard extends StatelessWidget {
  final Constellation constellation;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: constellation.isUnlocked ? onTap : null,
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: Color(0xFFF4D9A6).withOpacity(0.2),
            width: 2,
          ),
          boxShadow: [
            BoxShadow(
              color: Color(0xFF6B5945).withOpacity(0.1),
              blurRadius: 15,
              offset: Offset(0, 4),
            ),
          ],
        ),
        child: Padding(
          padding: EdgeInsets.all(12),
          child: Column(
            children: [
              CelestialWindow(
                height: 120,
                stars: constellation.stars,
                lines: constellation.lines,
                isLocked: !constellation.isUnlocked,
                category: constellation.category,
              ),
              SizedBox(height: 10),
              Text(
                constellation.name,
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: Color(0xFF6B5945),
                ),
              ),
              SizedBox(height: 4),
              Text(
                constellation.isUnlocked
                    ? constellation.rarityTier
                    : 'Locked',
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w500,
                  color: Color(0xFFB8935C),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
```

**3. UnlockCelebrationModal**
```dart
class UnlockCelebrationModal extends StatefulWidget {
  final Constellation constellation;
  final VoidCallback onViewDetails;
  final VoidCallback onContinue;

  @override
  _UnlockCelebrationModalState createState() =>
      _UnlockCelebrationModalState();
}

class _UnlockCelebrationModalState extends State<UnlockCelebrationModal>
    with TickerProviderStateMixin {
  late AnimationController _sequenceController;
  late Animation<double> _cardSlideUp;
  late Animation<double> _windowFade;
  late List<Animation<double>> _starAnimations;

  @override
  void initState() {
    super.initState();

    _sequenceController = AnimationController(
      duration: Duration(milliseconds: 3000),
      vsync: this,
    );

    // Card slides up
    _cardSlideUp = CurvedAnimation(
      parent: _sequenceController,
      curve: Interval(0.0, 0.2, curve: Curves.easeOut),
    );

    // Window appears
    _windowFade = CurvedAnimation(
      parent: _sequenceController,
      curve: Interval(0.2, 0.4, curve: Curves.easeIn),
    );

    // Stars appear sequentially
    _starAnimations = List.generate(
      widget.constellation.stars.length,
      (index) => CurvedAnimation(
        parent: _sequenceController,
        curve: Interval(
          0.4 + (index * 0.1),
          0.6 + (index * 0.1),
          curve: Curves.easeOut,
        ),
      ),
    );

    _sequenceController.forward();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => Navigator.pop(context),
      child: Scaffold(
        backgroundColor: Colors.black.withOpacity(0.6),
        body: Center(
          child: GestureDetector(
            onTap: () {}, // Prevent modal dismiss when tapping card
            child: AnimatedBuilder(
              animation: _sequenceController,
              builder: (context, child) {
                return Transform.translate(
                  offset: Offset(0, 50 * (1 - _cardSlideUp.value)),
                  child: Opacity(
                    opacity: _cardSlideUp.value,
                    child: _buildCelebrationCard(),
                  ),
                );
              },
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildCelebrationCard() {
    return Container(
      width: 340,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: Color(0xFF6B5945).withOpacity(0.25),
            blurRadius: 40,
            offset: Offset(0, 10),
          ),
        ],
      ),
      padding: EdgeInsets.all(24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            '🌟 You\'ve unlocked a constellation!',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w600,
              color: Color(0xFF6B5945),
            ),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 20),
          // Animated celestial window
          // ... (constellation appears with star sequence)
          SizedBox(height: 16),
          // Action buttons
        ],
      ),
    );
  }
}
```

### Performance Optimizations

**1. Lazy Loading**
- Only render celestial windows for on-screen cards
- Use `ListView.builder` with `addAutomaticKeepAlives: false`
- Cache rendered constellations (don't re-render on scroll)

**2. Animation Performance**
- Use `Transform` and `Opacity` (GPU-accelerated)
- Avoid `Container` size animations (layout-thrashing)
- Dispose animation controllers properly
- Limit simultaneous animations (max 10 twinkling stars visible)

**3. Image Assets (Phase 2)**
- Use vector SVGs for constellations
- Lazy load Phase 3 illustrations
- Cache images with `cached_network_image`
- Provide low-res placeholders

**4. State Management**
- Use `Provider` or `Riverpod` for constellation state
- Cache API responses (5 min TTL)
- Optimistic updates (show unlock immediately, sync in background)

---

## Design System - Complete Reference

### Constellation Categories

**Visual Identity:**

| Category | Emoji | Color | Vibe |
|----------|-------|-------|------|
| Emotion | 🌊 | `#A8C5DA` Soft blue | Flowing, gentle, water |
| Courage | 🦁 | `#E8B870` Warm gold | Bold, warm, fire |
| Presence | 🧘 | `#C8A8BE` Soft lavender | Calm, balanced, air |

**Usage:**
- Category headers: Border-left color
- Badges: Background tint
- Star glow: Subtle category-color tint (Phase 2 evolution)

### Rarity Tiers

**Visual Treatment:**

| Tier | Badge Color | Glow | Use Case |
|------|-------------|------|----------|
| Common | Silver-gray | None | Weekly reflection baseline |
| Rare | Warm gold | Subtle | Quality reflection or single breakthrough |
| Epic | Soft purple | Medium | Multiple breakthroughs |
| Legendary | Bright gold | Strong | Exceptional breakthrough week |

**Subtle Differentiation:**
- Badge only (not on constellation itself)
- No functional difference (all constellations evolve equally)
- Personal pride, not competitive advantage

---

## Phase 2 & 3 Design Notes

### Evolution Stages (Phase 2)

**Stage 1: Stars (Current MVP)**
- Individual star nodes, no connecting lines
- Current POC shows this

**Stage 2: Connected Lines**
- Lines connect stars to form constellation shape
- Category-specific line styles:
  - Emotion: Flowing, organic curves
  - Courage: Bold, angular lines
  - Presence: Balanced, symmetrical lines
- Unlock trigger: Revisit growth area 3+ times

**Stage 3: Illustrated Glory**
- Full mythological illustration overlaid
- Requires separate illustration asset
- Unlock trigger: Create wisdom note
- Most visually impressive stage

**UI Impact:**
- Add evolution progress indicator to detail card
- Show "2/3 Stars Connected" with progress bar
- Celebrate evolution unlock (similar to initial unlock)

### Celestial Levels (Phase 3)

**Tier 1: Custom Constellation Creator**
- New screen: Constellation design tool
- UI: Star placement canvas, name input, mythology input
- Style: Maintains warm Jaimee aesthetic with celestial window preview

**Tier 2: Meta-Abilities**
- Badge on profile: "Brave Heart Ability Unlocked"
- Subtle UI indicator (gold star on chat?)
- No intrusive notifications

**Tier 3: Mentor Wisdom Notes**
- New section in detail view: "Wisdom from others"
- Opt-in modal when tier unlocked
- Moderation queue (admin panel - separate spec)

---

## Technical Specifications

### API Integration Points

**GET /api/v1/constellations/sky**
- **When:** Screen loads
- **Caching:** 5 minutes
- **Loading:** Show skeleton
- **Error:** Show error state with retry

**POST /api/v1/constellations/breakthrough/mark**
- **When:** User marks breakthrough
- **Optimistic:** Show "saving..." immediately
- **Success:** Update local state
- **Error:** Revert + show error toast

**WebSocket/Events (Realtime Unlock)**
- **Listen:** `constellation_unlocked` events
- **Action:** Show celebration modal immediately
- **Fallback:** Poll every 30s if WebSocket disconnected

### Asset Requirements

**Phase 1 (MVP):**
- Constellation line coordinates (JSON or hardcoded)
- Category emoji (🌊, 🦁, 🧘)
- System icons (back, close, nav icons)

**Phase 2:**
- 88 constellation line coordinates
- Evolution stage assets (lines, partial illustrations)

**Phase 3:**
- 88 full mythological illustrations (Stage 3)
- Custom constellation creator UI assets

### Animation Libraries

**Recommended:**
- `flutter_animate` - Easy declarative animations
- `lottie` - Complex celebration animations (optional)
- `shimmer` - Loading skeleton effect
- Built-in `AnimationController` for custom animations

---

## Design Rationale Summary

### Why Hybrid Dark Window Works

**1. Psychological Safety**
- Warm Jaimee structure = familiar, safe, comfortable
- Dark celestial windows = contained magic (not overwhelming)
- Like looking through a telescope - controlled view of wonder

**2. Visual Hierarchy**
- Clear separation: Structure (warm) vs Content (mystical)
- Easy to understand: "Jaimee shows me my constellations"
- Doesn't compete - each aesthetic has its role

**3. Brand Cohesion**
- Entire app structure stays consistent (cards, nav, colors)
- Constellation feature doesn't feel like separate app
- Users stay in familiar, safe environment

**4. Emotional Journey**
- Warm = safe, supportive, present (Jaimee's core)
- Dark celestial = mystery, wonder, growth (constellation magic)
- Together = supported journey into self-discovery

**5. Technical Feasibility**
- Reuses existing Jaimee components (cards, nav)
- Dark windows are contained `Container` widgets
- No full-app theme switching required
- Easy to build and maintain

---

## Visual Reference Files

**POC Prototypes Created:**
1. `docs/ux-ui/poc-hybrid-card-window.html` - **Chosen detail card style**
2. `docs/ux-ui/poc-full-sky-hybrid-dark.html` - **Chosen sky overview style**
3. `docs/ux-ui/poc-warm-twilight-constellation.html` - Alternative (not chosen)
4. `docs/ux-ui/poc-vintage-astronomy.html` - Alternative (not chosen)

**Existing References:**
1. `docs/ux-ui/skyrim_constellation_hybrid.html` - Original inspiration
2. `docs/ux-ui/jaimee-screenshots/` - Current app screenshots

**Analysis:**
1. `docs/ux-ui/design-approaches-analysis.md` - Design decision rationale

---

## Next Steps for Implementation

**1. Review & Approval**
- Stakeholder review of POCs (open HTML files in browser)
- User testing with target audience (women using therapeutic apps)
- Feedback on emotional tone and visual balance

**2. Design Assets Production**
- Constellation coordinates for 20-30 MVP constellations
- Category icons and badges
- Animation asset preparation

**3. Flutter Development Handoff**
- Share this spec with Flutter team
- Provide POC HTMLs as visual reference
- Define API contracts (already in PRD.md)

**4. Iterative Refinement**
- Build prototype in Flutter
- Test on devices (iOS/Android)
- Refine animations and interactions
- Accessibility audit

---

## Success Metrics (UX)

**Engagement:**
- 60%+ of users visit Constellation tab weekly
- Average 3+ minutes per visit (browsing, reminiscing)
- 80%+ of unlocks result in viewing detail card

**Emotional Resonance:**
- User sentiment: "I love seeing my progress" (qualitative feedback)
- Breakthrough moment revisits: 40%+ users tap "View conversation" link
- Weekly reflection participation: 50%+ (if prompted)

**Usability:**
- Task completion: 95%+ can find and view constellations
- Error rate: <5% on breakthrough marking
- Accessibility: 100% screen reader navigation success

---

_This UX specification defines the complete user experience for Jaimee's Constellation Gamification System using the Hybrid Dark Window aesthetic. The design balances mystical constellation wonder with Jaimee's warm, therapeutic personality, creating an emotional memory palace that feels both magical and safe._

_Created by Sally (UX Designer) on 2025-11-22, based on collaborative design exploration with BMad._
