# Brainstorming Session Results - WORK IN PROGRESS

**Session Date:** 2025-11-07
**Facilitator:** Business Analyst Mary
**Participant:** BMad
**Status:** COMPLETED
**Last Updated:** 2025-11-22

## Executive Summary

**Topic:** Constellation Gamification Feature for jaimee-constellations chatbot app

**Session Goals:**
- Refine and evaluate existing constellation feature ideas
- Explore user experience and engagement mechanics
- Prioritize directions before technical implementation

**Techniques Used:** SCAMPER Method (Complete - All 7 phases)

**Chatbot Core Purpose:** Safe, Supportive, Present

## Initial Ideas (Starting Point)

The team began with these feature concepts:
1. Digital Sky Map - Personal night sky that fills with collected constellations
2. Rarity Tiers - Common, rare, and legendary constellations
3. Constellation Stories - Mythology and facts unlock with each constellation
4. Constellation Powers - Each grants perks/abilities in the chatbot
5. Trading System - Exchange duplicates with friends
6. Seasonal/Event Constellations - Limited-time special releases
7. AR Integration - View constellations overlaid on real night sky
8. Constellation Building - Collect stars and connect them (puzzle element)
9. Evolution System - Constellations become more elaborate over time
10. Zodiac Bonuses - Special rewards for receiving your zodiac sign
11. Custom Constellations - Create your own at high levels

## SCAMPER Session - Key Discoveries

### S - SUBSTITUTE: What Could You Replace?

**MAJOR BREAKTHROUGH: Trigger-Based Earning System**

❌ **OLD:** Random constellation reward upon leveling up (XP-based)
✅ **NEW:** Constellations earned through meaningful interaction milestones

**Trigger Event Categories:**
- Completing challenges
- Emotional milestones (first vulnerable moment, breakthrough insights)
- Conversation depth markers
- Therapeutic goal completion
- Consistency streaks

**Three Constellation Categories (Skyrim-Inspired Design)**

Modeled after Skyrim's Mage/Thief/Warrior skill trees:

1. **EMOTION** - Understanding and feeling your inner world
   - Earned through: Emotional awareness, processing feelings, emotional breakthroughs

2. **COURAGE** - Taking action on your journey despite fear
   - Earned through: Downloading app, starting conversations, facing difficult topics, vulnerability

3. **PRESENCE** - Being grounded, mindful, and in the moment
   - Earned through: Mindfulness practice, staying engaged, being present in conversations

**Progression Arc:** Feel → Act → Be

**Multi-Tiered Progression System**

✅ **Tier 1:** Individual constellations (88 total across 3 categories)
✅ **Tier 2:** Category completion gates
✅ **Tier 3:** CELESTIAL LEVELS - Meta-progression unlocked after completing ALL constellations in a category

**Benefits of This System:**
- Short-term goals (next constellation)
- Medium-term goals (complete a category)
- Long-term aspirational goals (celestial levels)
- Rewards feel earned and meaningful, not random
- Aligns constellations with user growth journey

**Mapping Constellations to Categories:**
- Emotion achievements → Pisces, Cancer (water signs, emotional)
- Courage achievements → Leo, Aries (fire signs, bold)
- Presence achievements → TBD based on mindfulness themes

### C - COMBINE: What Could You Merge Together?

**MAJOR BREAKTHROUGH: 3-Stage Evolution System**

**Combined:** Evolution System + Category-Specific Practice

**Design Principle:** Universal 3-Stage Evolution for ALL 88 Constellations

**Evolution Stages (Using Leo Example):**

1. **Stage 1: Stars**
   - Initial unlock
   - Scattered points of light
   - Basic achievement

2. **Stage 2: Connected Lines**
   - Deeper engagement with related skills
   - Constellation pattern becomes visible
   - Progress milestone

3. **Stage 3: Illustrated Glory**
   - Mastery of related practice
   - Full mythological figure revealed in majestic detail
   - Leo appears as a proud, regal lion
   - Visual reward for sustained growth

**Evolution Triggers by Category:**
- **Emotion constellations** evolve through continued emotional milestones
- **Courage constellations** evolve through brave actions and risk-taking
- **Presence constellations** evolve through mindfulness practice depth

**Design Equity Principle:**
✅ Every constellation is equally stunning in its final form
✅ No hierarchy of "better" artwork
✅ 88 unique, majestic illustrated beings
✅ Equal desirability across all constellations

**System Benefits:**
- Visual progression that feels rewarding
- Reasons to revisit and deepen practice
- Beautiful end-state artwork to aspire toward
- Collection becomes more impressive over time
- Consistent, learnable system

**Other Combinations Identified:**

- **Shared Sky Visits:** Digital Sky Map + Trading System = Friends can visit your personal constellation sky
- **Story-Unlocked Abilities:** Constellation Stories + Constellation Powers = Reading mythology activates the power
- **Limited-Time Legendaries:** Rarity Tiers + Seasonal Events = Special event-only constellations
- **AR Evolution Display:** AR Integration + Evolution System = See YOUR evolved constellations overlaid on real night sky

### A - ADAPT: What Could You Borrow? (COMPLETED)

**Strategic Decisions Made:**
- ❌ **AR Integration**: Set aside per stakeholder feedback - can revisit later if desired
- ❌ **Daily Quests**: Too generic across gamification landscape - seeking more unique approach

**MAJOR BREAKTHROUGH: Breakthrough-Reflection Model**

**Adapted From:**
- **Therapy Session Models** → Breakthrough moments detection
- **Journal/Diary Reflection** → Weekly depth-based reflections
- **Choose Your Own Adventure** → Intentional emotional journey paths

**Core Innovation: Two Unlock Pathways**

**1. Breakthrough Moments (Real-Time Unlocks)**
- AI detects or user marks genuine insights: "This conversation helped me understand something"
- Constellation unlocks **immediately** as celebration
- Becomes **memory anchor** - tap constellation to revisit that exact breakthrough conversation
- Creates emotional bookmarks throughout user's journey

**2. Reflection Milestones (Weekly Depth-Based)**
- Every Sunday: "What's changed for you this week? Have you learned anything new?"
- **Hybrid depth analysis determines unlock:**
  - **Engagement Quality** (AI-analyzed): Genuine insight language, emotional vocabulary richness, concrete examples
  - **Self-Assessment** (User-choice): User rates their own growth (1-5 stars) - honors self-awareness
  - **Reflection Depth** (Length + specificity): Thoughtful, detailed reflections vs surface responses

**Constellation Unlock Formula:**
- **Baseline**: Showing up for reflection = Common constellation
- **Depth Bonus**: High quality reflection = Rare tier
- **Breakthrough Week**: Multiple breakthroughs + deep reflection = Epic/Legendary

**Key Differentiators:**
- ✅ Depth-based, NOT time-based or streak-based
- ✅ Celebrates authentic growth, not just participation
- ✅ No FOMO pressure ("I missed a day!")
- ✅ Constellations tied to real memories and insights
- ✅ Perfectly aligned with therapeutic chatbot purpose
- ✅ **Unique in the gamification landscape**

### M - MODIFY: What Could We Change or Alter? (IN PROGRESS - PAUSED)

**Modification Area 1: Enhanced 3-Stage Evolution System**

**Original:** Stars → Connected Lines → Illustrated Glory (universal)

**Modified to Include All Three Enhancements:**

**Stage 1: UNLOCK (Stars)**
- Earned through first achievement in that growth area
- Scattered star points appear
- **NEW: Category-specific subtle effects:**
  - **Emotion**: Soft shimmer/glow
  - **Courage**: Warm ember glow
  - **Presence**: Calm, steady pulse

**Stage 2: DEEPEN (Connected Lines)**
- **NEW Trigger**: Revisit that growth area 3+ times (shows commitment, not just one-time achievement)
- Constellation pattern becomes visible
- **NEW: Category-specific line styles:**
  - **Emotion**: Flowing, organic connections with gentle color
  - **Courage**: Bold, decisive lines with fire effects
  - **Presence**: Zen-like, balanced lines with calm aesthetics

**Stage 3: MASTERY (Illustrated Glory)**
- **NEW Trigger**: **Teach or share** what you learned
- User creates a "wisdom note" - reflection that could help someone else
- Full mythological illustration revealed
- Category-unique visual treatments maintain distinct feel

**❌ Stage Regression Mechanic (ELIMINATED)**
- Originally considered: Constellations fade if growth area untouched for 3-6 months
- **Decision:** REMOVED - Risks feeling punishing rather than motivating
- **Philosophy shift:** Trust users to engage authentically without punishment mechanics
- Growth is permanent, even if practice ebbs and flows

**Modification Area 2: Enhanced Category System**

**Original:** 88 constellations across 3 equal categories

**Modified to Include All Three Enhancements:**

**A) Weighted Category Balance (88 Total)**
- **Emotion (35 constellations)**: Largest set - foundation of therapeutic work
- **Courage (27 constellations)**: Action-oriented growth
- **Presence (26 constellations)**: Mindful grounding
- **User's primary path** (chosen at onboarding) influences which constellations appear first in their sky

**B) Hybrid/Intersection Constellations**
- Advanced constellations require progress in **multiple categories**
- Examples:
  - **"Vulnerability"**: Emotion + Courage intersection
  - **"Compassionate Action"**: Emotion + Presence intersection
  - **"Mindful Courage"**: Courage + Presence intersection
  - **"Wholeness"**: All three categories (ultimate constellation?)
- Appear at visual intersections in the sky map
- Unlocked only after achieving depth in required categories

**C) Evolving Category Names (Language Grows With User)**
- **Beginner language** (Onboarding): Feel → Act → Be
- **Intermediate unlock** (After 10 constellations in category):
  - Emotion → "Heart Wisdom"
  - Courage → "Bold Spirit"
  - Presence → "Grounded Being"
- **Mastery language** (After completing category):
  - Emotion → "Inner Knowing"
  - Courage → "Brave Heart"
  - Presence → "Mindful Soul"
- Language sophistication mirrors user's growth journey

**Modification Area 3: Celestial Levels - HYBRID 3-TIER SYSTEM**

**✅ DECISION: Combine All Three Approaches**

**Tier 1: Creation Power (Complete 1 Category)**
- Unlock ability to create **1 custom constellation** in that completed category
- Name it, define its personal mythology, design the star pattern
- Becomes a powerful reflection exercise on your unique journey
- Example: Complete all Emotion constellations → Create "My Heart's Truth" constellation
- **Rationale:** Personal, therapeutic, no social pressure, deeply meaningful

**Tier 2: Meta-Ability (Complete 2 Categories)**
- Unlock subtle AI enhancements based on completed categories
- Examples:
  - Emotion + Courage → "Brave Heart" ability (AI attuned to courageous vulnerability)
  - Courage + Presence → "Mindful Action" ability (AI recognizes grounded decision-making)
  - Emotion + Presence → "Compassionate Awareness" ability (AI supports emotional mindfulness)
- **Rationale:** Tangible benefit that enhances the core chatbot experience

**Tier 3: Mentor Role - OPTIONAL (Complete All 3 Categories)**
- *Option* (not requirement) to leave "wisdom notes" on constellations for other users
- Must explicitly opt-in (no pressure to participate)
- Community moderation system required
- Pay-it-forward for those who want to help light the way for others
- **Rationale:** Beautiful community feature, but completely optional

### P - PUT TO OTHER USES: What Else Could This Be Used For? (COMPLETED)

**✅ DECISION: Celebration Ritual**

**Core Concept:** Quick Visual Celebration (2-3 minutes)
- Weekly prompt (optional): "Want to celebrate this week's progress?"
- User-initiated: "Show me my constellations" button anytime
- After earning a constellation: "See your full sky?" option
- Visual sweep through constellations earned this period
- Brief moment to appreciate progress

**Multi-Purpose Benefits:**
- ✅ Gratitude practice (evidence-based wellbeing tool)
- ✅ Progress visualization (combats "I'm not making progress" cognitive distortion)
- ✅ Memory consolidation (reviewing breakthroughs strengthens learning)
- ✅ Mindfulness ritual (grounding practice)
- ✅ Celebration (positive reinforcement for growth)

**Philosophy:** Bite-sized joy, not another task - transforms constellations from mere collectibles into a therapeutic tool

**Other Possibilities Explored (Not Adopted):**
- Therapeutic journaling aid (timeline of growth)
- Progress sharing with therapist/coach
- Goal-setting framework
- Crisis support anchor (visual reminder of resilience)
- Personal mythology building

### E - ELIMINATE: What Should We Remove? (COMPLETED)

**✅ CONFIRMED ELIMINATIONS:**

**❌ #2: Trading System**
- **Removed because:** Undermines "earned through personal growth" philosophy
- Creates social pressure and comparison ("I need that constellation!")
- Turns meaningful achievements into commodities
- **Decision:** Constellations are personal and non-transferable
- Your constellation sky should reflect YOUR journey, not trades

**❌ #4: AR Integration**
- **Removed because:** Already set aside per earlier discussion
- High technical complexity for uncertain value
- Not core to therapeutic experience
- Can always revisit if desired in future
- **Decision:** Confirmed elimination

**❌ #8: Stage Regression (Fading Mechanic)**
- **Removed because:** Risks feeling punishing rather than motivating
- Creates anxiety: "I'm losing my progress!"
- Contradicts "safe, supportive" core value
- Growth isn't linear - sometimes we need breaks
- **Decision:** Once evolved, constellations stay evolved permanently

**Philosophy Shift:** Trust users to engage authentically without punishment mechanics. Growth is permanent, even if practice ebbs and flows.

### R - REVERSE: What If We Flipped It? (COMPLETED)

**Decision: No Reversals Adopted**

**Reversals Explored:**
1. Start full, remove instead of collect (less is more philosophy)
2. Hide your own sky, show only AI reflections (remove self-judgment)
3. Constellations appear during struggle, not after (companion vs reward)
4. Temporary constellations (reflect current state, not just history)
5. Constellations choose you (self-discovery vs self-declaration)
6. Mourn what's missing (aspirational focus vs retrospective pride)

**Conclusion:** All reversals felt wrong - **confirms the core design is solid as-is**. Sometimes the best decision is knowing when to stop. No need to overcomplicate what's working.

## Ideas Captured So Far

### Immediate Strong Concepts

1. **Trigger-Based Earning** - Constellations earned through meaningful milestones, not random XP leveling
2. **Three Categories** (Emotion, Courage, Presence) - Aligned with chatbot's "safe, supportive, present" purpose
3. **3-Stage Evolution System** - Stars → Lines → Illustrated Glory (applies to all 88 constellations)
4. **Skyrim-Inspired Gated Progression** - Complete category → Unlock Celestial Levels
5. **Universal Design Equity** - All constellations equally majestic in final form

### Features to Explore Further

- Digital Sky Map (enhanced with sharing/visiting)
- Rarity Tiers (how does this work with category system?)
- Constellation Stories unlocking powers
- Trading/Social elements
- Seasonal/Event constellations
- AR integration with evolved forms
- Celestial Levels (what ARE these?)
- Zodiac bonuses
- Custom constellations at high levels

## Key Questions to Explore When Session Resumes

1. **What are Celestial Levels?** What happens when someone completes all constellations in a category?
2. **How many constellations per category?** Need to divide 88 across Emotion, Courage, Presence
3. **Rarity system compatibility?** How do rarity tiers work with trigger-based earning?
4. **What constellation powers make sense?** How do they enhance chatbot experience without breaking it?
5. **Social/Trading mechanics?** How to implement without undermining earned progression?
6. **AR feasibility?** Technical complexity vs user value
7. **Seasonal constellations?** How to balance FOMO with inclusivity

## SCAMPER Progress Tracker

- ✅ **Substitute** (COMPLETED) - Trigger-based earning system
- ✅ **Combine** (COMPLETED) - 3-stage evolution system
- ✅ **Adapt** (COMPLETED) - Breakthrough-Reflection model
- ✅ **Modify** (COMPLETED) - Hybrid Celestial Levels 3-tier system
- ✅ **Put to Other Uses** (COMPLETED) - Celebration Ritual
- ✅ **Eliminate** (COMPLETED) - Removed Trading, AR, Stage Regression
- ✅ **Reverse** (COMPLETED) - Explored, core design confirmed solid

**🎉 SCAMPER METHOD COMPLETE - ALL 7 PHASES FINISHED**

## Summary of Major Breakthroughs This Session

### Session 1 Breakthroughs (Nov 7):
1. **Trigger-Based Earning** replacing random XP rewards
2. **Three Categories**: Emotion, Courage, Presence (Feel → Act → Be)
3. **3-Stage Evolution**: Stars → Lines → Illustrated Glory
4. **Skyrim-Inspired Progression**: Individual → Category → Celestial Levels

### Session 2 Breakthroughs (Nov 16):
1. **Breakthrough-Reflection Model**: Real-time breakthrough moments + weekly depth-based reflections
2. **Hybrid Depth Analysis**: AI + Self-assessment + Reflection quality
3. **Category-Specific Evolution Aesthetics**: Different visual styles per category
4. **Stage Regression Mechanic**: Growth requires tending
5. **Weighted Category Distribution**: 35 Emotion / 27 Courage / 26 Presence
6. **Hybrid/Intersection Constellations**: Multi-category requirements
7. **Evolving Category Names**: Language sophistication grows with user

### Session 3 Breakthroughs (Nov 22):
1. **Hybrid Celestial Levels System**: Combined all three approaches (Creation + Meta-Abilities + Optional Mentor)
2. **3-Tier Celestial Progression**: 1 category = Creation, 2 categories = Meta-Ability, 3 categories = Mentor option
3. **Celebration Ritual Feature**: Quick visual celebration (2-3 min) as gratitude practice and progress visualization
4. **Strategic Eliminations**: Removed Trading (undermines personal growth), AR (complexity), Stage Regression (punishing)
5. **Design Validation**: Reverse phase confirmed core design is solid - no changes needed
6. **Philosophy Refinement**: Trust users to engage authentically without punishment mechanics
7. **Convergent Synthesis**: Complete system design with 4-phase implementation roadmap

## Convergent Phase - Implementation Roadmap

### Phase 1: MVP (Core Loop) - Quick Wins
*Get the fundamental experience working*

**Features:**
1. Basic constellation unlocking (trigger-based, single stage)
2. Three categories (Emotion, Courage, Presence)
3. Simple digital sky map (view your constellations)
4. Breakthrough moment detection (real-time unlock)

**Assessment:**
- **Effort:** Medium
- **Value:** High
- **Risk:** Low
- **Priority:** This is the heart of the system - if this doesn't feel good, nothing else matters

### Phase 2: Evolution & Depth - Medium Term
*Add progression and richness*

**Features:**
5. 3-stage evolution system (Stars → Lines → Illustrated)
6. Weekly reflection depth analysis
7. Category-specific visual aesthetics
8. Constellation story/mythology unlocks

**Assessment:**
- **Effort:** High
- **Value:** High
- **Risk:** Medium (requires quality artwork)
- **Priority:** Keeps users engaged long-term, adds replayability

### Phase 3: Meta-Progression - Long Term
*Reward mastery and depth*

**Features:**
9. Celestial Levels Tier 1 (custom constellation creation)
10. Celestial Levels Tier 2 (AI meta-abilities)
11. Hybrid/intersection constellations
12. Celebration ritual feature

**Assessment:**
- **Effort:** Very High
- **Value:** Medium-High
- **Risk:** Medium
- **Priority:** High emotional value, strong differentiation

### Phase 4: Community (Optional) - Future
*Only if community becomes important*

**Features:**
13. Celestial Levels Tier 3 (mentor wisdom notes)
14. Moderation system

**Assessment:**
- **Effort:** Very High
- **Value:** Uncertain
- **Risk:** High (community management)
- **Priority:** Defer until user base demands it

### Top 3 Recommended Priorities

**Priority 1: Nail the Core Unlock Experience**
- Trigger-based earning (breakthrough moments)
- Three categories with clear theming
- Simple but beautiful visual feedback

**Priority 2: Build Meaningful Progression**
- 3-stage evolution system
- Weekly reflection depth analysis

**Priority 3: Create Custom Constellation Tool (Celestial Tier 1)**
- Powerful reflection exercise
- Deeply personal
- Strong differentiation from other gamification

## Session Notes

**Session 1 (Nov 7):**
- High energy and engagement throughout
- Strong collaborative ideation flow
- Clear vision alignment around "safe, supportive, present" values
- Evolution concept resonated strongly
- Category system (Emotion/Courage/Presence) feels deeply aligned with product purpose

**Session 2 (Nov 16):**
- Continued SCAMPER method (Adapt phase)
- Breakthrough-Reflection model emerged
- Enhanced evolution system with category-specific aesthetics
- Paused at Celestial Levels decision point

**Session 3 (Nov 22):**
- Resolved Celestial Levels with hybrid 3-tier approach
- Completed all remaining SCAMPER phases
- Celebration Ritual identified as key alternative use
- Strategic eliminations confirmed (Trading, AR, Stage Regression)
- Reverse phase validated core design integrity
- Convergent analysis produced 4-phase implementation roadmap
- Complete system design ready for PRD creation

---

**🎉 SESSION COMPLETE - READY FOR PRD PHASE**

_This brainstorming session successfully produced a complete, cohesive constellation gamification system aligned with the therapeutic chatbot's core values. All major design decisions have been made and documented. Next step: Create Product Requirements Document (PRD)._
