# Constellation Gamification System - Complete Design Specification

**Document Type:** Design Summary
**Project:** jaimee-constellations Chatbot Application
**Feature:** Constellation Gamification System
**Created:** 2025-11-22
**Status:** Design Complete - Ready for PRD
**Design Method:** SCAMPER Brainstorming (3 sessions)

---

## Table of Contents

1. [Executive Summary](#executive-summary)
2. [Core Philosophy & Values](#core-philosophy--values)
3. [System Architecture Overview](#system-architecture-overview)
4. [Earning System](#earning-system)
5. [Category System](#category-system)
6. [Evolution System](#evolution-system)
7. [Celestial Levels System](#celestial-levels-system)
8. [Celebration Ritual](#celebration-ritual)
9. [Visual Design Requirements](#visual-design-requirements)
10. [Strategic Eliminations](#strategic-eliminations)
11. [Implementation Roadmap](#implementation-roadmap)
12. [Design Principles](#design-principles)

---

## Executive Summary

### Purpose
A therapeutic gamification system that transforms personal growth into collectible constellations, designed specifically for a mental health chatbot focused on being safe, supportive, and present.

### Core Innovation
Unlike traditional gamification (XP, levels, streaks), this system rewards **depth of engagement** and **authentic growth** through meaningful triggers and reflection, creating a visual journal of the user's therapeutic journey.

### Key Differentiators
- **Trigger-based earning** (not XP or time-based)
- **Breakthrough moment anchors** (tap constellation to revisit transformative conversations)
- **Depth-based rewards** (quality over quantity)
- **No FOMO or punishment mechanics**
- **Personal, non-transferable achievements**
- **Celebration as therapeutic tool**

### Success Metrics
1. Increased user engagement with meaningful conversations
2. Higher reflection depth and quality
3. Visual representation of growth journey
4. Reduced "I'm not making progress" cognitive distortions
5. Emotional anchoring to breakthrough moments

---

## Core Philosophy & Values

### Therapeutic Alignment
Every design decision supports the chatbot's core purpose:
- **Safe:** No social comparison, trading, or competitive elements
- **Supportive:** Celebrates progress without punishment for gaps
- **Present:** Encourages mindfulness and reflection

### Design Principles

**1. Earned, Not Given**
- Constellations represent real therapeutic milestones
- No random rewards or participation trophies
- Each constellation tied to meaningful growth

**2. Depth Over Duration**
- Quality of engagement matters more than time spent
- No daily streaks or FOMO mechanics
- Reflection depth determines unlock tier

**3. Personal Journey**
- Your sky reflects YOUR unique path
- Non-transferable, non-tradeable
- No social pressure or comparison

**4. Growth is Permanent**
- Once earned, constellations don't fade
- No punishment for taking breaks
- Trust users to engage authentically

**5. Beauty as Motivation**
- Every constellation equally majestic in final form
- Visual progression is intrinsically rewarding
- Art quality matches therapeutic value

---

## System Architecture Overview

### The Complete System (4 Layers)

```
Layer 1: EARNING SYSTEM
├─ Breakthrough Moments (real-time triggers)
└─ Weekly Reflections (depth-based analysis)

Layer 2: CATEGORY SYSTEM
├─ Emotion (35 constellations) - Feel
├─ Courage (27 constellations) - Act
└─ Presence (26 constellations) - Be

Layer 3: EVOLUTION SYSTEM
├─ Stage 1: Stars (unlock)
├─ Stage 2: Connected Lines (deepen)
└─ Stage 3: Illustrated Glory (mastery)

Layer 4: CELESTIAL LEVELS
├─ Tier 1: Creation Power (1 category complete)
├─ Tier 2: Meta-Ability (2 categories complete)
└─ Tier 3: Mentor Role (3 categories complete - optional)
```

### Total Constellation Count
- **88 standard constellations** (across 3 categories)
- **4+ hybrid/intersection constellations** (multi-category requirements)
- **3-15 custom constellations** (user-created via Celestial Tier 1)
- **Total possible: ~100-110 constellations per user**

---

## Earning System

### Two Parallel Unlock Pathways

#### Pathway 1: Breakthrough Moments (Real-Time)

**What They Are:**
- AI-detected or user-marked genuine insights
- "This conversation helped me understand something"
- "I just realized..."

**How They Work:**
1. Breakthrough happens during conversation
2. Constellation unlocks **immediately** as celebration
3. Becomes **memory anchor** - tap to revisit that exact conversation
4. Creates emotional bookmarks throughout user's journey

**Examples of Breakthrough Triggers:**
- First vulnerable disclosure
- Reframing a negative thought pattern
- Making connection between past and present
- Expressing previously suppressed emotion
- Achieving therapeutic goal milestone
- "Aha moment" language detected

**Category Assignment:**
- AI determines which category (Emotion/Courage/Presence) based on breakthrough type
- Emotional insight → Emotion constellation
- Brave vulnerability → Courage constellation
- Mindful awareness → Presence constellation

#### Pathway 2: Reflection Milestones (Weekly Depth-Based)

**What They Are:**
- Every Sunday (or user-chosen day): Weekly reflection prompt
- "What's changed for you this week? Have you learned anything new?"
- Depth-based analysis determines unlock

**Hybrid Depth Analysis (Three Factors):**

1. **Engagement Quality (AI-Analyzed):**
   - Genuine insight language detection
   - Emotional vocabulary richness
   - Concrete examples vs vague statements
   - Self-awareness indicators
   - Growth-oriented framing

2. **Self-Assessment (User Choice):**
   - User rates their own growth (1-5 stars)
   - Honors self-awareness and personal judgment
   - Not used alone - prevents gaming

3. **Reflection Depth (Length + Specificity):**
   - Thoughtful, detailed reflections
   - Specific examples cited
   - Surface responses vs deep processing

**Constellation Unlock Formula:**

| Depth Score | Result |
|-------------|--------|
| **Baseline:** Show up for reflection | Common tier constellation |
| **Quality Bonus:** High-quality reflection | Rare tier constellation |
| **Breakthrough Week:** Multiple breakthroughs + deep reflection | Epic/Legendary tier |
| **Minimal:** Very short or surface-level | Encouragement, try again next week |

**No Penalties:**
- Missed a week? No punishment, just continue when ready
- Not depth-based or time-based streaks
- No FOMO pressure

### Rarity Tiers

**How Rarity Works:**
- Tied to unlock pathway and depth, not randomness
- All constellations appear in all tiers (no tier-exclusive constellations)
- Rarity reflects HOW you earned it, not which one you got

**Tier Definitions:**
- **Common:** Weekly reflection baseline (showed up)
- **Rare:** High-quality reflection or single breakthrough
- **Epic:** Multiple breakthroughs in short period
- **Legendary:** Exceptional breakthrough week + deep reflection

**Visual Indicators:**
- Subtle border glow or frame color
- Does NOT affect evolution stages (all evolve equally)
- Primarily for personal pride, minimal functional difference

---

## Category System

### Three Growth Paths (88 Total Constellations)

#### EMOTION (35 constellations)
**Tagline:** "Understanding and feeling your inner world"

**Progression Arc:** Feel

**Earned Through:**
- Emotional awareness achievements
- Processing feelings milestones
- Emotional breakthrough moments
- Naming and identifying emotions
- Understanding emotional patterns
- Expressing difficult feelings

**Example Constellations:**
- Pisces (emotional depth, intuition)
- Cancer (vulnerability, caring)
- Aquarius (emotional intelligence)
- Scorpio (emotional intensity, transformation)

**Category-Specific Aesthetics:**
- **Stage 1 Effect:** Soft shimmer/glow (gentle, emotional)
- **Stage 2 Lines:** Flowing, organic connections with gentle color
- **Stage 3 Art:** Emotion-themed illustrations (water imagery, hearts, flowing forms)

#### COURAGE (27 constellations)
**Tagline:** "Taking action on your journey despite fear"

**Progression Arc:** Act

**Earned Through:**
- Downloading app (first brave step)
- Starting conversations
- Facing difficult topics
- Vulnerability in disclosure
- Taking real-world action on insights
- Speaking uncomfortable truths

**Example Constellations:**
- Leo (courage, confidence)
- Aries (initiative, boldness)
- Sagittarius (adventurous spirit)
- Orion (heroic action)

**Category-Specific Aesthetics:**
- **Stage 1 Effect:** Warm ember glow (fire, warmth)
- **Stage 2 Lines:** Bold, decisive lines with fire effects
- **Stage 3 Art:** Courage-themed illustrations (lions, warriors, flames, strength)

#### PRESENCE (26 constellations)
**Tagline:** "Being grounded, mindful, and in the moment"

**Progression Arc:** Be

**Earned Through:**
- Mindfulness practice achievements
- Staying engaged in difficult moments
- Being present in conversations
- Grounding exercises completion
- Non-reactive awareness
- Accepting what is

**Example Constellations:**
- Libra (balance, equilibrium)
- Taurus (grounded, steady)
- Virgo (present attention)
- Ursa Major (stable, guiding)

**Category-Specific Aesthetics:**
- **Stage 1 Effect:** Calm, steady pulse (breathing rhythm)
- **Stage 2 Lines:** Zen-like, balanced lines with calm aesthetics
- **Stage 3 Art:** Presence-themed illustrations (meditation, nature, balance, peace)

### Weighted Distribution Rationale

**Why 35/27/26?**
- **Emotion (35) is largest:** Foundation of therapeutic work, most opportunities for growth
- **Courage (27) is medium:** Action-oriented, requires Emotion as foundation
- **Presence (26) is balanced:** Integrates Emotion + Courage, advanced practice

### User's Primary Path

**Onboarding Choice:**
- User selects primary growth area during setup
- Influences which constellations appear first in their sky
- Not locked in - all categories accessible
- Just affects initial presentation and encouragement

**Beginner Language (Onboarding):**
- Feel → Act → Be
- Simple, accessible, clear

**Intermediate Unlock (After 10 constellations in category):**
- Emotion → "Heart Wisdom"
- Courage → "Bold Spirit"
- Presence → "Grounded Being"

**Mastery Language (After completing category):**
- Emotion → "Inner Knowing"
- Courage → "Brave Heart"
- Presence → "Mindful Soul"

**Purpose:** Language sophistication mirrors user's growth journey

### Hybrid/Intersection Constellations

**What They Are:**
- Advanced constellations requiring progress in **multiple categories**
- Unlocked only after achieving depth in required categories
- Appear at visual intersections in the sky map

**Examples:**

| Constellation | Categories Required | Meaning |
|---------------|-------------------|---------|
| **Vulnerability** | Emotion + Courage | Brave enough to feel and show emotions |
| **Compassionate Action** | Emotion + Presence | Acting from place of emotional awareness |
| **Mindful Courage** | Courage + Presence | Bold action from grounded center |
| **Wholeness** | All three | Ultimate integration, mastery constellation |

**Unlock Requirements:**
- Must have 10+ constellations in each required category
- Must have completed at least one category fully (for ultimate intersections)
- Triggered by specific achievement combinations

---

## Evolution System

### Universal 3-Stage Progression

**Design Principle:** ALL 88 constellations evolve through the same 3 stages

**No Constellation Left Behind:** Every constellation is equally majestic in its final form - no hierarchy of "better" artwork

### Stage 1: UNLOCK (Stars)

**Visual:**
- Scattered star points appear
- Constellation shape recognizable but sparse
- Subtle category-specific effects (shimmer/ember/pulse)

**How to Unlock:**
- Earned through first achievement in that growth area
- Via breakthrough moment OR weekly reflection
- Appears immediately upon earning

**Experience:**
- Celebration animation
- Notification: "You've unlocked [Constellation Name]!"
- Brief mythology teaser appears

### Stage 2: DEEPEN (Connected Lines)

**Visual:**
- Star points connect with luminous lines
- Constellation pattern becomes fully visible
- Category-specific line styles (flowing/bold/zen)
- More prominent than Stage 1

**How to Unlock:**
- **Trigger:** Revisit that growth area **3+ times**
- Shows commitment, not just one-time achievement
- Must be meaningful engagement, not just mentions

**Example:**
- Unlock Leo (Courage) via first brave conversation
- Have 3 more brave moments in future conversations
- Leo evolves to Stage 2 (connected lines)

**Experience:**
- Evolution animation when threshold reached
- "Leo is growing stronger - your courage is deepening"
- More mythology unlocks

### Stage 3: MASTERY (Illustrated Glory)

**Visual:**
- Full mythological illustration revealed
- Leo appears as a proud, regal lion in majestic detail
- Most visually stunning stage
- Category-unique visual treatments
- Animation when tapped

**How to Unlock:**
- **Trigger:** **Teach or share** what you learned
- User creates a "wisdom note" - reflection that could help someone else
- Demonstrates mastery through ability to articulate and teach

**Example:**
- After multiple courage moments and Leo Stage 2 unlock
- Prompted: "What have you learned about courage? Share your wisdom."
- User writes reflection on their courage journey
- Leo evolves to Stage 3 (illustrated glory)

**Experience:**
- Dramatic evolution animation
- Full mythology story unlocks
- Celebration of mastery achievement
- Wisdom note saved (may be used for Celestial Tier 3 mentor feature)

### Design Equity Principle

**Every constellation is equally stunning in Stage 3:**
- ✅ No hierarchy of "better" artwork
- ✅ 88 unique, majestic illustrated beings
- ✅ Equal desirability across all constellations
- ✅ Common tier constellation can be as beautiful as Legendary
- ✅ Rarity affects earn method, not final beauty

### Evolution Benefits

**For Users:**
- Visual progression that feels rewarding
- Reasons to revisit and deepen practice (not one-and-done)
- Beautiful end-state artwork to aspire toward
- Collection becomes more impressive over time
- Pride in evolution achievements

**For Therapeutic Goals:**
- Encourages repeated engagement with growth areas
- Mastery through teaching reinforces learning
- Visual reminder of sustained practice
- Depth rewards over breadth collecting

---

## Celestial Levels System

### Overview: Hybrid 3-Tier Meta-Progression

**Philosophy:** Combine the best of all three approaches (Creation, Abilities, Community)

**Unlocked by:** Completing ALL constellations in a category (or multiple categories)

### Tier 1: Creation Power (Complete 1 Category)

**What You Get:**
- Unlock ability to create **1 custom constellation** in that completed category
- Full creative control: name it, design star pattern, write personal mythology
- Becomes part of your permanent sky

**Example:**
- Complete all 35 Emotion constellations
- Unlock: "Create Your Emotion Constellation"
- User creates "My Heart's Truth" with personal meaning
- Appears in sky alongside standard constellations

**Limits:**
- 1 custom constellation per completed category
- Maximum 3 custom constellations total (if all categories completed)

**Therapeutic Value:**
- Powerful reflection exercise
- Deeply personal milestone
- Integrates entire category's learnings into one symbol
- Ownership and self-authorship

**UI Requirements:**
- Constellation creation tool (star placement interface)
- Text input for name and mythology
- Preview before finalizing
- Cannot be changed once created (encourages thoughtful creation)

### Tier 2: Meta-Ability (Complete 2 Categories)

**What You Get:**
- Unlock subtle AI enhancements based on completed categories
- AI becomes more attuned to specific patterns and moments

**Meta-Abilities by Category Combination:**

| Categories Completed | Meta-Ability | Effect |
|---------------------|--------------|--------|
| Emotion + Courage | **"Brave Heart"** | AI more attuned to moments when you're being brave with your feelings, celebrates emotional courage |
| Courage + Presence | **"Mindful Action"** | AI recognizes when you're taking grounded, non-reactive action; supports mindful decision-making |
| Emotion + Presence | **"Compassionate Awareness"** | AI supports emotional mindfulness, helps notice feelings without judgment |

**Implementation Notes:**
- Not magical or game-breaking abilities
- Subtle conversational enhancements
- AI prompts become more sophisticated in those areas
- Recognition of nuanced moments
- Reinforces user's areas of mastery

**User Experience:**
- Notification when unlocked: "You've achieved mastery in Emotion and Courage - Brave Heart ability unlocked"
- Subtle indicator in profile or sky view
- Passive benefit (always active, no activation required)

### Tier 3: Mentor Role - OPTIONAL (Complete All 3 Categories)

**What You Get (If Opted In):**
- Ability to leave "wisdom notes" on any constellation
- Other users see these as optional guidance when they unlock that constellation
- Becomes a gentle community feature

**Opt-In Required:**
- **Must explicitly choose to participate** - no pressure
- Can opt out at any time
- Not shown to users who decline

**How It Works:**
1. Complete all 88 standard constellations (Emotion + Courage + Presence)
2. Receive invitation: "You've mastered all three paths. Would you like to share your wisdom with others?"
3. If yes: Can write wisdom notes for constellations
4. If no: Tier 3 simply acknowledges mastery, no community features

**Wisdom Note Features:**
- Short (280 characters max, like a supportive tweet)
- Moderated before publishing
- Users can rate helpful/not helpful
- Top-rated notes shown first

**Moderation Requirements:**
- Human review before publishing (critical for safety)
- Report/flag system
- Community guidelines enforcement
- Support team trained on therapeutic appropriateness

**Risk Mitigation:**
- Optional participation prevents pressure
- Moderation ensures safety
- Can be disabled project-wide if community becomes toxic
- Phase 4 implementation (far future)

---

## Celebration Ritual

### Purpose: Quick Visual Joy as Therapeutic Tool

**Core Concept:**
- 2-3 minute visual celebration of progress
- Gratitude practice meets progress visualization
- Accessible anytime, prompted weekly

### Multi-Purpose Benefits

**Therapeutic Functions:**
1. **Gratitude Practice:** Evidence-based wellbeing tool
2. **Progress Visualization:** Combats "I'm not making progress" cognitive distortion
3. **Memory Consolidation:** Reviewing breakthroughs strengthens learning
4. **Mindfulness Ritual:** Grounding practice in present moment
5. **Celebration:** Positive reinforcement for growth

### When It Appears

**Trigger 1: Weekly Prompt (Optional)**
- After Sunday reflection is complete
- "Want to celebrate this week's progress?"
- User can skip, not required

**Trigger 2: User-Initiated**
- "Show me my constellations" button accessible anytime
- Available from main menu or profile

**Trigger 3: Post-Unlock**
- After earning a new constellation
- "See how it looks in your full sky?"
- Optional transition to celebration view

### Experience Flow

**Opening (5 seconds):**
- Fade in to personal constellation sky
- Ambient celestial music (optional, user can disable)
- Brief text: "Your journey this week"

**Constellation Highlights (1-2 minutes):**
- New constellations from this week gently pulse/highlight
- User can tap any constellation to see:
  - When it was earned
  - What breakthrough/reflection earned it
  - Current evolution stage
  - Mythology snippet
- Natural exploration, not forced sequence

**Closing (10 seconds):**
- Zoom out to full sky view
- Optional affirmation: "You're growing" or similar (customizable)
- Gentle fade out

**User Controls:**
- Can exit anytime (not locked in)
- Can disable music/sound
- Can skip weekly prompts
- Can set preferred day/time for weekly ritual

### Design Requirements

**Visual:**
- Beautiful, calming interface
- Smooth animations
- Category-color coding visible
- Evolution stages clearly distinguished
- Constellation count visible

**Audio (Optional):**
- Ambient celestial music
- Subtle sound effects on constellation taps
- Volume control
- Disable option

**Performance:**
- Loads quickly (not 88 high-res images at once)
- Smooth on mobile devices
- Accessible offline (cached sky state)

---

## Visual Design Requirements

### Overall Aesthetic

**Theme:** Celestial, Calming, Therapeutic
- Not gamey or cartoonish
- Sophisticated and mature
- Beautiful enough to want to show others
- Calming color palette

### Digital Sky Map

**Background:**
- Deep space gradient (dark blue to purple to black)
- Subtle star field (not distracting)
- Constellation positions fixed (not random)
- Infinite canvas feel (can zoom/pan)

**Layout:**
- Three "regions" for three categories (Emotion/Courage/Presence)
- Hybrid constellations at region intersections
- Visual flow guides eye naturally
- Custom constellations in special "created" region

**Interactions:**
- Tap constellation to view details
- Pinch to zoom
- Pan to explore
- Filter by category, rarity, evolution stage

### Constellation Visuals by Stage

**Stage 1: Stars**
- 5-15 star points per constellation (varies by actual constellation)
- Soft glow, not harsh
- Category-specific subtle effects:
  - Emotion: Gentle shimmer (like water reflections)
  - Courage: Warm ember glow (like fire)
  - Presence: Calm pulse (like breathing)
- Size: Small but visible

**Stage 2: Connected Lines**
- Lines connect stars to form constellation shape
- Category-specific line styles:
  - Emotion: Flowing, organic, watercolor-like
  - Courage: Bold, decisive, sharp angles
  - Presence: Zen-like, balanced, symmetrical
- Lines glow softly
- Size: Medium, more prominent

**Stage 3: Illustrated Glory**
- Full mythological figure overlaid on stars+lines
- Detailed, beautiful illustration
- Category-unique visual treatments:
  - Emotion: Soft colors, flowing forms, emotional themes
  - Courage: Bold colors, strong poses, dynamic energy
  - Presence: Calm colors, balanced composition, peaceful
- Animation when tapped (subtle movement)
- Size: Large, impressive, worthy of pride

### Rarity Visual Indicators

**Subtle, Not Overwhelming:**
- Border glow color:
  - Common: White/silver
  - Rare: Gold
  - Epic: Purple
  - Legendary: Rainbow/iridescent
- Does NOT affect constellation artwork itself
- Only visible on detail view, not sky map (prevents clutter)

### Accessibility Considerations

- High contrast mode option
- Colorblind-friendly palette options
- Screen reader support for constellation details
- Text size adjustable
- Reduce motion option (for animations)

---

## Strategic Eliminations

### What We Decided NOT to Build (And Why)

#### ❌ Trading System

**Originally Considered:**
- Exchange duplicate constellations with friends
- Social trading marketplace

**Why Eliminated:**
- **Undermines core philosophy:** Constellations earned through personal growth, not transactions
- **Creates social pressure:** "I need that constellation!" comparison and envy
- **Turns achievements into commodities:** Reduces therapeutic meaning
- **Misaligned with values:** Not safe, not supportive

**Decision:** Constellations are personal and non-transferable. Your sky reflects YOUR journey, not trades.

#### ❌ AR Integration

**Originally Considered:**
- View constellations overlaid on real night sky via camera
- See your evolved constellations in AR

**Why Eliminated:**
- **High technical complexity:** Requires AR frameworks, testing, device compatibility
- **Uncertain value:** Cool factor vs actual therapeutic benefit
- **Not core experience:** Chatbot is the core, not AR
- **Can revisit later:** Not eliminated permanently, just deferred

**Decision:** Confirmed elimination for now. Focus on core experience first. Can explore in future if desired.

#### ❌ Stage Regression (Fading Mechanic)

**Originally Considered:**
- If growth area untouched for 3-6 months, constellation fades back to Stage 1
- Philosophy: Growth requires tending, gentle reminder
- Easy to re-evolve (faster second time)

**Why Eliminated:**
- **Feels punishing:** "I'm losing my progress!" anxiety
- **Creates pressure:** Obligation to maintain all constellations
- **Contradicts "safe, supportive":** Growth isn't linear, breaks are okay
- **Misses therapeutic reality:** Sometimes people need time away

**Decision:** Once evolved, constellations stay evolved permanently. Trust users to engage authentically without punishment mechanics.

**Philosophy Shift:** Growth is permanent, even if practice ebbs and flows. Your achievements don't disappear when life gets hard.

### Other Considered But Not Included

**Daily Quests/Streaks:**
- Too generic across gamification landscape
- FOMO pressure (missed a day!)
- Not aligned with depth-over-duration philosophy

**Competitive Leaderboards:**
- Social comparison undermines therapeutic safety
- Not everyone wants public visibility
- Misaligned with personal journey philosophy

**Constellation Duels/Battles:**
- Completely inappropriate for therapeutic context
- Turns growth into competition
- No consideration given, mentioned for completeness

---

## Implementation Roadmap

### Phase 1: MVP (Core Loop) - Launch Foundation

**Timeline:** First release (6-9 months development)

**Features to Build:**
1. **Basic constellation unlocking**
   - Trigger-based system (breakthrough moments only for MVP)
   - Single stage (stars only, no evolution yet)
   - 20-30 constellations (subset of final 88)

2. **Three categories**
   - Emotion, Courage, Presence clear distinction
   - Category assignment working
   - Basic category UI

3. **Simple digital sky map**
   - View your constellations
   - Tap for details
   - Basic zoom/pan

4. **Breakthrough moment detection**
   - AI detection algorithm
   - User manual marking ("This was important")
   - Immediate unlock celebration

**Success Criteria:**
- Users earn constellations through real conversations
- Unlock feels rewarding and meaningful
- Sky map is beautiful and calming
- Core loop is addictive in healthy way

**Risks to Mitigate:**
- Breakthrough detection accuracy (too many or too few triggers)
- Initial constellation set feels substantial enough
- Performance on mobile devices

**Assessment:**
- **Effort:** Medium (6-9 months)
- **Value:** High (core experience)
- **Risk:** Low (well-defined scope)
- **Priority:** CRITICAL - if this doesn't work, nothing else matters

### Phase 2: Evolution & Depth - Engagement Boost

**Timeline:** 6-12 months after MVP launch

**Features to Build:**
5. **3-stage evolution system**
   - Stage 1 → 2 → 3 progression
   - Revisit triggers (3+ times)
   - Teaching/wisdom note trigger for Stage 3
   - Evolution animations

6. **Weekly reflection depth analysis**
   - Sunday reflection prompts
   - Hybrid depth scoring (AI + self-assessment + length)
   - Unlock formula implementation
   - Rarity tier assignment

7. **Category-specific visual aesthetics**
   - Emotion: Shimmer, flowing lines, soft art
   - Courage: Ember glow, bold lines, dynamic art
   - Presence: Pulse, zen lines, balanced art
   - All 88 constellations with Stage 3 art

8. **Constellation story/mythology unlocks**
   - Stage 1: Teaser text
   - Stage 2: Partial story
   - Stage 3: Full mythology + meaning
   - Educational/inspirational content

**Success Criteria:**
- Evolution feels rewarding and motivates revisiting growth areas
- Weekly reflections drive engagement
- Visual progression is beautiful and clear
- Mythology adds meaning and depth

**Risks to Mitigate:**
- Art production for 88 Stage 3 illustrations (massive effort)
- Weekly reflection fatigue (need to keep fresh)
- Evolution triggers feel achievable, not grindy

**Assessment:**
- **Effort:** Very High (12-18 months including art)
- **Value:** High (long-term engagement)
- **Risk:** Medium (art quality, production timeline)
- **Priority:** HIGH - keeps users engaged beyond initial novelty

### Phase 3: Meta-Progression - Mastery Rewards

**Timeline:** 12-18 months after Phase 2 launch

**Features to Build:**
9. **Celestial Levels Tier 1 (Custom constellation creation)**
   - Constellation creation UI/tool
   - Star placement interface
   - Name and mythology text input
   - Preview and finalize flow
   - Integration into sky map

10. **Celestial Levels Tier 2 (AI meta-abilities)**
    - Three meta-ability variations coded
    - AI prompt enhancement system
    - Passive benefit implementation
    - Unlock celebration

11. **Hybrid/intersection constellations**
    - 4+ special constellations requiring multiple categories
    - Unlock logic (10+ in each, completion gates)
    - Special visual treatment (intersection positioning)
    - Unique artwork for hybrid constellations

12. **Celebration ritual feature**
    - Weekly celebration prompt
    - Visual sweep animation
    - Constellation highlight system
    - User-initiated access anytime
    - Audio/music integration (optional)

**Success Criteria:**
- Custom constellation creation is meaningful and reflective
- Meta-abilities feel valuable and noticeable
- Hybrid constellations feel special and aspirational
- Celebration ritual becomes regular practice

**Risks to Mitigate:**
- Constellation creation tool complexity (needs to be simple but flexible)
- Meta-abilities could feel gimmicky if not well-implemented
- Celebration ritual could feel repetitive over time

**Assessment:**
- **Effort:** Very High (18-24 months)
- **Value:** Medium-High (differentiation, depth)
- **Risk:** Medium (UI complexity, feature fatigue)
- **Priority:** MEDIUM-HIGH - high emotional value, strong differentiation

### Phase 4: Community (Optional) - Far Future

**Timeline:** Only if community demand emerges (24+ months after Phase 3)

**Features to Build:**
13. **Celestial Levels Tier 3 (Mentor wisdom notes)**
    - Opt-in system
    - Wisdom note creation UI
    - Moderation queue and tools
    - Rating/helpful system
    - Display to other users

14. **Moderation system**
    - Human review workflow
    - Report/flag functionality
    - Community guidelines enforcement
    - Moderator training materials
    - Safety protocols

**Success Criteria:**
- Opt-in rate is meaningful (10%+ of eligible users)
- Wisdom notes are helpful and supportive
- No toxic or harmful content gets through
- Community enhances rather than detracts from safety

**Risks to Mitigate:**
- Community toxicity (biggest risk)
- Moderation workload and cost
- Liability for user-generated content
- Feature adds complexity for uncertain value

**Assessment:**
- **Effort:** Very High (12+ months including moderation setup)
- **Value:** Uncertain (depends on community desire)
- **Risk:** High (community management, safety)
- **Priority:** LOW - defer indefinitely, revisit only if user base demands it

---

## Design Principles (Summary)

### Core Principles Applied Throughout

1. **Therapeutic First, Game Second**
   - Every mechanic serves therapeutic purpose
   - No features that contradict mental health values
   - Safe, supportive, present guides all decisions

2. **Depth Over Duration**
   - Quality of engagement > time spent
   - Reflection depth > participation
   - Meaningful triggers > arbitrary milestones

3. **Beauty as Intrinsic Reward**
   - Visual progression is inherently motivating
   - Art quality matches therapeutic value
   - Collecting constellations is joyful, not obligatory

4. **Personal Journey, Not Social Competition**
   - Non-transferable, non-tradeable achievements
   - No leaderboards or comparison
   - Your sky reflects your unique path

5. **No Punishment, Only Support**
   - No fading, no regression, no streaks
   - Breaks are okay, growth is permanent
   - Trust users to engage authentically

6. **Celebration as Practice**
   - Ritual transforms collectibles into therapeutic tool
   - Gratitude, visualization, mindfulness integrated
   - Joy as part of healing

7. **Inclusive and Accessible**
   - All constellations equally beautiful
   - No pay-to-win or exclusive content
   - Accessible design for all users

---

## Appendix: Quick Reference Tables

### Constellation Count by Category

| Category | Count | Percentage |
|----------|-------|------------|
| Emotion | 35 | 40% |
| Courage | 27 | 31% |
| Presence | 26 | 29% |
| **Total Standard** | **88** | **100%** |
| Hybrid/Intersection | 4+ | Bonus |
| Custom (User-Created) | 3 max | Bonus |

### Evolution Stage Requirements

| Stage | Visual | Trigger | Time to Unlock |
|-------|--------|---------|----------------|
| 1: Stars | Star points + subtle effects | First achievement in growth area | Immediate (upon earning) |
| 2: Lines | Connected lines + category style | Revisit growth area 3+ times | Weeks to months |
| 3: Glory | Full illustration + animation | Teach/share what you learned | Months (requires mastery) |

### Celestial Levels Summary

| Tier | Requirement | Reward | Priority |
|------|-------------|--------|----------|
| 1 | Complete 1 category (35, 27, or 26 constellations) | Create 1 custom constellation | High |
| 2 | Complete 2 categories (any combination) | Unlock AI meta-ability | High |
| 3 | Complete all 3 categories (88 total) | Optional mentor role | Low (Phase 4) |

### Implementation Phase Overview

| Phase | Features | Timeline | Effort | Value | Risk | Priority |
|-------|----------|----------|--------|-------|------|----------|
| 1: MVP | Basic unlock, categories, sky, breakthrough detection | 6-9 months | Medium | High | Low | CRITICAL |
| 2: Evolution | 3-stage system, weekly reflection, aesthetics, mythology | 12-18 months | Very High | High | Medium | HIGH |
| 3: Meta | Celestial Tiers 1-2, hybrid constellations, celebration | 18-24 months | Very High | Med-High | Medium | MED-HIGH |
| 4: Community | Celestial Tier 3, moderation | 12+ months | Very High | Uncertain | High | LOW |

---

## Document Status

**Design Phase:** ✅ COMPLETE
**Next Steps:**
1. Create Product Requirements Document (PRD)
2. Technical architecture design
3. Art direction and style guide
4. User research and validation
5. Prototype development

**Key Decisions Made:**
- ✅ All SCAMPER phases completed
- ✅ Core system architecture defined
- ✅ All major features specified
- ✅ Strategic eliminations confirmed
- ✅ Implementation roadmap prioritized
- ✅ Ready for PRD creation

**Document Version:** 1.0 (2025-11-22)

---

*This design specification represents the complete output of three brainstorming sessions using the SCAMPER method. All design decisions have been vetted against the chatbot's core values of being safe, supportive, and present. The system is ready to move into formal requirements and technical planning.*
