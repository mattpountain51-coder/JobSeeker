# Ultra API AWS - Database Schema

**Generated:** 2025-11-07  
**Database:** PostgreSQL  
**ORM:** SQLAlchemy (Async)  
**Migrations:** Alembic

## Overview

The ultra-api-aws backend uses PostgreSQL with 12 core tables for managing user profiles, AI characters, chat sessions, and analytics.

**Key Patterns:**
- **UUID Primary Keys** - All tables use UUIDs
- **User Isolation** - All tables include `user_id`
- **Soft Deletes** - `deleted_at` timestamp
- **Audit Trails** - `created_at` and `updated_at`
- **JSONB Metadata** - Flexible schema extension

**Total Tables:** 12  
**Total Migrations:** 13+

---

## Entity Relationships

```
UserProfile (user_profile)
    ├──> CharacterProfile (character_profile) [1:N]
    ├──> Session (sessions) [1:N]
    ├──> Channel (channels) [1:N]
    ├──> Nudge (nudges) [1:N]
    └──> UserMetrics (user_metrics) [1:N]

Session (sessions)
    ├──> SessionParticipant (session_participant) [1:N]
    ├──> UserSession (user_sessions) [1:N]
    └──> Chat (chats) [1:N]

Chat (chats)
    ├──> Reaction (reactions) [1:N]
    └──> Feedback (feedback) [1:N]

Channel (channels)
    └──> Chat (chats) [1:N]
```

---

## Tables

### 1. user_profile

**Purpose:** User account information and preferences

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | UUID | PK | Primary key |
| user_id | String | NOT NULL, INDEX | Cognito user ID |
| email | String | UNIQUE | User email |
| display_name | String | NULL | Display name |
| avatar_url | String | NULL | Profile picture |
| bio | Text | NULL | User bio |
| preferences | JSONB | DEFAULT '{}' | User preferences |
| metadata | JSONB | DEFAULT '{}' | Additional data |
| is_active | Boolean | DEFAULT TRUE | Active status |
| last_login_at | DateTime(TZ) | NULL | Last login |
| created_at | DateTime(TZ) | DEFAULT NOW() | Creation time |
| updated_at | DateTime(TZ) | DEFAULT NOW() | Last update |
| deleted_at | DateTime(TZ) | NULL | Soft delete |

**Indexes:**
- PRIMARY KEY on `id`
- UNIQUE on `email`
- INDEX on `user_id`

**Relationships:**
- Has many `character_profile`
- Has many `sessions`
- Has many `user_metrics`

---

### 2. character_profile

**Purpose:** AI character definitions

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | UUID | PK | Primary key |
| user_id | String | NOT NULL, INDEX | Owner user ID |
| name | String | NOT NULL | Character name |
| description | Text | NULL | Description |
| personality | Text | NULL | Personality traits |
| avatar_url | String | NULL | Character avatar |
| system_prompt | Text | NULL | AI system prompt |
| model_config | JSONB | DEFAULT '{}' | LLM config |
| voice_settings | JSONB | DEFAULT '{}' | TTS config |
| is_public | Boolean | DEFAULT FALSE | Public visibility |
| is_active | Boolean | DEFAULT TRUE | Active status |
| metadata | JSONB | DEFAULT '{}' | Additional data |
| created_at | DateTime(TZ) | DEFAULT NOW() | Creation time |
| updated_at | DateTime(TZ) | DEFAULT NOW() | Last update |
| deleted_at | DateTime(TZ) | NULL | Soft delete |

**Indexes:**
- PRIMARY KEY on `id`
- INDEX on `user_id`
- INDEX on `is_public`

**Relationships:**
- Belongs to `user_profile`
- Has many `sessions`

---

### 3. sessions

**Purpose:** Chat session management

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | UUID | PK | Primary key |
| user_id | String | NOT NULL, INDEX | Owner user ID |
| character_id | UUID | FK | Associated character |
| title | String | NULL | Session title |
| status | Enum | DEFAULT 'active' | Status |
| context | JSONB | DEFAULT '{}' | Conversation context |
| state | JSONB | DEFAULT '{}' | Session state |
| last_message_at | DateTime(TZ) | NULL | Last message time |
| started_at | DateTime(TZ) | DEFAULT NOW() | Start time |
| ended_at | DateTime(TZ) | NULL | End time |
| metadata | JSONB | DEFAULT '{}' | Additional data |
| created_at | DateTime(TZ) | DEFAULT NOW() | Creation time |
| updated_at | DateTime(TZ) | DEFAULT NOW() | Last update |
| deleted_at | DateTime(TZ) | NULL | Soft delete |

**Enums:**
- `status`: 'active', 'paused', 'ended'

**Indexes:**
- PRIMARY KEY on `id`
- INDEX on `user_id`
- INDEX on `character_id`
- INDEX on `status`

**Foreign Keys:**
- `character_id` → `character_profile.id` (CASCADE)

**Relationships:**
- Belongs to `user_profile`
- Belongs to `character_profile`
- Has many `chats`
- Has many `session_participant`

---

### 4. user_sessions

**Purpose:** User participation in sessions

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | UUID | PK | Primary key |
| user_id | String | NOT NULL, INDEX | Participant user ID |
| session_id | UUID | FK | Associated session |
| role | String | DEFAULT 'participant' | User role |
| joined_at | DateTime(TZ) | DEFAULT NOW() | Join time |
| left_at | DateTime(TZ) | NULL | Leave time |
| is_active | Boolean | DEFAULT TRUE | Active status |
| metadata | JSONB | DEFAULT '{}' | Additional data |
| created_at | DateTime(TZ) | DEFAULT NOW() | Creation time |
| updated_at | DateTime(TZ) | DEFAULT NOW() | Last update |
| deleted_at | DateTime(TZ) | NULL | Soft delete |

**Indexes:**
- PRIMARY KEY on `id`
- INDEX on `user_id`
- INDEX on `session_id`
- UNIQUE on `(user_id, session_id)`

**Foreign Keys:**
- `session_id` → `sessions.id` (CASCADE)

---

### 5. session_participant

**Purpose:** AI character participation

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | UUID | PK | Primary key |
| user_id | String | NOT NULL, INDEX | Owner user ID |
| session_id | UUID | FK | Associated session |
| character_id | UUID | FK | Participating character |
| role | String | DEFAULT 'assistant' | Role |
| joined_at | DateTime(TZ) | DEFAULT NOW() | Join time |
| left_at | DateTime(TZ) | NULL | Leave time |
| is_active | Boolean | DEFAULT TRUE | Active status |
| metadata | JSONB | DEFAULT '{}' | Additional data |
| created_at | DateTime(TZ) | DEFAULT NOW() | Creation time |
| updated_at | DateTime(TZ) | DEFAULT NOW() | Last update |
| deleted_at | DateTime(TZ) | NULL | Soft delete |

**Indexes:**
- PRIMARY KEY on `id`
- INDEX on `session_id`
- INDEX on `character_id`
- UNIQUE on `(session_id, character_id)`

**Foreign Keys:**
- `session_id` → `sessions.id` (CASCADE)
- `character_id` → `character_profile.id` (CASCADE)

---

### 6. channels

**Purpose:** Communication channels

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | UUID | PK | Primary key |
| user_id | String | NOT NULL, INDEX | Owner user ID |
| name | String | NOT NULL | Channel name |
| type | String | NOT NULL | Channel type |
| description | Text | NULL | Description |
| settings | JSONB | DEFAULT '{}' | Channel settings |
| is_active | Boolean | DEFAULT TRUE | Active status |
| metadata | JSONB | DEFAULT '{}' | Additional data |
| created_at | DateTime(TZ) | DEFAULT NOW() | Creation time |
| updated_at | DateTime(TZ) | DEFAULT NOW() | Last update |
| deleted_at | DateTime(TZ) | NULL | Soft delete |

**Indexes:**
- PRIMARY KEY on `id`
- INDEX on `user_id`
- INDEX on `type`

**Relationships:**
- Has many `chats`

---

### 7. chats

**Purpose:** Chat messages

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | UUID | PK | Primary key |
| user_id | String | NOT NULL, INDEX | Owner user ID |
| session_id | UUID | FK, NULL | Associated session |
| channel_id | UUID | FK, NULL | Associated channel |
| sender_id | String | NOT NULL | Sender ID |
| sender_type | Enum | NOT NULL | Sender type |
| content | Text | NOT NULL | Message content |
| content_type | String | DEFAULT 'text' | Content type |
| metadata | JSONB | DEFAULT '{}' | Message metadata |
| is_edited | Boolean | DEFAULT FALSE | Edit status |
| edited_at | DateTime(TZ) | NULL | Edit time |
| created_at | DateTime(TZ) | DEFAULT NOW() | Creation time |
| updated_at | DateTime(TZ) | DEFAULT NOW() | Last update |
| deleted_at | DateTime(TZ) | NULL | Soft delete |

**Enums:**
- `sender_type`: 'user', 'assistant', 'system'

**Indexes:**
- PRIMARY KEY on `id`
- INDEX on `user_id`
- INDEX on `session_id`
- INDEX on `channel_id`
- INDEX on `created_at`

**Foreign Keys:**
- `session_id` → `sessions.id` (SET NULL)
- `channel_id` → `channels.id` (SET NULL)

**Relationships:**
- Belongs to `session` (optional)
- Belongs to `channel` (optional)
- Has many `reactions`
- Has many `feedback`

---

### 8. reactions

**Purpose:** Message reactions

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | UUID | PK | Primary key |
| user_id | String | NOT NULL, INDEX | Reacting user |
| chat_id | UUID | FK | Associated message |
| reaction_type | String | NOT NULL | Reaction type |
| metadata | JSONB | DEFAULT '{}' | Additional data |
| created_at | DateTime(TZ) | DEFAULT NOW() | Creation time |
| updated_at | DateTime(TZ) | DEFAULT NOW() | Last update |
| deleted_at | DateTime(TZ) | NULL | Soft delete |

**Indexes:**
- PRIMARY KEY on `id`
- INDEX on `chat_id`
- UNIQUE on `(user_id, chat_id, reaction_type)`

**Foreign Keys:**
- `chat_id` → `chats.id` (CASCADE)

---

### 9. feedback

**Purpose:** User feedback on AI responses

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | UUID | PK | Primary key |
| user_id | String | NOT NULL, INDEX | Feedback provider |
| chat_id | UUID | FK, NULL | Associated message |
| session_id | UUID | FK, NULL | Associated session |
| rating | Integer | NULL | Numeric rating |
| feedback_type | Enum | NOT NULL | Feedback type |
| comment | Text | NULL | Feedback text |
| metadata | JSONB | DEFAULT '{}' | Additional data |
| created_at | DateTime(TZ) | DEFAULT NOW() | Creation time |
| updated_at | DateTime(TZ) | DEFAULT NOW() | Last update |
| deleted_at | DateTime(TZ) | NULL | Soft delete |

**Enums:**
- `feedback_type`: 'positive', 'negative', 'bug', 'feature_request', 'general'

**Indexes:**
- PRIMARY KEY on `id`
- INDEX on `chat_id`
- INDEX on `feedback_type`

**Foreign Keys:**
- `chat_id` → `chats.id` (SET NULL)
- `session_id` → `sessions.id` (SET NULL)

---

### 10. nudges

**Purpose:** System notifications

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | UUID | PK | Primary key |
| user_id | String | NOT NULL, INDEX | Target user |
| nudge_type | Enum | NOT NULL | Nudge type |
| title | String | NOT NULL | Nudge title |
| message | Text | NOT NULL | Nudge message |
| action_url | String | NULL | Call-to-action URL |
| priority | Integer | DEFAULT 0 | Priority level |
| is_read | Boolean | DEFAULT FALSE | Read status |
| read_at | DateTime(TZ) | NULL | Read time |
| expires_at | DateTime(TZ) | NULL | Expiration time |
| metadata | JSONB | DEFAULT '{}' | Additional data |
| created_at | DateTime(TZ) | DEFAULT NOW() | Creation time |
| updated_at | DateTime(TZ) | DEFAULT NOW() | Last update |
| deleted_at | DateTime(TZ) | NULL | Soft delete |

**Enums:**
- `nudge_type`: 'reminder', 'suggestion', 'alert', 'tip', 'update'

**Indexes:**
- PRIMARY KEY on `id`
- INDEX on `user_id`
- INDEX on `is_read`
- INDEX on `(user_id, is_read)`

---

### 11. user_metrics

**Purpose:** User activity metrics

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | UUID | PK | Primary key |
| user_id | String | NOT NULL, INDEX | User being tracked |
| metric_type | String | NOT NULL | Metric category |
| metric_name | String | NOT NULL | Metric name |
| metric_value | Float | NOT NULL | Metric value |
| period | String | NULL | Time period |
| recorded_at | DateTime(TZ) | DEFAULT NOW() | Record time |
| metadata | JSONB | DEFAULT '{}' | Additional data |
| created_at | DateTime(TZ) | DEFAULT NOW() | Creation time |
| updated_at | DateTime(TZ) | DEFAULT NOW() | Last update |
| deleted_at | DateTime(TZ) | NULL | Soft delete |

**Indexes:**
- PRIMARY KEY on `id`
- INDEX on `user_id`
- INDEX on `metric_type`
- INDEX on `(user_id, metric_type, recorded_at)`

---

### 12. ref_data

**Purpose:** Reference/lookup data

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | UUID | PK | Primary key |
| user_id | String | NOT NULL, INDEX | Owner user |
| category | String | NOT NULL | Data category |
| key | String | NOT NULL | Data key |
| value | Text | NOT NULL | Data value |
| data | JSONB | DEFAULT '{}' | Structured data |
| is_active | Boolean | DEFAULT TRUE | Active status |
| metadata | JSONB | DEFAULT '{}' | Additional data |
| created_at | DateTime(TZ) | DEFAULT NOW() | Creation time |
| updated_at | DateTime(TZ) | DEFAULT NOW() | Last update |
| deleted_at | DateTime(TZ) | NULL | Soft delete |

**Indexes:**
- PRIMARY KEY on `id`
- INDEX on `category`
- UNIQUE on `(user_id, category, key)`

---

## Migration History

**Total Migrations:** 13+

**Key Migrations:**
1. Initial schema setup
2. Added nudges table
3. Added feedback table
4. Added reactions table
5. Added user_metrics table
6. Added channels table
7. Added chats table
8. Added session_participant table
9. Added user_sessions table
10. Added sessions table
11. Added character_profile table
12. Added user_profile table
13. Added ref_data table

**Migration Commands:**
```bash
# Create new migration
alembic revision --autogenerate -m "description"

# Apply migrations
alembic upgrade head

# Rollback
alembic downgrade -1

# Check current version
alembic current
```

---

## Common Query Patterns

### Active Records (Soft Delete)
```sql
SELECT * FROM table_name 
WHERE user_id = :user_id 
  AND deleted_at IS NULL;
```

### User's Active Sessions
```sql
SELECT s.* FROM sessions s
WHERE s.user_id = :user_id
  AND s.deleted_at IS NULL
  AND s.status = 'active'
ORDER BY s.last_message_at DESC;
```

### Session Chat History
```sql
SELECT c.* FROM chats c
WHERE c.session_id = :session_id
  AND c.deleted_at IS NULL
ORDER BY c.created_at ASC;
```

### Unread Nudges
```sql
SELECT * FROM nudges
WHERE user_id = :user_id
  AND is_read = FALSE
  AND deleted_at IS NULL
ORDER BY priority DESC, created_at DESC;
```

---

## Database Configuration

**Connection String:**
```
postgresql+asyncpg://user:pass@host:port/database
```

**Pool Settings:**
- Pool size: 5 (configurable)
- Max overflow: 20
- Pool recycle: 300 seconds
- Pool timeout: 60 seconds

**Extensions:**
- uuid-ossp (for UUID generation)

---

## File Locations

**Models:** `/app/app/db/`
- `user_profile.py`
- `character_profile.py`
- `sessions.py`
- `user_sessions.py`
- `session_participant.py`
- `channels.py`
- `chat.py`
- `reaction.py`
- `feedback.py`
- `nudge.py`
- `user_metrics.py`
- `ref_data.py`

**Migrations:** `/app/alembic/versions/`

**Base Config:** `/app/app/db/base.py`
