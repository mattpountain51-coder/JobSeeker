# Ultra API AWS - Deployment Guide

**Generated:** 2025-11-07
**Project:** ultra-api-aws
**Stack:** Python FastAPI + PostgreSQL + Redis + Celery

## Table of Contents

1. [Overview](#overview)
2. [Docker Deployment](#docker-deployment)
3. [CI/CD Pipeline](#cicd-pipeline)
4. [Environment Configuration](#environment-configuration)
5. [Database Setup](#database-setup)
6. [Running Modes](#running-modes)

---

## Overview

The ultra-api-aws backend is containerized using Docker and supports multiple deployment modes:
- **API Server** (FastAPI with Uvicorn/Gunicorn)
- **Celery Worker** (Background task processing)
- **Celery Beat** (Scheduled tasks)

**Deployment Architecture:**
- **Application**: FastAPI REST API
- **Database**: PostgreSQL (asyncpg driver)
- **Cache/Queue**: Redis
- **Background Workers**: Celery
- **Server**: Gunicorn + Uvicorn workers
- **CI/CD**: GitHub Actions

---

## Docker Deployment

### Dockerfile

**Base Image:** `public.ecr.aws/docker/library/python:3.10-slim`

**Key Features:**
- Non-root user (`app:app` group)
- Python optimizations (no .pyc files, unbuffered output)
- Multi-mode support via `RUN_MODE` environment variable
- Automatic migrations via `prestart.sh`
- Health check support

**Build Process:**
```bash
# Build Docker image
cd /src/ultra-api-aws
docker build -t ultra-api:latest -f docker/Dockerfile .
```

**Dockerfile Stages:**
1. Install system dependencies (curl)
2. Create non-root app user
3. Copy and install Python requirements
4. Copy application code
5. Set entrypoint for mode selection

### Docker Compose Configuration

**Available Compose Files:**
- `docker/all.yml` - Full stack (app, db, redis, celery)
- `docker/app.yml` - API server only
- `docker/db.yml` - PostgreSQL database
- `docker/redis.yml` - Redis cache/queue

**Running Full Stack:**
```bash
cd docker
docker-compose -f all.yml up -d
```

---

## CI/CD Pipeline

**Platform:** GitHub Actions

**Workflow:** `.github/workflows/python-app.yml`

**Trigger Events:**
- Push to `main` branch
- Pull requests to `main`

**Pipeline Steps:**

1. **Checkout Code**
   ```yaml
   uses: actions/checkout@v4
   ```

2. **Setup Python 3.10**
   ```yaml
   uses: actions/setup-python@v3
   with:
     python-version: "3.10"
   ```

3. **Install Dependencies**
   - Upgrade pip
   - Install linting tools (flake8, flake8-tidy-imports)
   - Install test framework (pytest)
   - Install app requirements
   - Install test requirements

4. **Lint with Flake8**
   - Check for syntax errors
   - Check code complexity (max 10)
   - Enforce line length (127 chars)
   - Generate statistics

5. **Run Tests with Pytest**
   - Decrypt `.env.enc` using GPG passphrase
   - Run pytest test suite
   - Environment-specific configuration

**Required Secrets:**
- `GPG_PASSPHRASE` - For decrypting environment file

---

## Environment Configuration

### Environment Files

**Development:** `.env` (decrypted from `.env.enc`)

**Encryption/Decryption:**
```bash
# Encrypt .env file
gpg --output .env.enc --symmetric --cipher-algo AES256 .env

# Decrypt .env file
gpg --output .env --decrypt .env.enc
```

### Required Environment Variables

**Database:**
- `SQLALCHEMY_DATABASE_URL` - PostgreSQL connection string
  - Format: `postgresql+asyncpg://user:password@host:port/database`
  - Example: `postgresql+asyncpg://ultraapi:ultraapipwd@localhost:5532/ultraapidb`

**API Configuration:**
- `PORT` - API server port (default: 8080)
- `BACKEND_CORS_ORIGINS` - JSON array of allowed origins

**AI/LLM:**
- `OPENAI_API_KEY` - OpenAI API key
- `SELECTED_MODEL` - Model selection (default: gpt-3.5-turbo)
- `BEDROCK_AWS_*` - AWS Bedrock credentials
- `GEMINI_API_KEY` - Google Gemini API key
- `MISTRAL_API_KEY` - Mistral AI API key

**External Services:**
- `ZEP_API_KEY`, `ZEP_API_URL` - Zep memory service
- `FIREBASE_*` - Firebase configuration
- `TWILIO_*` - Twilio SMS/WhatsApp
- `TTS_API_KEY` - Text-to-speech service

**Feature Flags:**
- `RATE_REDUCE` - Enable rate limiting (default: false)
- `OPENAI_ONLY` - Use only OpenAI (default: true)
- `USE_CUSTOM_CONTEXT` - Enable custom context (default: true)

**Admin:**
- `ADMIN_API_KEY` - Admin API authentication key

---

## Database Setup

### Automatic Migrations

Migrations run automatically on container startup via `prestart.sh`:

```bash
# Set database URL
export SQLALCHEMY_DATABASE_URL=postgresql+asyncpg://ultraapi:ultraapipwd@localhost:5532/ultraapidb

# Run migrations
cd app
alembic upgrade head
```

### Manual Migration Commands

```bash
# Create new migration
alembic revision --autogenerate -m "description"

# Apply migrations
alembic upgrade head

# Rollback one migration
alembic downgrade -1

# View current version
alembic current

# View history
alembic history
```

### Database Connection

**PostgreSQL Requirements:**
- Version: 13+
- Extensions: uuid-ossp
- User: ultraapi
- Database: ultraapidb
- Port: 5532 (custom to avoid conflict with Zep)

**Connection Pool:**
- Pool size: Configurable via `DB_POOL_SIZE` (default: 5)
- Max overflow: 20
- Pool recycle: 300 seconds
- Pool timeout: 60 seconds

---

## Running Modes

The application supports multiple run modes controlled by the `RUN_MODE` environment variable:

### 1. API Server Mode (Default)

**Purpose:** Run FastAPI REST API

**Command:**
```bash
# Using run script (production)
cd app
./run.sh

# Using uvicorn with reload (development)
./run-reload.sh

# Using Python directly (debugging)
python app/main.py
```

**Server Configuration:**
- **Gunicorn** workers with **Uvicorn** worker class
- Worker count: Auto (CPU cores)
- Bind: `0.0.0.0:${PORT}`
- Timeout: 120 seconds

**Access:**
- API: `http://localhost:8080/api/`
- Docs: `http://localhost:8080/docs` (Swagger UI)
- ReDoc: `http://localhost:8080/redoc`
- Health: `http://localhost:8080/healthz`

### 2. Celery Worker Mode

**Purpose:** Process background tasks

**Environment:**
```bash
export RUN_MODE=celery
```

**Command:**
```bash
cd app
./run-celery.sh
```

**Celery Configuration:**
- Broker: Redis
- Result backend: Redis
- Task modules: `app.background.worker`

### 3. Celery Beat Mode

**Purpose:** Schedule periodic tasks

**Environment:**
```bash
export RUN_MODE=beat
```

**Command:**
```bash
cd app
celery -A app.background.beat beat --loglevel=info
```

---

## Development Workflows

### Local Development Setup

1. **Clone Repository**
   ```bash
   git clone <repository-url>
   cd ultra-api-aws
   ```

2. **Create Virtual Environment**
   ```bash
   python -m venv .venv
   source .venv/bin/activate  # On Windows: .venv\Scripts\activate
   ```

3. **Install Dependencies**
   ```bash
   pip install -r app/requirements.txt
   ```

4. **Setup Environment**
   ```bash
   cp .env_blank .env
   # Edit .env with your configuration
   ```

5. **Start Database**
   ```bash
   ./scripts/start-stop-db.sh
   ```

6. **Run Migrations**
   ```bash
   export SQLALCHEMY_DATABASE_URL=postgresql+asyncpg://ultraapi:ultraapipwd@localhost:5532/ultraapidb
   cd app
   alembic upgrade head
   ```

7. **Start API Server**
   ```bash
   cd app
   ./run-reload.sh  # Auto-reload on code changes
   ```

### VS Code Debugging

**Launch Configuration:**
```json
{
  "name": "Ultra-api: Uvicorn",
  "type": "python",
  "request": "launch",
  "module": "uvicorn",
  "args": [
    "app.main:app",
    "--reload",
    "--host", "0.0.0.0",
    "--port", "8080"
  ],
  "env": {
    "SQLALCHEMY_DATABASE_URL": "postgresql+asyncpg://ultraapi:ultraapipwd@localhost:5532/ultraapidb",
    "PYTHONPATH": "${workspaceFolder}/app"
  },
  "console": "integratedTerminal"
}
```

**Steps:**
1. Start database: `./scripts/start-stop-db.sh`
2. Run migrations
3. Set breakpoints in VS Code
4. Press F5 or click "Run & Debug"

---

## Production Deployment

### Prerequisites

- Docker installed
- PostgreSQL database accessible
- Redis accessible
- Environment variables configured

### Deployment Steps

1. **Build Docker Image**
   ```bash
   docker build -t ultra-api:latest -f docker/Dockerfile .
   ```

2. **Tag for Registry**
   ```bash
   docker tag ultra-api:latest <registry>/ultra-api:latest
   docker push <registry>/ultra-api:latest
   ```

3. **Deploy API Server**
   ```bash
   docker run -d \
     --name ultra-api \
     -p 8080:8080 \
     -e SQLALCHEMY_DATABASE_URL="postgresql+asyncpg://..." \
     -e PORT=8080 \
     -e RUN_MODE=api \
     <registry>/ultra-api:latest
   ```

4. **Deploy Celery Worker**
   ```bash
   docker run -d \
     --name ultra-celery-worker \
     -e SQLALCHEMY_DATABASE_URL="postgresql+asyncpg://..." \
     -e RUN_MODE=celery \
     <registry>/ultra-api:latest
   ```

5. **Deploy Celery Beat**
   ```bash
   docker run -d \
     --name ultra-celery-beat \
     -e SQLALCHEMY_DATABASE_URL="postgresql+asyncpg://..." \
     -e RUN_MODE=beat \
     <registry>/ultra-api:latest
   ```

### Health Checks

**API Health:**
```bash
curl http://localhost:8080/healthz
# Expected: {"status": 200}
```

**Database Connection:**
```bash
# Check database connectivity
psql "postgresql://ultraapi:ultraapipwd@localhost:5532/ultraapidb" -c "SELECT 1"
```

**Celery Workers:**
```bash
# Check active workers
celery -A app.background.worker inspect active
```

---

## Monitoring & Logging

### Logging Configuration

**Framework:** Python `logging` module

**Log Levels:**
- Application: `INFO`
- SQLAlchemy: `WARNING`
- Asyncio: `INFO`

**Log Format:**
```
%(asctime)s - %(thread)d - %(process)d - %(threadName)s - %(levelname)s - %(message)s
```

### Instrumentation

**Tool:** Logfire

**Instrumented Components:**
- FastAPI requests
- SQLAlchemy queries
- AsyncPG database calls
- Redis operations
- OpenAI API calls
- Celery tasks
- System metrics
- HTTP clients (httpx, requests, aiohttp)

**Configuration:**
```python
import logfire
logfire.configure()
logfire.instrument_fastapi(app, excluded_urls='^(?!.*(/api)).*$')
```

### Metrics & Observability

- **Request metrics** via Logfire
- **Slow callback detection** (threshold: 0.1s)
- **System metrics** tracking
- **Database connection pooling** metrics

---

## Security Considerations

### Application Security

- **Non-root user** in Docker container
- **Environment variable encryption** (GPG)
- **Secret management** via GitHub Secrets (CI/CD)
- **CORS** configuration
- **JWT authentication** for API endpoints
- **API key authentication** for webhooks

### Database Security

- **Connection pooling** with limits
- **Parameterized queries** (SQLAlchemy ORM)
- **Connection recycling** (300s)
- **Pool pre-ping** for connection health

### Network Security

- **CORS** whitelist configuration
- **HTTPS enforcement** (production)
- **Rate limiting** (optional, via `RATE_REDUCE` flag)

---

## Troubleshooting

### Common Issues

**Database Connection Error:**
```bash
# Check database is running
./scripts/start-stop-db.sh

# Verify connection string
echo $SQLALCHEMY_DATABASE_URL

# Test connection
psql "$SQLALCHEMY_DATABASE_URL"
```

**Migration Errors:**
```bash
# Check current version
alembic current

# View migration history
alembic history

# Rollback and retry
alembic downgrade -1
alembic upgrade head
```

**Port Already in Use:**
```bash
# Find process using port 8080
lsof -i :8080

# Kill process
kill -9 <PID>
```

**Import Errors:**
```bash
# Ensure PYTHONPATH is set
export PYTHONPATH=/path/to/ultra-api-aws/app

# Verify from app directory
cd app
python -c "import app; print(app.__file__)"
```

---

## File Locations

**Docker:**
- Dockerfile: `/src/ultra-api-aws/docker/Dockerfile`
- Compose files: `/src/ultra-api-aws/docker/*.yml`
- Entrypoint: `/src/ultra-api-aws/docker/entrypoint.sh`

**CI/CD:**
- GitHub Actions: `/src/ultra-api-aws/.github/workflows/python-app.yml`

**Scripts:**
- Build: `/src/ultra-api-aws/scripts/build-app-image.sh`
- Database: `/src/ultra-api-aws/scripts/start-stop-db.sh`
- App Control: `/src/ultra-api-aws/scripts/start-stop-app.sh`

**Application:**
- Main: `/src/ultra-api-aws/app/app/main.py`
- Run scripts: `/src/ultra-api-aws/app/run.sh`, `run-reload.sh`, `run-celery.sh`
- Prestart: `/src/ultra-api-aws/app/prestart.sh`

---

## Summary

**Deployment Stack:**
- Container: Docker
- Orchestration: Docker Compose
- CI/CD: GitHub Actions
- Database: PostgreSQL 13+
- Cache/Queue: Redis
- Background Tasks: Celery
- Server: Gunicorn + Uvicorn
- Monitoring: Logfire

**Supported Modes:**
1. API Server (FastAPI)
2. Celery Worker
3. Celery Beat

**Key Features:**
- Multi-mode deployment via `RUN_MODE`
- Automatic database migrations
- Health check endpoints
- Comprehensive instrumentation
- Non-root container execution
- Environment encryption
- CI/CD automation
