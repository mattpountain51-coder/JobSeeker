# Ultra API AWS - Project Documentation

**Project:** ultra-api-aws
**Type:** Backend API (Python FastAPI)
**Generated:** 2025-11-07
**Scan Level:** Exhaustive

---

## Quick Reference

**Project Structure:** Monolith
**Primary Language:** Python 3.10
**Framework:** FastAPI
**Architecture:** REST API with Background Workers
**Database:** PostgreSQL (asyncpg)
**Cache/Queue:** Redis
**Background Tasks:** Celery

**Key Statistics:**
- **API Endpoints:** 87 total (61 public, 25 admin, 1 restricted)
- **Database Tables:** 12 core tables
- **Migrations:** 13 Alembic migrations
- **Tech Stack:** Multi-LLM AI platform with chat capabilities

---

## Table of Contents

1. [Project Overview](#project-overview)
2. [Getting Started](#getting-started)
3. [Architecture](#architecture)
4. [Generated Documentation](#generated-documentation)
5. [Existing Documentation](#existing-documentation)
6. [Development Guide](#development-guide)

---

## Project Overview

Ultra API AWS is a **Python FastAPI backend** that provides an AI-powered conversational platform. The system enables users to create and interact with AI character profiles through multi-channel chat sessions, with support for multiple LLM providers, memory management, and comprehensive analytics.

### Core Capabilities

**AI/LLM Integration:**
- Multiple LLM providers (OpenAI, AWS Bedrock, Google Gemini, Mistral AI)
- LangChain & LlamaIndex frameworks
- Zep Cloud memory/context management
- Custom context and fact extraction

**Chat & Messaging:**
- Multi-user chat sessions
- AI character interactions
- Voice, text, and video channels
- Message reactions and feedback
- Session state management

**User Management:**
- User profiles with preferences
- Character profile creation (custom AI personalities)
- Session-based conversations
- User metrics and analytics

**External Integrations:**
- Twilio (SMS/WhatsApp)
- Firebase (auth, push notifications)
- ElevenLabs (Text-to-Speech)
- Plaid (banking, if applicable)

### Technology Stack

**Backend:**
- Python 3.10
- FastAPI (REST API framework)
- SQLAlchemy (async ORM)
- Alembic (database migrations)
- Pydantic (data validation)

**AI/ML:**
- LangChain 0.3.9
- LlamaIndex 0.10.50
- OpenAI SDK
- langchain-aws, langchain-google-genai, langchain-mistralai
- Zep Python SDK

**Database & Cache:**
- PostgreSQL 13+ (asyncpg driver)
- Redis 4.5.5

**Background Processing:**
- Celery 5.4.0
- Celery Beat (scheduled tasks)
- Redis broker

**Monitoring:**
- Logfire instrumentation (FastAPI, SQLAlchemy, OpenAI, Celery, etc.)

**Deployment:**
- Docker & Docker Compose
- Gunicorn + Uvicorn workers
- GitHub Actions CI/CD

---

## Getting Started

### Prerequisites

- Python 3.10+
- PostgreSQL 13+
- Redis
- Docker (optional)

### Quick Start

```bash
# 1. Clone and setup
git clone <repository>
cd ultra-api-aws

# 2. Create virtual environment
python -m venv .venv
source .venv/bin/activate

# 3. Install dependencies
pip install -r app/requirements.txt

# 4. Setup environment
cp .env_blank .env
# Edit .env with your configuration

# 5. Start database
./scripts/start-stop-db.sh

# 6. Run migrations
export SQLALCHEMY_DATABASE_URL=postgresql+asyncpg://ultraapi:ultraapipwd@localhost:5532/ultraapidb
cd app
alembic upgrade head

# 7. Start API server
./run-reload.sh
```

### Access Points

- **API Base:** `http://localhost:8080/api/`
- **API Docs (Swagger):** `http://localhost:8080/docs`
- **API Docs (ReDoc):** `http://localhost:8080/redoc`
- **Health Check:** `http://localhost:8080/healthz`

---

## Architecture

### System Design

```
┌─────────────────────────────────────────────────────────┐
│                    Client Applications                   │
│              (Mobile, Web, Third-party)                  │
└───────────────────────┬─────────────────────────────────┘
                        │ HTTPS/REST
                        ▼
┌─────────────────────────────────────────────────────────┐
│              FastAPI REST API (Gunicorn + Uvicorn)      │
│                                                           │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐ │
│  │  Public API  │  │  Admin API   │  │Restricted API│ │
│  │  (/api/v1/)  │  │ (/api/admin/)│  │ (Webhooks)   │ │
│  │  61 endpoints│  │ 25 endpoints │  │  1 endpoint  │ │
│  └──────────────┘  └──────────────┘  └──────────────┘ │
└───────┬───────────────────────────────────────┬─────────┘
        │                                       │
        │ Async I/O                            │ Background
        ▼                                       ▼
┌─────────────────┐                   ┌──────────────────┐
│   PostgreSQL    │                   │ Celery Workers   │
│  (12 tables)    │◄──────────────────│  + Celery Beat   │
│  UUID PKs       │                   │  (Redis broker)  │
│  Soft deletes   │                   └──────────────────┘
└─────────────────┘
        ▲
        │
        │
┌───────┴────────────────────────────────────────────────┐
│                   Business Logic Layer                  │
│                                                          │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐│
│  │ Chat Service │  │  AI Service  │  │User Service  ││
│  │              │  │  (LangChain) │  │              ││
│  └──────────────┘  └──────────────┘  └──────────────┘│
└───────┬──────────────────────────────────────┬─────────┘
        │                                      │
        ▼                                      ▼
┌─────────────────┐                   ┌──────────────────┐
│     Redis       │                   │  External APIs   │
│ (Cache/Queue)   │                   │                  │
└─────────────────┘                   │ - OpenAI         │
                                       │ - AWS Bedrock    │
                                       │ - Google Gemini  │
                                       │ - Mistral AI     │
                                       │ - Zep Cloud      │
                                       │ - Firebase       │
                                       │ - Twilio         │
                                       │ - ElevenLabs     │
                                       └──────────────────┘
```

### Data Flow

**1. User Authentication:**
- Client → POST /api/v1/login/access-token
- API validates credentials (future: Firebase/Cognito)
- Returns JWT token
- Client includes token in all subsequent requests

**2. Chat Session Flow:**
- User creates/selects character profile
- Creates chat session with character
- Sends message via POST /api/v1/chat/
- Backend:
  - Retrieves session context from PostgreSQL
  - Loads character configuration
  - Calls LLM provider (OpenAI/Bedrock/etc.)
  - Stores message in database
  - Updates session state
  - Returns AI response
- Frontend displays response

**3. Background Processing:**
- Scheduled nudges (Celery Beat)
- Message processing (Celery Worker)
- Metrics aggregation (Celery Worker)
- Push notification delivery

### Multi-Tenancy

All data is isolated by `user_id`:
- Every table includes `user_id` column (indexed)
- Queries filter by current authenticated user
- Admin API can access across users (superuser role)
- Soft deletes via `deleted_at` timestamp

---

## Generated Documentation

### Core API Documentation

**[API Contracts](./api-contracts.md)** - Complete API Reference
- **87 endpoints** across 3 API sections
- Public API (v1): 61 endpoints
  - Authentication & sessions
  - User & profile management
  - Chat & messaging
  - Plaid banking integration
  - Financial data (items, accounts, transactions)
- Admin API: 25 endpoints (superuser only)
- Restricted API: 1 endpoint (Plaid webhooks)
- Request/response schemas
- Authentication requirements
- Error handling

### Database Documentation

**[Data Models](./data-models.md)** - Database Schema Reference
- **12 core tables** with full schemas
- Entity-relationship diagrams
- Column definitions, types, constraints
- Indexes and foreign keys
- **13 migrations** documented
- Query patterns and examples
- Performance considerations

**Core Tables:**
1. `user_profile` - User accounts and preferences
2. `character_profile` - AI character definitions
3. `sessions` - Chat session management
4. `user_sessions` - User participation tracking
5. `session_participant` - AI character participation
6. `channels` - Communication channels
7. `chats` - Individual messages
8. `reactions` - Message reactions
9. `feedback` - User feedback on AI responses
10. `nudges` - System notifications
11. `user_metrics` - Analytics
12. `ref_data` - Reference/lookup data

### Deployment Documentation

**[Deployment Guide](./deployment-guide.md)** - Deployment & Operations
- Docker setup and configuration
- Multi-mode deployment (API, Celery Worker, Celery Beat)
- Environment configuration
- CI/CD pipeline (GitHub Actions)
- Database migration procedures
- Development workflows
- Production deployment steps
- Monitoring and logging
- Troubleshooting guide

---

## Existing Documentation

**Project Root Documentation:**
- [README.md](../src/ultra-api-aws/README.md) - Installation and setup guide
  - Python environment setup
  - Database setup with Alembic
  - Multiple running modes (run.sh, uvicorn, Python, VS Code)
  - Twilio integration setup
  - Environment encryption guide
  - Character creation examples

**Test Documentation:**
- [app/test/README.md](../src/ultra-api-aws/app/test/README.md) - Testing documentation

**Performance Testing:**
- [perf_test/README.md](../src/ultra-api-aws/perf_test/README.md) - Performance testing guide

**CI/CD:**
- [.github/workflows/python-app.yml](../src/ultra-api-aws/.github/workflows/python-app.yml) - GitHub Actions workflow

---

## Development Guide

### Project Structure

```
ultra-api-aws/
├── app/
│   ├── app/                    # Main application code
│   │   ├── api/               # API endpoints
│   │   │   ├── api_v1/       # Public API v1
│   │   │   ├── admin/        # Admin API
│   │   │   └── restricted/   # Restricted API (webhooks)
│   │   ├── chat/             # Chat/AI logic
│   │   ├── core/             # Core utilities and config
│   │   ├── db/               # Database models
│   │   ├── integrations/     # External service integrations
│   │   ├── nudger/          # Nudge notification system
│   │   ├── schemas/         # Pydantic schemas
│   │   ├── service/         # Business logic services
│   │   └── main.py          # FastAPI application entry point
│   ├── background/           # Celery tasks
│   ├── alembic/             # Database migrations
│   ├── test/                # Test suite
│   ├── requirements.txt     # Python dependencies
│   ├── run.sh               # Production run script
│   ├── run-reload.sh        # Development run script (auto-reload)
│   └── run-celery.sh        # Celery worker run script
├── docker/                  # Docker configuration
│   ├── Dockerfile
│   ├── all.yml             # Full stack compose
│   ├── app.yml             # API server compose
│   ├── db.yml              # PostgreSQL compose
│   ├── redis.yml           # Redis compose
│   └── entrypoint.sh       # Container entrypoint
├── scripts/                # Utility scripts
│   ├── build-app-image.sh
│   ├── start-stop-db.sh
│   └── start-stop-app.sh
├── .github/workflows/      # CI/CD
│   └── python-app.yml
├── perf_test/              # Performance tests
└── README.md               # Project README
```

### Key Directories

**API Endpoints** (`/app/app/api/`):
- `api_v1/endpoints/` - Public API implementation
- `admin/endpoints/` - Admin API implementation
- `restricted/endpoints/` - Webhook endpoints
- `deps.py` - Authentication dependencies

**Database Models** (`/app/app/db/`):
- SQLAlchemy models for all tables
- `base.py` - Base model configuration
- Individual model files per table

**Pydantic Schemas** (`/app/app/schemas/`):
- Request/response validation models
- API contract definitions

**Chat/AI Logic** (`/app/app/chat/`):
- LangChain integration
- Character personality management
- Context handling

**Background Tasks** (`/app/background/`):
- Celery worker configuration
- Scheduled tasks
- Async job processing

### Running Different Modes

**API Server (Development with Auto-reload):**
```bash
cd app
export SQLALCHEMY_DATABASE_URL=postgresql+asyncpg://ultraapi:ultraapipwd@localhost:5532/ultraapidb
./run-reload.sh
```

**API Server (Production):**
```bash
cd app
./run.sh
```

**Celery Worker:**
```bash
cd app
export RUN_MODE=celery
./run-celery.sh
```

**Celery Beat (Scheduled Tasks):**
```bash
cd app
export RUN_MODE=beat
celery -A app.background.beat beat --loglevel=info
```

### Testing

```bash
cd app/test
pytest
```

### Database Migrations

```bash
cd app

# Create migration
alembic revision --autogenerate -m "description"

# Apply migrations
alembic upgrade head

# Rollback
alembic downgrade -1
```

---

## Authentication

### Public API

**Type:** JWT Bearer Token

**Login:**
```bash
curl -X POST "http://localhost:8080/api/v1/login/access-token" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "username=user@example.com&password=yourpassword"
```

**Response:**
```json
{
  "access_token": "eyJ0eXAiOiJKV1QiLCJhbGc...",
  "token_type": "bearer"
}
```

**Usage:**
```bash
curl "http://localhost:8080/api/v1/users/me" \
  -H "Authorization: Bearer eyJ0eXAiOiJKV1QiLCJhbGc..."
```

### Admin API

Requires `is_superuser=true` in addition to valid JWT.

### Restricted API

**Type:** API Key

**Header:** `X-API-Key: your-api-key`

---

## Contributing

**Code Style:**
- Follow flake8 rules (max complexity: 10, max line length: 127)
- Use type hints
- Document functions with docstrings

**Testing:**
- Write tests for new endpoints
- Ensure all tests pass before committing
- CI/CD runs automatically on PR

**Database Changes:**
- Always create Alembic migration
- Test migration up and down
- Document schema changes

---

## Support & Resources

**Documentation Files:**
- This index: `/docs/index.md`
- API contracts: `/docs/api-contracts.md`
- Data models: `/docs/data-models.md`
- Deployment: `/docs/deployment-guide.md`
- Project README: `/src/ultra-api-aws/README.md`

**For Brownfield PRD:**
When planning new features, reference:
- `/docs/api-contracts.md` - Understand existing API patterns
- `/docs/data-models.md` - Understand database schema
- `/docs/deployment-guide.md` - Understand deployment process

**Next Steps After Documentation:**
1. Review the generated documentation
2. Run workflow-init to start planning new features
3. Use BMad Method for comprehensive feature planning

---

**Document Version:** 1.0
**Last Updated:** 2025-11-07
**Scan Mode:** Exhaustive
**Maintainer:** Development Team

