# Ultra API AWS - API Contracts

**Generated:** 2025-11-07  
**Project:** ultra-api-aws  
**Framework:** FastAPI

## Overview

The ultra-api-aws backend provides a REST API for AI-powered chat interactions with character profiles.

**API Sections:**
- **Public API** (`/api/v1/`) - Main application API
- **Admin API** (`/api/admin/`) - Administrative operations  
- **Restricted API** (`/api/restricted/`) - Internal/webhook endpoints

**Base URL:** `http://localhost:8080`

---

## Authentication

### Public API
**Type:** Bearer Token (JWT)

**Login:**
```http
POST /api/v1/login/access-token
Content-Type: application/x-www-form-urlencoded

username=user@example.com&password=yourpassword
```

**Response:**
```json
{
  "access_token": "eyJ0eXAi...",
  "token_type": "bearer"
}
```

**Usage:**
```http
Authorization: Bearer {access_token}
```

### Admin API
Requires `is_superuser=true` + valid JWT

### Restricted API  
**Type:** API Key via `X-API-Key` header

---

## Public API (`/api/v1/`)

### Health & Metrics

#### GET /api/v1/health
Health check endpoint

**Auth:** None required

**Response:**
```json
{
  "status": "healthy",
  "timestamp": "2025-01-01T00:00:00Z"
}
```

#### GET /api/v1/metrics
Get user metrics

**Auth:** Bearer token required

**Response:**
```json
{
  "user_id": "user123",
  "total_sessions": 42,
  "total_messages": 1337,
  "characters_created": 5
}
```

---

### User Profiles

#### GET /api/v1/profile
Get current user profile

**Auth:** Bearer token required

**Response:**
```json
{
  "id": "uuid",
  "user_id": "user123",
  "display_name": "John Doe",
  "email": "john@example.com",
  "avatar_url": "https://...",
  "preferences": {},
  "created_at": "2025-01-01T00:00:00Z"
}
```

#### PUT /api/v1/profile
Update user profile

**Auth:** Bearer token required

**Request:**
```json
{
  "display_name": "Jane Doe",
  "avatar_url": "https://...",
  "preferences": {
    "theme": "dark"
  }
}
```

---

### Character Profiles

#### GET /api/v1/character-profiles
List all character profiles for current user

**Auth:** Bearer token required

**Query Params:**
- `skip` (int): Pagination offset  
- `limit` (int): Max results (default: 100)

**Response:**
```json
[
  {
    "id": "char-uuid",
    "user_id": "user123",
    "name": "Assistant",
    "description": "Helpful AI assistant",
    "personality": "Friendly and professional",
    "system_prompt": "You are a helpful assistant...",
    "model_config": {
      "temperature": 0.7,
      "max_tokens": 2000
    },
    "is_public": false,
    "created_at": "2025-01-01T00:00:00Z"
  }
]
```

#### POST /api/v1/character-profiles
Create new character profile

**Auth:** Bearer token required

**Request:**
```json
{
  "name": "My Character",
  "description": "Description here",
  "personality": "Traits here",
  "system_prompt": "You are...",
  "model_config": {
    "temperature": 0.7
  }
}
```

#### GET /api/v1/character-profiles/{id}
Get specific character profile

#### PUT /api/v1/character-profiles/{id}
Update character profile

#### DELETE /api/v1/character-profiles/{id}
Delete character profile

---

### Chat Sessions

#### GET /api/v1/sessions
List all sessions for current user

**Auth:** Bearer token required

**Response:**
```json
[
  {
    "id": "session-uuid",
    "user_id": "user123",
    "character_id": "char-uuid",
    "title": "Chat about AI",
    "status": "active",
    "context": {},
    "last_message_at": "2025-01-01T12:00:00Z",
    "created_at": "2025-01-01T00:00:00Z"
  }
]
```

#### POST /api/v1/sessions
Create new chat session

**Auth:** Bearer token required

**Request:**
```json
{
  "character_id": "char-uuid",
  "title": "New Chat"
}
```

#### GET /api/v1/sessions/{id}
Get specific session

#### PUT /api/v1/sessions/{id}
Update session

#### DELETE /api/v1/sessions/{id}
Delete session

---

### Chat Messages

#### POST /api/v1/web-chat
Send chat message and get AI response

**Auth:** Bearer token required

**Request:**
```json
{
  "session_id": "session-uuid",
  "message": "Hello, how are you?",
  "character_id": "char-uuid"
}
```

**Response:**
```json
{
  "id": "msg-uuid",
  "session_id": "session-uuid",
  "sender_type": "assistant",
  "content": "I'm doing well, thank you! How can I help you?",
  "metadata": {
    "model": "gpt-3.5-turbo",
    "tokens": 42
  },
  "created_at": "2025-01-01T12:00:00Z"
}
```

#### GET /api/v1/chat-structure/{session_id}
Get chat message history for session

**Auth:** Bearer token required

**Response:**
```json
{
  "session_id": "session-uuid",
  "messages": [
    {
      "id": "msg1-uuid",
      "sender_type": "user",
      "content": "Hello",
      "created_at": "2025-01-01T12:00:00Z"
    },
    {
      "id": "msg2-uuid",
      "sender_type": "assistant",
      "content": "Hi there!",
      "created_at": "2025-01-01T12:00:01Z"
    }
  ]
}
```

---

### Channels

#### GET /api/v1/channels
List all channels

#### POST /api/v1/channels
Create new channel

**Request:**
```json
{
  "name": "General Chat",
  "type": "text",
  "description": "Main discussion channel"
}
```

---

### Reference Data

#### GET /api/v1/ref-data
Get reference data by category

**Query Params:**
- `category` (string): Data category

#### POST /api/v1/ref-data
Create reference data entry

---

### Twilio Webhooks

#### POST /api/v1/twilio/webhook
Receive Twilio SMS/WhatsApp messages

**Auth:** None (webhook)

**Request:**
```json
{
  "From": "+1234567890",
  "Body": "Message content",
  "MessageSid": "SM..."
}
```

---

## Admin API (`/api/admin/`)

**Auth:** All endpoints require `is_superuser=true`

### Character Profiles (Admin)

#### GET /api/admin/character-profiles
List ALL character profiles (all users)

#### POST /api/admin/character-profiles
Create character profile for any user

#### PUT /api/admin/character-profiles/{id}
Update any character profile

#### DELETE /api/admin/character-profiles/{id}
Delete any character profile

---

### User Profiles (Admin)

#### GET /api/admin/profile
List all user profiles

#### PUT /api/admin/profile/{user_id}
Update any user profile

---

### Sessions (Admin)

#### GET /api/admin/session-admin
List all sessions (all users)

#### DELETE /api/admin/session-admin/{id}
Delete any session

---

### Experiments (Admin)

#### GET /api/admin/experiments
List all experiments

#### POST /api/admin/experiments
Create experiment

**Request:**
```json
{
  "name": "Feature Test",
  "description": "Testing new feature",
  "variant_a": "control",
  "variant_b": "treatment",
  "active": true
}
```

---

### Nudges (Admin)

#### GET /api/admin/nudges
List all nudges

#### POST /api/admin/nudges
Create nudge notification

**Request:**
```json
{
  "user_id": "user123",
  "nudge_type": "reminder",
  "title": "Check this out",
  "message": "You have unread messages",
  "priority": 1
}
```

---

## Restricted API (`/api/restricted/`)

**Auth:** API Key via `X-API-Key` header

### Character Profiles (Restricted)

#### PUT /api/restricted/character-profiles/{id}
Internal character profile update

### User Profiles (Restricted)

#### PUT /api/restricted/profile/{user_id}
Internal user profile update

---

## Data Models

### UserProfile
```typescript
{
  id: UUID
  user_id: string
  email: string
  display_name: string
  avatar_url: string
  bio: string
  preferences: JSON
  is_active: boolean
  created_at: datetime
  updated_at: datetime
}
```

### CharacterProfile
```typescript
{
  id: UUID
  user_id: string
  name: string
  description: string
  personality: string
  system_prompt: string
  model_config: JSON
  voice_settings: JSON
  is_public: boolean
  is_active: boolean
  created_at: datetime
  updated_at: datetime
}
```

### Session
```typescript
{
  id: UUID
  user_id: string
  character_id: UUID
  title: string
  status: 'active' | 'paused' | 'ended'
  context: JSON
  state: JSON
  last_message_at: datetime
  created_at: datetime
  updated_at: datetime
}
```

### Chat
```typescript
{
  id: UUID
  user_id: string
  session_id: UUID
  channel_id: UUID
  sender_id: string
  sender_type: 'user' | 'assistant' | 'system'
  content: string
  content_type: string
  metadata: JSON
  created_at: datetime
}
```

---

## Error Responses

### 400 Bad Request
```json
{
  "detail": "Invalid request parameters"
}
```

### 401 Unauthorized
```json
{
  "detail": "Could not validate credentials"
}
```

### 403 Forbidden
```json
{
  "detail": "Not enough permissions"
}
```

### 404 Not Found
```json
{
  "detail": "Resource not found"
}
```

### 422 Unprocessable Entity
```json
{
  "detail": [
    {
      "loc": ["body", "field_name"],
      "msg": "field required",
      "type": "value_error.missing"
    }
  ]
}
```

---

## File Locations

**Endpoint Implementation:**
- Public API: `/app/app/api/api_v1/endpoints/`
- Admin API: `/app/app/api/admin/endpoints/`
- Restricted API: `/app/app/api/restricted/endpoints/`

**Schemas:** `/app/app/schemas/`

**Main Application:** `/app/app/main.py`

---

**For detailed database schema, see data-models.md**
