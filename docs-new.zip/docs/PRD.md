# Constellation Gamification System - Product Requirements Document

**Author:** BMad
**Date:** 2025-11-22
**Version:** 1.0
**Project:** Jaimee AI Companion - Backend Gamification Services

---

## Executive Summary

### Vision

The Constellation Gamification System transforms therapeutic growth into a visual, collectible experience for women using Jaimee, creating an **emotional memory palace** that celebrates progress without anxiety, FOMO, or social pressure.

Unlike traditional gamification that rewards time spent or arbitrary milestones, this system recognizes **depth of engagement** and **authentic emotional breakthroughs**, making growth visible and meaningful.

### What Makes This Special

**The Breakthrough Moment Anchor:** When users tap a constellation, they're instantly transported back to the exact conversation where they had that transformative insight. It's not just a badge - it's an **emotional bookmark** in their healing journey.

**Core Innovation:**
- **Trigger-based earning** - Constellations unlock during breakthrough moments or deep weekly reflections, not XP grinding
- **Depth over duration** - Quality of engagement matters more than time spent
- **Safe, supportive, present** - No punishment mechanics, no social comparison, no streaks to maintain
- **Personal journey visualization** - Your constellation sky reflects YOUR unique path

---

## Project Classification

**Technical Type:** Backend API/Service (Python FastAPI)
**Integration Approach:** Modular addition to existing Ultra API AWS codebase (designed for future extraction as microservice)
**Domain:** Mental Health / Therapeutic AI Companion
**Target Audience:** Women using Jaimee AI companion
**Complexity:** High (therapeutic gamification, AI-driven triggers, complex progression system)

### Brownfield Context

**Existing Codebase:** Ultra API AWS
- **Stack:** Python 3.10, FastAPI, PostgreSQL, Redis, Celery, SQLAlchemy
- **Architecture:** API endpoints (v1, admin), background workers, database models
- **Key Integrations:** LangChain, OpenAI, AWS Bedrock, Zep Cloud (memory), Firebase (auth)
- **Existing Tables:** user_profile, sessions, chats, character_profile, user_sessions, etc.

**Integration Points:**
- Leverage existing user authentication and session management
- Integrate with existing chat message flow for breakthrough detection
- Use existing Celery infrastructure for background processing (weekly reflections)
- Extend database schema with new constellation-related tables

**Modularity Requirement:**
Design services with clear boundaries to enable future extraction as standalone microservice if needed.

### Domain Context - Therapeutic Application

**Mental Health Considerations:**
- **Safety-first design** - No mechanics that create anxiety or pressure
- **Privacy** - Constellation data is deeply personal (tied to vulnerable moments)
- **Therapeutic alignment** - Every feature supports emotional growth, not addiction
- **User agency** - Users control their journey, no forced engagement

**Best Practices:**
- Avoid FOMO mechanics (daily streaks, time-limited rewards)
- No social comparison or leaderboards
- Celebrate progress without punishing breaks
- Growth is permanent (no regression/fading)

---

## Success Criteria

### User Experience Success

**Primary Metrics:**
1. **Increased reflection depth** - Weekly reflection quality improves over time (measured by AI depth scoring)
2. **Breakthrough moments captured** - Users mark or AI detects 2+ meaningful insights per week
3. **Constellation engagement** - 60%+ of users revisit constellations to review past breakthroughs
4. **Reduced "not making progress" distortion** - Users report feeling more aware of their growth

**User Sentiment:**
- "I can see how far I've come" - Visual progress representation
- "I love looking back at my breakthroughs" - Emotional anchoring works
- "It doesn't feel like a game" - Therapeutic integrity maintained
- "No pressure, just celebration" - Safe and supportive experience

### Technical Success

**Performance:**
- Breakthrough detection latency < 2s (real-time during conversation)
- Weekly reflection analysis completes within 30s
- Constellation sky loads in < 1s (for 88+ constellations)

**Reliability:**
- 99.9% uptime for constellation services (no data loss)
- Idempotent constellation unlocks (no duplicate awards)
- Graceful degradation if AI detection fails (fallback to manual marking)

### Business Metrics

**Engagement:**
- Increased session frequency (users return more often to check progress)
- Longer session duration (users engage more deeply when progress is visible)
- Reduced churn (visualization of growth increases retention)

**Platform Health:**
- Modular architecture enables future monetization (custom constellations, premium tiers)
- Data insights into user growth patterns inform product development
- Foundation for broader gamification ecosystem

---

## Product Scope

### MVP - Phase 1 (Core Loop)

**Must Have for Launch:**

**1. Breakthrough Moment Detection & Unlock**
- AI detects breakthrough moments during conversations (real-time)
- User can manually mark "This conversation helped me understand something"
- Constellation unlocks immediately with celebration
- Breakthrough is saved as memory anchor (links back to chat message)

**2. Three Category System**
- **Emotion** (35 constellations) - Understanding your inner world
- **Courage** (27 constellations) - Taking action despite fear
- **Presence** (26 constellations) - Grounded mindfulness
- Category assignment based on breakthrough type (AI-determined)

**3. Basic Constellation Collection**
- 20-30 constellations available in MVP (subset of final 88)
- Single evolution stage (stars only, no multi-stage evolution yet)
- Constellation metadata: name, mythology snippet, category, earn timestamp

**4. Digital Sky Map API**
- GET /constellations - Retrieve user's earned constellations
- GET /constellations/{id} - View details, including linked breakthrough conversation
- Visual state: earned vs locked constellations

**5. Backend Services**
- Breakthrough detection service (AI-powered analysis)
- Constellation unlock service (idempotent, transactional)
- Progress tracking service (user stats, category counts)

**Out of MVP Scope:**
- Weekly reflection depth analysis (Phase 2)
- Multi-stage evolution (Stars → Lines → Illustrated Glory) (Phase 2)
- Celestial Levels meta-progression (Phase 3)
- Celebration ritual feature (Phase 3)
- Frontend implementation (separate PRD)

---

### Growth Features (Phase 2 - Post-MVP)

**Depth & Progression:**

**1. Weekly Reflection System**
- Sunday prompt: "What's changed for you this week?"
- Hybrid depth analysis (AI quality + self-assessment + reflection length)
- Unlock formula determines rarity tier (Common/Rare/Epic/Legendary)

**2. Multi-Stage Evolution**
- **Stage 1 (Stars)** - Initial unlock
- **Stage 2 (Lines)** - Revisit growth area 3+ times
- **Stage 3 (Glory)** - Teach/share what you learned (wisdom note)
- Category-specific visual aesthetics

**3. Full Constellation Set**
- Complete 88 constellation library
- Hybrid/intersection constellations (require multiple categories)
- Mythology and story content for each constellation

**4. Rarity Tiers**
- Common, Rare, Epic, Legendary based on unlock pathway
- Visual indicators (subtle, not overwhelming)

---

### Vision Features (Phase 3 - Long Term)

**Meta-Progression & Celebration:**

**1. Celestial Levels System**
- **Tier 1** (Complete 1 category): Create custom constellation
- **Tier 2** (Complete 2 categories): AI meta-abilities unlock
- **Tier 3** (Complete all 3): Optional mentor role (leave wisdom notes for others)

**2. Celebration Ritual**
- Weekly visual celebration (2-3 min)
- Progress visualization as gratitude practice
- User-initiated "show me my sky" feature

**3. Advanced Analytics**
- Growth pattern insights
- Category balance recommendations
- Personalized encouragement based on progress

---

## Backend API Specific Requirements

### Service Architecture

**Modularity Requirements:**
Design services with clear bounded contexts to enable future extraction:

**1. Constellation Service** (Core)
- Manages constellation library, user progress, unlock logic
- Self-contained business logic
- Clear API contracts

**2. Breakthrough Detection Service**
- AI-powered analysis of conversations
- Trigger determination (Emotion/Courage/Presence)
- Pluggable interface (can swap detection algorithms)

**3. Progress Tracking Service**
- User statistics, category completion tracking
- Evolution stage management
- Achievement calculations

**4. Integration Layer**
- Adapters to existing Ultra API services
- Event publishers for constellation unlocks
- Webhook support for frontend notifications

### Database Schema (Hybrid Approach)

**Design Strategy:** New constellation tables with foreign keys to existing tables (user_profile, chats, sessions)

#### New Tables

**1. constellation_library** (Reference Data)
```sql
CREATE TABLE constellation_library (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    constellation_key VARCHAR(50) UNIQUE NOT NULL,  -- e.g., "leo", "pisces"
    name VARCHAR(100) NOT NULL,                      -- Display name
    category VARCHAR(20) NOT NULL,                   -- emotion, courage, presence
    mythology_short TEXT,                            -- Brief mythology (MVP)
    mythology_full TEXT,                             -- Complete story (Phase 2)
    sort_order INTEGER,                              -- Display ordering
    is_active BOOLEAN DEFAULT true,                  -- MVP subset flag
    is_hybrid BOOLEAN DEFAULT false,                 -- Requires multiple categories
    required_categories JSONB,                       -- For hybrid constellations
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Indexes
CREATE INDEX idx_constellation_category ON constellation_library(category);
CREATE INDEX idx_constellation_active ON constellation_library(is_active);
```

**2. user_constellations** (User Progress)
```sql
CREATE TABLE user_constellations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES user_profile(id) ON DELETE CASCADE,
    constellation_id UUID NOT NULL REFERENCES constellation_library(id),

    -- Unlock details
    unlocked_at TIMESTAMP NOT NULL DEFAULT NOW(),
    unlock_type VARCHAR(20) NOT NULL,                -- breakthrough, reflection, manual
    rarity_tier VARCHAR(20) DEFAULT 'common',        -- common, rare, epic, legendary

    -- Evolution (Phase 2)
    evolution_stage INTEGER DEFAULT 1,               -- 1=stars, 2=lines, 3=glory
    stage_2_unlocked_at TIMESTAMP,
    stage_3_unlocked_at TIMESTAMP,
    revisit_count INTEGER DEFAULT 0,                 -- For stage 2 trigger

    -- Breakthrough anchor (if unlocked via breakthrough)
    breakthrough_chat_id UUID REFERENCES chats(id),  -- Links to specific message
    breakthrough_session_id UUID REFERENCES sessions(id),

    -- Reflection anchor (if unlocked via weekly reflection)
    reflection_id UUID,                              -- Links to reflection entry

    -- Metadata
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),

    UNIQUE(user_id, constellation_id)                -- User can only earn each constellation once
);

-- Indexes
CREATE INDEX idx_user_const_user ON user_constellations(user_id);
CREATE INDEX idx_user_const_unlocked ON user_constellations(unlocked_at);
CREATE INDEX idx_user_const_category ON user_constellations(constellation_id);
CREATE INDEX idx_user_const_breakthrough ON user_constellations(breakthrough_chat_id);
```

**3. breakthrough_events** (Detection History)
```sql
CREATE TABLE breakthrough_events (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES user_profile(id) ON DELETE CASCADE,
    session_id UUID REFERENCES sessions(id),
    chat_id UUID REFERENCES chats(id),               -- The specific message

    -- Detection details
    detected_at TIMESTAMP NOT NULL DEFAULT NOW(),
    detection_type VARCHAR(20) NOT NULL,             -- real_time, post_analysis, manual
    category VARCHAR(20) NOT NULL,                   -- emotion, courage, presence
    confidence_score DECIMAL(3,2),                   -- 0.00-1.00 (AI confidence)

    -- AI analysis
    insight_summary TEXT,                            -- What the AI detected
    emotional_indicators JSONB,                      -- Specific markers found

    -- User confirmation
    user_confirmed BOOLEAN,                          -- Did user validate?
    user_marked BOOLEAN DEFAULT false,               -- User manually marked

    -- Constellation unlock linkage
    constellation_unlocked_id UUID REFERENCES user_constellations(id),

    created_at TIMESTAMP DEFAULT NOW()
);

-- Indexes
CREATE INDEX idx_breakthrough_user ON breakthrough_events(user_id);
CREATE INDEX idx_breakthrough_session ON breakthrough_events(session_id);
CREATE INDEX idx_breakthrough_chat ON breakthrough_events(chat_id);
CREATE INDEX idx_breakthrough_category ON breakthrough_events(category);
CREATE INDEX idx_breakthrough_detected ON breakthrough_events(detected_at);
```

**4. weekly_reflections** (Phase 2)
```sql
CREATE TABLE weekly_reflections (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES user_profile(id) ON DELETE CASCADE,

    -- Reflection content
    week_start_date DATE NOT NULL,
    week_end_date DATE NOT NULL,
    reflection_text TEXT NOT NULL,
    self_rating INTEGER,                             -- 1-5 stars (user self-assessment)

    -- Depth analysis
    ai_quality_score DECIMAL(3,2),                   -- 0.00-1.00
    depth_score DECIMAL(3,2),                        -- 0.00-1.00 (combined metric)
    rarity_tier VARCHAR(20),                         -- Determined tier

    -- Unlock linkage
    constellations_unlocked JSONB,                   -- Array of constellation IDs earned

    -- Metadata
    submitted_at TIMESTAMP NOT NULL DEFAULT NOW(),
    analyzed_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW(),

    UNIQUE(user_id, week_start_date)                 -- One reflection per week
);

-- Indexes
CREATE INDEX idx_reflection_user ON weekly_reflections(user_id);
CREATE INDEX idx_reflection_week ON weekly_reflections(week_start_date);
CREATE INDEX idx_reflection_submitted ON weekly_reflections(submitted_at);
```

**5. user_constellation_stats** (Aggregated Progress)
```sql
CREATE TABLE user_constellation_stats (
    user_id UUID PRIMARY KEY REFERENCES user_profile(id) ON DELETE CASCADE,

    -- Overall counts
    total_unlocked INTEGER DEFAULT 0,
    emotion_count INTEGER DEFAULT 0,
    courage_count INTEGER DEFAULT 0,
    presence_count INTEGER DEFAULT 0,

    -- Category completion
    emotion_complete BOOLEAN DEFAULT false,          -- All 35 unlocked
    courage_complete BOOLEAN DEFAULT false,          -- All 27 unlocked
    presence_complete BOOLEAN DEFAULT false,         -- All 26 unlocked

    -- Rarity distribution
    common_count INTEGER DEFAULT 0,
    rare_count INTEGER DEFAULT 0,
    epic_count INTEGER DEFAULT 0,
    legendary_count INTEGER DEFAULT 0,

    -- Evolution progress (Phase 2)
    stage_2_count INTEGER DEFAULT 0,
    stage_3_count INTEGER DEFAULT 0,

    -- Celestial levels (Phase 3)
    celestial_tier INTEGER DEFAULT 0,                -- 0=none, 1-3=tier unlocked

    -- Timestamps
    first_unlock_at TIMESTAMP,
    last_unlock_at TIMESTAMP,
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Automatically updated by triggers
```

#### Database Triggers

**Auto-update stats on constellation unlock:**
```sql
CREATE OR REPLACE FUNCTION update_constellation_stats()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO user_constellation_stats (user_id, total_unlocked)
    VALUES (NEW.user_id, 1)
    ON CONFLICT (user_id) DO UPDATE
    SET
        total_unlocked = user_constellation_stats.total_unlocked + 1,
        last_unlock_at = NEW.unlocked_at,
        updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_update_stats_on_unlock
AFTER INSERT ON user_constellations
FOR EACH ROW EXECUTE FUNCTION update_constellation_stats();
```

---

### API Endpoints

**Base Path:** `/api/v1/constellations`

**Authentication:** All endpoints require Firebase auth token (existing auth middleware)

#### Phase 1 (MVP) Endpoints

**1. GET /api/v1/constellations/library**
```
Description: Get available constellation library (both locked and unlocked)
Query Params:
  - category: Optional filter (emotion|courage|presence)
  - unlocked_only: boolean (default false)
Response: {
  "constellations": [
    {
      "id": "uuid",
      "key": "leo",
      "name": "Leo",
      "category": "courage",
      "mythology_short": "The lion who...",
      "is_unlocked": boolean,
      "unlocked_at": "timestamp | null",
      "unlock_details": {...} | null
    }
  ],
  "stats": {
    "total_available": 30,
    "total_unlocked": 5,
    "by_category": {...}
  }
}
```

**2. GET /api/v1/constellations/sky**
```
Description: Get user's constellation sky (earned constellations with details)
Response: {
  "constellations": [
    {
      "id": "uuid",
      "constellation": {...},  // Full constellation data
      "unlocked_at": "timestamp",
      "unlock_type": "breakthrough",
      "rarity_tier": "rare",
      "breakthrough_link": {
        "chat_id": "uuid",
        "session_id": "uuid",
        "message_preview": "I just realized..."
      } | null
    }
  ],
  "progress": {
    "total_unlocked": 5,
    "emotion_count": 2,
    "courage_count": 2,
    "presence_count": 1,
    "completion_percentage": 16.7
  }
}
```

**3. GET /api/v1/constellations/{constellation_id}**
```
Description: Get detailed info about a specific constellation
Response: {
  "constellation": {...},
  "user_progress": {
    "is_unlocked": boolean,
    "unlocked_at": "timestamp" | null,
    "unlock_story": {
      "type": "breakthrough",
      "breakthrough_message": {...},
      "session_context": {...}
    } | null
  },
  "mythology": {
    "short": "Brief text",
    "full": "Complete story (Phase 2)"
  }
}
```

**4. POST /api/v1/constellations/breakthrough/mark**
```
Description: User manually marks a breakthrough moment
Request Body: {
  "chat_id": "uuid",           // The message that was meaningful
  "category": "emotion",        // Optional (AI can determine)
  "note": "This helped me realize..."  // Optional user note
}
Response: {
  "breakthrough_id": "uuid",
  "constellation_unlocked": {
    "id": "uuid",
    "constellation": {...},
    "celebration": {
      "message": "You've unlocked Leo!",
      "category": "courage"
    }
  } | null,
  "status": "breakthrough_recorded" | "constellation_unlocked"
}
```

**5. GET /api/v1/constellations/progress**
```
Description: Get user's overall progress and stats
Response: {
  "stats": {
    "total_unlocked": 5,
    "total_available": 30,
    "completion_percentage": 16.7,
    "by_category": {
      "emotion": {"unlocked": 2, "total": 35},
      "courage": {"unlocked": 2, "total": 27},
      "presence": {"unlocked": 1, "total": 26}
    },
    "by_rarity": {
      "common": 3,
      "rare": 2,
      "epic": 0,
      "legendary": 0
    }
  },
  "recent_unlocks": [...],     // Last 5 constellations
  "next_milestones": [...]     // Upcoming achievements
}
```

**6. POST /api/v1/constellations/admin/unlock** (Admin only)
```
Description: Manually unlock constellation for testing/support
Request Body: {
  "user_id": "uuid",
  "constellation_key": "leo",
  "unlock_type": "manual",
  "reason": "Support request"
}
```

#### Phase 2 Endpoints (Reflections & Evolution)

**7. POST /api/v1/constellations/reflections**
```
Description: Submit weekly reflection
Request Body: {
  "reflection_text": "This week I...",
  "self_rating": 4  // 1-5
}
Response: {
  "reflection_id": "uuid",
  "analysis": {
    "depth_score": 0.85,
    "rarity_tier": "rare",
    "constellations_unlocked": [...]
  }
}
```

**8. GET /api/v1/constellations/reflections**
```
Description: Get reflection history
```

**9. POST /api/v1/constellations/{constellation_id}/evolve**
```
Description: Trigger evolution stage progression
(Stage 2 auto-triggers on revisit count, Stage 3 requires wisdom note)
```

---

### Background Processing (Celery Tasks)

**Using Existing Stack:** Celery + Redis (existing infrastructure)

#### Real-Time Tasks (Low Latency)

**1. `detect_breakthrough_realtime.py`**
```python
@celery_app.task(bind=True, max_retries=3)
def analyze_message_for_breakthrough(self, chat_id: str, user_id: str):
    """
    Triggered: After each chat message is saved
    Priority: High (time-sensitive)
    Timeout: 5s

    Process:
    1. Load chat message + recent context (last 5 messages)
    2. AI analysis via LangChain (existing integration)
    3. If breakthrough detected:
       - Save breakthrough_event
       - Check if constellation should unlock
       - Publish unlock event
    4. Return detection result
    """
```

**2. `unlock_constellation.py`**
```python
@celery_app.task(bind=True, max_retries=3)
def unlock_constellation_for_user(
    self,
    user_id: str,
    category: str,
    unlock_type: str,
    context: dict
):
    """
    Idempotent constellation unlock

    Process:
    1. Determine which constellation to award (random from category)
    2. Check if already unlocked (idempotency)
    3. Create user_constellation record
    4. Update stats (via trigger)
    5. Publish constellation_unlocked event
    6. Return unlock details
    """
```

#### Scheduled Tasks (Celery Beat)

**3. `weekly_reflection_prompts.py`**
```python
@celery_app.task
def send_weekly_reflection_prompts():
    """
    Scheduled: Every Sunday 9am user local time

    Process:
    1. Query users who haven't submitted this week's reflection
    2. Send prompt notification (via existing notification system)
    3. Track prompt delivery
    """
```

**4. `post_conversation_analysis.py`**
```python
@celery_app.task
def analyze_completed_session(session_id: str):
    """
    Triggered: When chat session ends
    Priority: Medium

    Process:
    1. Load full session conversation
    2. Deep AI analysis (more thorough than real-time)
    3. Detect missed breakthroughs
    4. Refine existing breakthrough categorizations
    5. Update breakthrough_events with refined data
    """
```

**5. `reflection_depth_analysis.py`**
```python
@celery_app.task
def analyze_weekly_reflection(reflection_id: str):
    """
    Triggered: When user submits weekly reflection
    Timeout: 30s

    Process:
    1. Load reflection text
    2. AI quality analysis (LangChain)
       - Emotional vocabulary richness
       - Concrete examples vs vague statements
       - Self-awareness indicators
    3. Combine AI score + self-rating + length
    4. Determine rarity tier
    5. Unlock 1-3 constellations based on tier
    6. Publish events
    """
```

---

### Event Publishing Architecture

**Event Bus:** Redis Pub/Sub (existing infrastructure)

**Event Schema (Standard):**
```python
{
    "event_type": "constellation_unlocked",
    "timestamp": "2025-11-22T10:30:00Z",
    "user_id": "uuid",
    "data": {
        "constellation_id": "uuid",
        "constellation_key": "leo",
        "category": "courage",
        "unlock_type": "breakthrough",
        "rarity_tier": "rare"
    },
    "metadata": {
        "source": "breakthrough_detection_service",
        "version": "1.0"
    }
}
```

#### Event Types

**1. `constellation_unlocked`**
- Published when: Constellation awarded to user
- Subscribers: Frontend (push notification), Analytics, Email service

**2. `breakthrough_detected`**
- Published when: AI detects meaningful moment
- Subscribers: Constellation service, Analytics

**3. `reflection_submitted`**
- Published when: User completes weekly reflection
- Subscribers: Reflection analysis worker, Analytics

**4. `category_completed`**
- Published when: User unlocks all constellations in a category
- Subscribers: Celestial levels service (Phase 3), Celebration service

**5. `evolution_stage_unlocked`** (Phase 2)
- Published when: Constellation evolves to next stage

---

## Functional Requirements

### FR-1: Breakthrough Detection System

**FR-1.1: Real-Time Breakthrough Detection**
- **Description:** Analyze each chat message as it arrives for breakthrough indicators
- **Trigger:** POST /chats endpoint (existing) - add hook after message save
- **AI Analysis Markers:**
  - Emotional language: "I realize...", "I understand now...", "It makes sense..."
  - Vulnerability indicators: First-time disclosure, naming difficult emotions
  - Pattern recognition: Connecting past/present, reframing thoughts
  - Growth language: "I'm learning...", "I'm trying...", "I noticed..."
- **Category Classification:**
  - Emotion: Emotional awareness, processing feelings, emotional vocabulary
  - Courage: Vulnerability, facing fears, taking action despite discomfort
  - Presence: Mindfulness, staying present, non-reactive awareness
- **Confidence Threshold:** Only trigger if AI confidence >= 0.70
- **Acceptance Criteria:**
  - Detection completes within 2s of message save
  - False positive rate < 20%
  - Category accuracy >= 75%

**FR-1.2: Post-Conversation Analysis**
- **Description:** Deep analysis of full conversation after session ends
- **Trigger:** Session closed event
- **Process:** Analyzes entire conversation for missed breakthroughs
- **Acceptance Criteria:**
  - Runs within 5 minutes of session close
  - Can refine/reclassify real-time detections
  - Catches breakthroughs missed in real-time

**FR-1.3: Manual Breakthrough Marking**
- **Description:** User can mark any message as meaningful
- **API:** POST /constellations/breakthrough/mark
- **Acceptance Criteria:**
  - User can mark any message from their chat history
  - Optional category override
  - Marked breakthroughs have same weight as AI-detected

---

### FR-2: Constellation Unlock Logic

**FR-2.1: Category-Based Unlock**
- **Description:** When breakthrough detected, award constellation from matching category
- **Selection Logic (MVP):** Random constellation from category that user hasn't unlocked
- **Constraints:**
  - User can only unlock each constellation once (UNIQUE constraint)
  - Must have available constellations in category
- **Acceptance Criteria:**
  - Idempotent (retries don't create duplicates)
  - Transactional (all-or-nothing)
  - Unlock completes within 1s

**FR-2.2: Unlock Anchoring**
- **Description:** Link constellation to the specific chat message that triggered it
- **Data Saved:**
  - breakthrough_chat_id - exact message
  - breakthrough_session_id - conversation context
  - insight_summary - AI's interpretation
- **Acceptance Criteria:**
  - User can navigate from constellation → breakthrough message
  - Message context preserved (link doesn't break)

**FR-2.3: Celebration Event**
- **Description:** Publish event immediately upon unlock
- **Event Data:** Constellation details, category, rarity, unlock story
- **Subscribers:** Frontend for notification
- **Acceptance Criteria:**
  - Event published within 500ms of unlock
  - Frontend receives push notification

---

### FR-3: Constellation Library Management

**FR-3.1: Constellation Metadata**
- **MVP Set:** 20-30 constellations (subset of final 88)
- **Required Fields:**
  - constellation_key (unique identifier)
  - name (display name)
  - category (emotion/courage/presence)
  - mythology_short (1-2 sentence teaser)
  - sort_order (display ordering)
- **Acceptance Criteria:**
  - Library loaded from database (not hardcoded)
  - Easy to expand to full 88 in Phase 2
  - Mythology content versioned

**FR-3.2: Category Distribution**
- **MVP Distribution:**
  - Emotion: 12 constellations (40%)
  - Courage: 9 constellations (30%)
  - Presence: 9 constellations (30%)
- **Reflects final ratio:** 35/27/26
- **Acceptance Criteria:**
  - Balanced unlock opportunities across categories
  - All categories represented in MVP

---

### FR-4: Progress Tracking

**FR-4.1: User Statistics**
- **Auto-calculated via triggers:**
  - Total unlocked count
  - Per-category counts
  - Rarity tier distribution
  - First/last unlock timestamps
- **API:** GET /constellations/progress
- **Acceptance Criteria:**
  - Stats update immediately on unlock (< 100ms)
  - Queryable without expensive joins

**FR-4.2: Sky Visualization Data**
- **API:** GET /constellations/sky
- **Returns:** All user's constellations with unlock details
- **Performance:** < 1s response time for 88 constellations
- **Acceptance Criteria:**
  - Includes breakthrough links
  - Sorted by unlock date (recent first)
  - Filterable by category

---

### FR-5: Admin & Support Tools

**FR-5.1: Manual Constellation Award**
- **Use Case:** Support requests, testing, special events
- **API:** POST /constellations/admin/unlock
- **Authorization:** Admin role only
- **Acceptance Criteria:**
  - Can award any constellation to any user
  - Logs reason for manual unlock
  - Bypasses normal unlock logic

**FR-5.2: Analytics & Reporting**
- **Metrics to Track:**
  - Breakthrough detection rate (per user, per day)
  - Category balance (are users earning evenly?)
  - False positive feedback (if user dismisses detections)
- **Acceptance Criteria:**
  - Exported to existing analytics pipeline
  - Queryable for product insights

---

## Non-Functional Requirements

### NFR-1: Performance

**NFR-1.1: Real-Time Detection Latency**
- **Requirement:** < 2s from message save to breakthrough detection complete
- **Rationale:** User experience - near real-time feels magical
- **Measurement:** P95 latency tracked in monitoring

**NFR-1.2: API Response Times**
- GET /constellations/sky: < 1s (P95)
- GET /constellations/library: < 500ms (P95)
- POST /breakthrough/mark: < 1s (P95)

**NFR-1.3: Background Task Processing**
- Weekly reflection analysis: < 30s
- Post-conversation analysis: < 5 minutes
- Scheduled tasks execute within 1 minute of scheduled time

---

### NFR-2: Scalability

**NFR-2.1: Database Performance**
- **Constellation library:** Read-heavy, cache in Redis (TTL: 1 hour)
- **User constellations:** Write-optimized indexes
- **Breakthrough events:** Partitioned by month (historical data)

**NFR-2.2: Concurrent Users**
- Support 10,000 concurrent breakthrough detections
- Celery worker pool: Auto-scaling based on queue depth
- Redis pub/sub: Handle 1000 events/second

---

### NFR-3: Reliability

**NFR-3.1: Data Integrity**
- **Idempotent unlocks:** Retry-safe operations
- **Transactional:** Constellation unlock + stats update atomic
- **No data loss:** Breakthrough events persisted before analysis

**NFR-3.2: Graceful Degradation**
- If AI detection fails: Log error, continue (user can manual mark)
- If unlock fails: Retry up to 3 times, alert on failure
- If event publish fails: Queue for retry (dead letter queue)

**NFR-3.3: Availability**
- Target: 99.9% uptime (existing SLA)
- Constellation service independent of chat service
- Redis cache failures don't block core functionality

---

### NFR-4: Security & Privacy

**NFR-4.1: Data Privacy**
- **Breakthrough data is sensitive:** Contains vulnerable moments
- Encrypted at rest (existing PostgreSQL encryption)
- Access logs for breakthrough data queries
- GDPR: Full data export includes constellation history

**NFR-4.2: Authorization**
- All endpoints require authentication (Firebase token)
- Users can only access their own constellation data
- Admin endpoints require admin role
- Rate limiting on manual breakthrough marking (prevent abuse)

---

### NFR-5: Observability

**NFR-5.1: Monitoring**
- Metrics exposed via existing monitoring (Logfire)
  - Breakthrough detection rate
  - Constellation unlock rate
  - API endpoint latencies
  - Celery task durations
  - Event publish success rate

**NFR-5.2: Logging**
- Structured logs for:
  - AI detection decisions (confidence scores, markers found)
  - Constellation unlocks (user, constellation, trigger)
  - Failed unlocks (why it failed)
- Retention: 90 days (existing policy)

**NFR-5.3: Alerting**
- Alert on:
  - Breakthrough detection failure rate > 5%
  - Unlock failure rate > 1%
  - Real-time detection latency > 5s (P95)
  - Weekly reflection processing backlog > 100

---

### NFR-6: Maintainability

**NFR-6.1: Modular Design**
- Service boundaries clear (constellation, detection, progress)
- No tight coupling to existing chat services
- Configuration externalized (feature flags for phased rollout)

**NFR-6.2: Testing**
- Unit tests: 80% coverage
- Integration tests: API endpoints, Celery tasks
- AI detection tests: Sample conversations with known breakthroughs

**NFR-6.3: Documentation**
- API documentation (OpenAPI/Swagger)
- Database schema docs (ERD diagrams)
- Service architecture diagrams
- AI detection model documentation (markers, thresholds)

---

## Implementation Planning

### Phase 1 Timeline (MVP - 6-9 months)

**Month 1-2: Foundation**
- Database schema implementation
- Constellation library seed data (20-30 constellations)
- Core service structure (modular packages)

**Month 3-4: Detection & Unlock**
- Real-time breakthrough detection integration
- Constellation unlock logic (idempotent)
- Event publishing infrastructure

**Month 5-6: API & Integration**
- REST endpoints implementation
- Integration with existing chat flow
- Frontend API contracts defined

**Month 7-8: Testing & Refinement**
- AI detection tuning (false positive reduction)
- Load testing (10k concurrent users)
- Security audit

**Month 9: Launch**
- Beta rollout (10% users)
- Monitor metrics, gather feedback
- Full rollout if metrics positive

---

### Phase 2 Timeline (Post-MVP - 6-12 months later)

**Features:**
- Weekly reflection system
- Multi-stage evolution
- Full 88 constellation set
- Rarity tiers

---

### Phase 3 Timeline (Long-term - 12-18 months later)

**Features:**
- Celestial Levels (custom constellations, meta-abilities, mentor)
- Celebration ritual
- Advanced analytics

---

## References

**Foundation Documents:**
- Brainstorming Session: docs/bmm-brainstorming-session-2025-11-07.md
- Design Specification: docs/constellation-system-complete-design.md
- Brownfield Documentation: docs/index.md

**Existing Codebase:**
- Ultra API AWS (Python FastAPI)
- Database: PostgreSQL 13+
- Background Processing: Celery + Redis
- AI Integrations: LangChain, OpenAI, AWS Bedrock

---

## Next Steps

1. **Architecture Design** - Run: `/bmad:bmm:agents:architect` → `*create-architecture`
   - Service decomposition
   - Data flow diagrams
   - Integration patterns
   - AI detection pipeline design

2. **Epic & Story Breakdown** - Run: `*create-epics-and-stories`
   - Decompose requirements into implementable stories
   - 200k context-sized work units
   - Sprint planning ready

3. **UX Design** (Frontend PRD) - Separate document
   - Constellation sky visual design
   - Unlock celebration animations
   - Breakthrough review UX

---

_This PRD captures the backend architecture for the Constellation Gamification System - a therapeutic, depth-based progression system that transforms growth into collectible emotional bookmarks. The magic lies in the **Breakthrough Moment Anchor** - tapping a constellation transports users back to transformative conversations, creating an emotional memory palace of their healing journey._

_Created through collaborative discovery between BMad and Product Manager John, synthesizing SCAMPER brainstorming and brownfield project analysis._
