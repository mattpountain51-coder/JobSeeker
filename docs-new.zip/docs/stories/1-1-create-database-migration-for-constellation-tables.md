# Story 1.1: Create Database Migration for Constellation Tables

Status: ready-for-dev

## Story

As a **backend developer**,
I want **an Alembic migration that creates the 5 constellation tables**,
so that **the database schema supports constellation gamification**.

## Requirements Context

Story 1.1 creates the foundational database schema for the entire Constellation Gamification System. This migration establishes 5 new tables that integrate with the existing Ultra API AWS PostgreSQL database via foreign key relationships. The migration enables Epic 1 foundation work and all subsequent epics (2-6). This is migration #14 in the Alembic chain, following 13 existing migrations.

**Key Requirements:**
- 5 tables: constellation_library, user_constellations, breakthrough_events, user_constellation_stats, weekly_reflections
- Database trigger: `update_constellation_stats()` for auto-updating stats on unlock
- Proper indexing for performance (foreign keys, category filters, date sorting)
- Foreign key types must match existing tables (Integer, not UUID)
- Reversible migration (upgrade/downgrade must work cleanly)

[Source: docs/tech-spec-epic-1.md#Data-Models-and-Contracts]
[Source: docs/epics.md Story 1.1]

## Acceptance Criteria

**Given** the existing Ultra API AWS database with 12 tables
**When** I run `alembic upgrade head`
**Then** the following tables are created:

1. `constellation_library` table with:
   - All columns: id, constellation_key, name, category, mythology_short, mythology_full, sort_order, is_active, is_hybrid, required_categories, created_at, updated_at
   - Indexes: idx_constellation_category, idx_constellation_active
   - UNIQUE constraint on constellation_key

2. `user_constellations` table with:
   - All columns: id, user_profile_id, constellation_id, unlocked_at, unlock_type, rarity_tier, evolution_stage, stage_2_unlocked_at, stage_3_unlocked_at, revisit_count, breakthrough_chat_id, breakthrough_session_id, reflection_id, created_at, updated_at
   - Indexes: idx_user_const_user, idx_user_const_unlocked, idx_user_const_chat
   - UNIQUE constraint on (user_profile_id, constellation_id)
   - Foreign keys with proper ON DELETE behavior

3. `breakthrough_events` table with:
   - All columns: id, user_profile_id, session_id, chat_id, detected_at, detection_type, category, confidence_score, insight_summary, emotional_indicators, user_confirmed, user_marked, constellation_unlocked_id, created_at
   - Indexes: idx_breakthrough_user, idx_breakthrough_session, idx_breakthrough_chat, idx_breakthrough_category, idx_breakthrough_detected

4. `user_constellation_stats` table with:
   - All columns: user_profile_id (PK), total_unlocked, emotion_count, courage_count, presence_count, emotion_complete, courage_complete, presence_complete, common_count, rare_count, epic_count, legendary_count, stage_2_count, stage_3_count, celestial_tier, first_unlock_at, last_unlock_at, updated_at
   - Primary key on user_profile_id

5. `weekly_reflections` table with:
   - All columns: id, user_profile_id, week_start_date, week_end_date, reflection_text, self_rating, ai_quality_score, depth_score, rarity_tier, constellations_unlocked, submitted_at, analyzed_at, created_at
   - Indexes: idx_reflection_user, idx_reflection_week, idx_reflection_submitted
   - UNIQUE constraint on (user_profile_id, week_start_date)

**And** the `update_constellation_stats()` PostgreSQL function is created:
- Function accepts NEW row from user_constellations INSERT
- Uses INSERT ... ON CONFLICT to upsert stats
- Increments total_unlocked count
- Updates last_unlock_at timestamp

**And** the trigger `trg_update_constellation_stats` is created:
- Trigger type: AFTER INSERT
- Target table: user_constellations
- FOR EACH ROW
- Executes: update_constellation_stats() function

**And** all foreign key constraints reference existing tables correctly:
- user_profile(id) - ON DELETE CASCADE
- chats(id) - ON DELETE SET NULL
- sessions(id) - ON DELETE SET NULL
- constellation_library(id) - ON DELETE RESTRICT

**And** the migration can be rolled back cleanly:
- `alembic downgrade -1` removes all 5 tables
- `alembic downgrade -1` removes all indexes
- `alembic downgrade -1` removes trigger and function
- No errors during rollback
- Database state restored to pre-migration

**And** foreign key types match existing table ID types:
- Use Integer for all ID columns (not UUID)
- Confirmed by inspecting existing user_profile, chats, sessions tables

[Source: docs/epics.md Story 1.1 Acceptance Criteria]
[Source: docs/tech-spec-epic-1.md#Story-Level-Acceptance-Criteria]

## Tasks / Subtasks

### Task 1: Verify Existing Table ID Types (AC: Foreign Key Types)
- [ ] 1.1 Query existing `user_profile` table to confirm `id` column type
- [ ] 1.2 Query existing `chats` table to confirm `id` column type
- [ ] 1.3 Query existing `sessions` table to confirm `id` column type
- [ ] 1.4 Document findings (Integer vs UUID) to inform migration FK definitions

### Task 2: Create Alembic Migration File (AC: 1, 2)
- [ ] 2.1 Run `alembic revision --autogenerate -m "Add constellation gamification tables"`
- [ ] 2.2 Review generated migration file in `alembic/versions/`
- [ ] 2.3 Verify autogenerate detected all 5 tables from models (if models pre-written)
- [ ] 2.4 OR manually write migration if models not yet created

### Task 3: Define constellation_library Table (AC: 1)
- [ ] 3.1 Create table with all columns (id, constellation_key, name, category, mythology_short, mythology_full, sort_order, is_active, is_hybrid, required_categories, created_at, updated_at)
- [ ] 3.2 Set proper column types (Integer, String, Text, Boolean, JSON, DateTime)
- [ ] 3.3 Add UNIQUE constraint on constellation_key
- [ ] 3.4 Create index on category column: `idx_constellation_category`
- [ ] 3.5 Create index on is_active column: `idx_constellation_active`

### Task 4: Define user_constellations Table (AC: 1)
- [ ] 4.1 Create table with all columns (15 total columns)
- [ ] 4.2 Add foreign keys: user_profile_id (CASCADE), constellation_id (RESTRICT), breakthrough_chat_id (SET NULL), breakthrough_session_id (SET NULL)
- [ ] 4.3 Add UNIQUE constraint on (user_profile_id, constellation_id)
- [ ] 4.4 Create index on user_profile_id: `idx_user_const_user`
- [ ] 4.5 Create index on unlocked_at DESC: `idx_user_const_unlocked`
- [ ] 4.6 Create index on breakthrough_chat_id: `idx_user_const_chat`

### Task 5: Define breakthrough_events Table (AC: 1)
- [ ] 5.1 Create table with all columns (14 total columns)
- [ ] 5.2 Add foreign keys: user_profile_id (CASCADE), session_id (SET NULL), chat_id (SET NULL), constellation_unlocked_id (SET NULL)
- [ ] 5.3 Create index on user_profile_id: `idx_breakthrough_user`
- [ ] 5.4 Create index on session_id: `idx_breakthrough_session`
- [ ] 5.5 Create index on chat_id: `idx_breakthrough_chat`
- [ ] 5.6 Create index on category: `idx_breakthrough_category`
- [ ] 5.7 Create index on detected_at DESC: `idx_breakthrough_detected`

### Task 6: Define user_constellation_stats Table (AC: 1)
- [ ] 6.1 Create table with user_profile_id as primary key
- [ ] 6.2 Add all stat columns (18 total columns)
- [ ] 6.3 Add foreign key: user_profile_id REFERENCES user_profile(id) ON DELETE CASCADE
- [ ] 6.4 Set default values for all counter columns (0, false)

### Task 7: Define weekly_reflections Table (AC: 1)
- [ ] 7.1 Create table with all columns (13 total columns)
- [ ] 7.2 Add foreign key: user_profile_id REFERENCES user_profile(id) ON DELETE CASCADE
- [ ] 7.3 Add UNIQUE constraint on (user_profile_id, week_start_date)
- [ ] 7.4 Create index on user_profile_id: `idx_reflection_user`
- [ ] 7.5 Create index on week_start_date: `idx_reflection_week`
- [ ] 7.6 Create index on submitted_at DESC: `idx_reflection_submitted`

### Task 8: Create Database Trigger and Function (AC: 3)
- [ ] 8.1 Write PostgreSQL function `update_constellation_stats()` using PL/pgSQL
- [ ] 8.2 Function logic: INSERT INTO user_constellation_stats ... ON CONFLICT DO UPDATE
- [ ] 8.3 Increment total_unlocked, update last_unlock_at, update updated_at
- [ ] 8.4 Create trigger `trg_update_constellation_stats` AFTER INSERT ON user_constellations
- [ ] 8.5 Attach trigger to execute function FOR EACH ROW

### Task 9: Add Migration Downgrade Logic (AC: 2)
- [ ] 9.1 Define downgrade() function in migration
- [ ] 9.2 Drop trigger: `DROP TRIGGER IF EXISTS trg_update_constellation_stats`
- [ ] 9.3 Drop function: `DROP FUNCTION IF EXISTS update_constellation_stats()`
- [ ] 9.4 Drop tables in reverse order (handle foreign key dependencies)
- [ ] 9.5 Order: weekly_reflections, user_constellation_stats, breakthrough_events, user_constellations, constellation_library

### Task 10: Test Migration on Local Database (AC: 2)
- [ ] 10.1 Run `alembic upgrade head` on local/dev database
- [ ] 10.2 Verify all 5 tables created: `SELECT table_name FROM information_schema.tables WHERE table_schema='public'`
- [ ] 10.3 Inspect each table schema: `\d table_name` in psql
- [ ] 10.4 Verify indexes created: `\di` in psql
- [ ] 10.5 Verify trigger attached: `SELECT tgname FROM pg_trigger WHERE tgrelid = 'user_constellations'::regclass`
- [ ] 10.6 Test rollback: `alembic downgrade -1`
- [ ] 10.7 Verify all 5 tables removed
- [ ] 10.8 Reapply: `alembic upgrade head`
- [ ] 10.9 Confirm no errors during upgrade/downgrade cycle

### Task 11: Verify Foreign Key Constraints (AC: Foreign Keys)
- [ ] 11.1 Insert test constellation into constellation_library
- [ ] 11.2 Attempt INSERT into user_constellations with invalid user_profile_id (should fail with FK error)
- [ ] 11.3 Insert valid test data (user exists, constellation exists)
- [ ] 11.4 Delete user from user_profile
- [ ] 11.5 Verify user_constellations record CASCADE deleted
- [ ] 11.6 Verify user_constellation_stats record CASCADE deleted (if exists)

## Dev Notes

**Previous Story Context:**
First story in Epic 1 - no predecessor learnings available.

**Critical Actions Before Creating Migration:**

1. **MUST VERIFY ID TYPES** - Query existing tables to confirm Integer vs UUID:
   ```sql
   SELECT column_name, data_type
   FROM information_schema.columns
   WHERE table_name IN ('user_profile', 'chats', 'sessions')
   AND column_name = 'id';
   ```
   Expected result: INTEGER (based on architecture assumptions)
   If UUID detected: Adjust all foreign key types in migration

2. **Migration File Location:**
   - Path: `alembic/versions/xxx_add_constellation_tables.py`
   - This will be migration #14 in the chain
   - Depends on: Migration #13 (previous migration must be applied)

3. **Alembic Autogenerate Limitations:**
   - Autogenerate may not detect triggers/functions
   - Manually add trigger creation in upgrade()
   - Manually add trigger drop in downgrade()

**Key Architectural Constraints:**

- **Use Integer IDs** (not UUID) - matches existing table patterns per architecture doc
- **ON DELETE CASCADE** for user_profile references - ensures GDPR compliance
- **ON DELETE SET NULL** for optional FKs (chat, session) - preserves data if conversation deleted
- **ON DELETE RESTRICT** for constellation_library FK - prevents deleting constellations that users have unlocked

**Database Trigger Design:**

The trigger auto-updates user_constellation_stats when constellation unlocked:
- Runs AFTER INSERT on user_constellations (not BEFORE)
- Uses INSERT ... ON CONFLICT for upsert pattern
- Atomic with constellation unlock (same transaction)
- Ensures stats always in sync with unlocks
- Performance: < 50ms target (simple upsert operation)

**Testing Strategy:**

Per tech spec test strategy (lines 1288-1383):
- Integration test: Run migration upgrade/downgrade cycle
- Manual verification: Inspect tables with psql
- Trigger test: Insert test unlock, verify stats updated
- FK test: Test CASCADE delete behavior
- Performance test: Run EXPLAIN ANALYZE on common queries

### Project Structure Notes

**Expected File Locations:**

Migration file will be created at:
```
src/ultra-api-aws/alembic/versions/{revision}_add_constellation_tables.py
```

**Alembic Configuration:**
- Uses existing `alembic.ini` configuration
- Target metadata: Defined in `alembic/env.py`
- Database URL: From environment variables (existing config)

**Migration Numbering:**
- Current: Migration #13 (last existing migration)
- New: Migration #14 (this story)
- Future: Epics 2-6 may add more migrations if needed

**Codebase Integration Points:**

While this story only creates the migration (no model files yet), be aware that Stories 1.2-1.3 will create:
- `app/db/constellation.py` - ConstellationLibrary model
- `app/db/constellation_progress.py` - UserConstellation, BreakthroughEvent, UserConstellationStats models

Migration table definitions must match these future model definitions exactly.

**NO NEW DEPENDENCIES** - All required packages already installed (alembic, SQLAlchemy, asyncpg, psycopg2).

### References

**Primary Sources:**
- [Tech Spec: Epic 1 - Data Models](docs/tech-spec-epic-1.md#Data-Models-and-Contracts)
- [Architecture: Database Schema](docs/architecture/constellation-system-architecture.md#Data-Architecture)
- [Epic Breakdown: Story 1.1](docs/epics.md#Story-1.1)

**Technical References:**
- [Tech Spec: Migration Dependencies](docs/tech-spec-epic-1.md#Migration-Dependencies)
- [Tech Spec: Database Triggers](docs/tech-spec-epic-1.md lines 302-321)
- [Tech Spec: Foreign Key Relationships](docs/tech-spec-epic-1.md lines 801-814)

**Testing References:**
- [Tech Spec: Test Strategy](docs/tech-spec-epic-1.md#Test-Strategy-Summary)
- [Tech Spec: Test Scenario 1 - Migration Execution](docs/tech-spec-epic-1.md lines 1044-1051)

## Dev Agent Record

### Context Reference

- docs/stories/1-1-create-database-migration-for-constellation-tables.context.xml

### Agent Model Used

{{agent_model_name_version}}

### Debug Log References

### Completion Notes List

### File List
